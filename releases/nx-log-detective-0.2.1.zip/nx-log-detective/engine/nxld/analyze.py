"""NXLD: расчёт выбранных блоков по подготовленным таблицам. Результат — results.pkl (листы, сводки, проблемы)."""
import json, os, pickle, re, warnings
import numpy as np, pandas as pd
from . import coverage, profile, anatomy, visits, blocks, brief, recon, findings_meta, findings_text
from .findings import Findings, calibrate

warnings.filterwarnings('ignore')
STATUS_THRESHOLD = 0.30   # порог «стала хуже / исправлена частично» при повторной проверке
BLOCKS = ['Общий анализ', 'Ошибки', 'Нагрузка и безопасность', 'Боты', 'Маркетинг', 'SEO']


def cleaning_stats(R, V):
    H = V[V['group'] == 'Люди']
    return {
        'Просмотров у людей до очистки': int(H['n_pages_raw'].sum()), 'Просмотров у людей после очистки': int(H['n_pages'].sum()),
        'Склеено двойных загрузок (повтор адреса ≤ 5 с)': int(H['n_dup'].sum()), 'Склеено редиректов с их целью': int(H['n_redirect'].sum()),
        'Подгрузок форм и блоков (не считаются просмотрами)': int(H['n_embedded'].sum()),
        'Визитов людей во встроенных браузерах приложений': int(H['ua_webview'].sum()),
    }


def important_ips(c, S_bots):
    V, T = c.V, c.T.set_index('ip')
    rows = []
    def add(ips, cat, action):
        for ip in ips:
            vv = V[V['ip'] == ip]
            t = T.loc[ip] if ip in T.index else None
            rows.append(dict(ip=ip, категория=cat, сеть=t['org'] if t is not None else '', ASN=int(t['asn']) if t is not None else 0,
                             страна=t['cc'] if t is not None else '', тип_сети=t['nettype'] if t is not None else '',
                             визитов=len(vv), запросов=int(vv['n_req'].sum()), отправок=int(vv['n_goal'].sum()), принято=int(vv['n_conv'].sum()),
                             первый=blocks.dt(vv['start'].min()) if len(vv) else None, последний=blocks.dt(vv['end'].max()) if len(vv) else None,
                             действие=action if t is None or t['nettype'] in ('хостинг/облако',) else ('проверить/метка' if action.startswith('бан') else action)))
    spam = V[V['subgroup'].str.startswith('спам форм')]['ip'].unique()
    add(spam, 'спам форм', 'бан')
    if 'Подделки' in S_bots: add(S_bots['Подделки']['ip'].astype(str).unique(), 'поддельный робот', 'бан')
    if 'Операторы' in S_bots and len(S_bots['Операторы']):
        rc = set(x for x in ','.join(S_bots['Операторы'].get('адреса_разведки', pd.Series(dtype=str)).fillna('')).replace(' ', '').split(',') if x) - set(spam)
        add(sorted(rc), 'разведка оператора', 'наблюдение')
    add(c.m.get('staff_ips', []), 'свои: сотрудники', 'не трогать')
    add([m_['ip'] for m_ in c.m.get('monitors', [])], 'свои: мониторинг', 'не трогать')
    D = pd.DataFrame(rows, columns=['ip', 'категория', 'сеть', 'ASN', 'страна', 'тип_сети', 'визитов', 'запросов', 'отправок', 'принято', 'первый', 'последний', 'действие']).drop_duplicates('ip')
    return D


def restatus_late(prev, items, thr=STATUS_THRESHOLD):
    """Статус «было → стало» для карточек, созданных после основного сравнения (SEO), и снятие ложных «исправлена» по их ключам."""
    old = {x['key']: x for x in prev.get('findings', [])}
    live = {x['key'] for x in items if x.get('статус_вид') != 'исправлена'}
    items[:] = [x for x in items if not (x.get('статус_вид') == 'исправлена' and x['key'] in live)]
    for x in items:
        if x.get('статус'): continue
        if x['key'] not in old:
            x['статус'], x['статус_вид'] = 'новая', 'новая'; continue
        o, n = old[x['key']].get('главная_цифра'), x.get('главная_цифра')
        x['было'], x['стало'] = o, n
        if isinstance(o, (int, float)) and isinstance(n, (int, float)) and o:
            ch = (n - o) / abs(o)
            vid = 'стала хуже' if ch >= thr else ('исправлена частично' if ch <= -thr else 'сохраняется')
            x['статус'] = f"{vid}: {o:g} → {n:g}" + (f" ({ch:+.0%})" if vid == 'исправлена частично' else '')
        else:
            vid = 'сохраняется'; x['статус'] = vid
        x['статус_вид'] = vid


def run(workdir, selected=None, check_ips=(), marks=None, prev=None, log=print):
    selected = selected or BLOCKS
    selected = ['Общий анализ', 'Ошибки'] + [b for b in selected if b not in ('Общий анализ', 'Ошибки')]
    log('Загрузка подготовленных таблиц')
    R = pd.read_pickle(os.path.join(workdir, 'R.pkl'))
    V = pd.read_pickle(os.path.join(workdir, 'V.pkl'))
    T = pd.read_pickle(os.path.join(workdir, 'T.pkl'))
    G = pd.read_pickle(os.path.join(workdir, 'G.pkl'))
    E = pd.read_pickle(os.path.join(workdir, 'errors.pkl')) if os.path.exists(os.path.join(workdir, 'errors.pkl')) else pd.DataFrame()
    m = json.load(open(os.path.join(workdir, 'site_map.json')))
    inv = json.load(open(os.path.join(workdir, 'inventory.json')))
    # форма адреса — по реестру (classify): страница / файл / конструкт; страницами считаем только страницы
    from . import classify
    form_ = np.array([classify.form_of(p_)[0] for p_ in R['base'].cat.categories.astype(str)])
    R['is_page'] = R['is_page'].values & (form_[R['base'].cat.codes.values] == 'страница')
    R, V = visits.reverify(R, V)   # подлинность роботов — по нынешнему справочнику сетей
    V = visits.regroup(V, R)   # «Свои» — только сотрудники; системы мониторинга и утилиты — своими группами
    V = visits.mark_scanners(V, R, [e.get('движок') for e in (m.get('engines') or []) if isinstance(e, dict)])   # сканеры под браузер — не люди
    V, server_ips = visits.own_server(V, R)   # сервер сайта проверяет сам себя — его IP «Свои — сервер сайта»
    m['server_ips'] = server_ips
    V = visits.mark_form_spam(V, R)
    R, V, form_ev = visits.confirm_form_success(R, V)
    c = blocks.Ctx(R, V, E, T, m, inv, G)
    engines_ = [e.get('движок') for e in (m.get('engines') or []) if isinstance(e, dict)]
    c.addr = classify.build(R, c.human, np.asarray(c.rg == 'Свои'), engines_)   # реестр адресов — общий для всех листов
    F = Findings()
    res = {'sheets': {}, 'summary': {}, 'selected': selected, 'site_map': m, 'inventory': inv, 'cleaning': cleaning_stats(R, V), 'form_evidence': form_ev,
           'hosting': recon.detect_hosting(E), 'check_ips': list(check_ips or []),
           'mobile_share': round(float(V.loc[V['group'] == 'Люди', 'ua_mobile'].mean()) * 100, 1) if (V['group'] == 'Люди').any() else None}
    fn = {'Общий анализ': lambda: blocks.overview(c, F), 'Ошибки': lambda: blocks.errors(c, F),
          'Нагрузка и безопасность': lambda: blocks.load_security(c, F), 'Боты': lambda: blocks.bots(c, F, check_ips),
          'Маркетинг': lambda: blocks.marketing(c, F), 'SEO': lambda: ({}, {})}   # SEO считается после срезов 03–05 (seo.build)
    for b in BLOCKS:
        if b in selected or b == 'Боты':   # боты считаем всегда: нужны для листа IP и спама форм
            log(f'Блок: {b}')
            S, s = fn[b]()
            res['sheets'][b] = S
            res['summary'][b] = s
    res['ips'] = important_ips(c, res['sheets'].get('Боты', {}))
    from . import actors
    res['actors'] = actors.build(c)   # реестр обращающихся: срезы для сводки «Активность» и полных листов
    # незнакомые системы мониторинга (имя не из справочника) — Детективу: найти сервис и записать (edits.json → «мониторинги»)
    mv_ = V[V['group'] == 'Системы мониторинга']
    res['unknown_monitors'] = [dict(имя=str(sg), user_agent=str(g['ua'].iloc[0])[:200], IP=int(g['ip'].nunique()), визитов=len(g))
                               for sg, g in mv_.groupby('subgroup') if sg != 'неопознанный мониторинг' and visits.monitor_name(g['ua'].iloc[0]) is None][:20]
    Mn = res['actors'].get('мониторинг')
    if Mn is not None and len(Mn):   # неопознанная система по расписанию — вопрос аналитику: чья
        U_ = Mn[Mn['система'].str.startswith('Неопознанный')]
        for _, r_ in U_.iterrows():
            F.add('Боты', 'К сведению', 'unknown_monitor', r_['система'], f"Неизвестная система следит за сайтом по расписанию: {r_['система']}",
                  f"проверяет {r_['проверяет']} примерно раз в {int(r_['интервал'] or 0) // 60} мин; {int(r_['запросов'])} запросов; коды: {r_['коды']}",
                  'хостинг, мониторинги компании', 'Выяснить, чья это система: если своя — отметить как норму; если чужая — решить, нужна ли она', int(r_['запросов']), '')
    from . import errors as errors_
    res['errors'] = errors_.build(c, res['sheets'].get('Ошибки', {}).get('Сбои'))   # «адрес × код», журнал и сводка ошибок — для файла 02
    lk = getattr(c, 'leaks', None)   # служебные файлы, отданные посторонним (03): подсветка в «Файлах» и «Анатомии»
    res['leaks'] = [] if lk is None else [dict(файл=str(r['base']), ответов=int(r['ответов_200']), IP=int(r['IP']), размер=float(r['размер'])) for _, r in lk.iterrows()]
    # GET-отправки — в «Нагрузку и безопасность» (03), рядом с карточкой о персональных данных
    go = res['sheets'].get('Общий анализ', {}).pop('GET-отправки', None)
    if go is not None and 'Нагрузка и безопасность' in res['sheets']:
        res['sheets']['Нагрузка и безопасность']['GET-отправки'] = go
    sp = V[V['subgroup'].str.startswith('спам форм')].sort_values('start')
    res['spam_examples'] = [dict(класс=k, ip=g['ip'].iloc[-1], время=str(blocks.dt(g['start'].iloc[-1]))[:16], вход=g['entry'].iloc[-1], визитов=len(g)) for k, g in sp.groupby('subgroup')]
    if 'Боты' not in selected:
        res['sheets'].pop('Боты'); res['summary'].pop('Боты')
        F.items = [x for x in F.items if x['блок'] != 'Боты']
    # важность по вреду, однотипное — одной проблемой
    F.items = calibrate(F.items, int((V['group'] == 'Люди').sum()), int(R['ts'].max()))
    # отметки «это норма» из прошлого снимка или от человека
    marks = dict((prev or {}).get('marks', {}), **(marks or {}))
    for x in F.items:
        if x['key'] in marks:
            x['статус'] = 'отмечено как норма'
            x['отметка'] = marks[x['key']]
    if prev:
        old = {x['key']: x for x in prev.get('findings', [])}
        thr = STATUS_THRESHOLD
        for x in F.items:
            if x['статус']: continue
            if x['key'] not in old:
                x['статус'], x['статус_вид'] = 'новая', 'новая'; continue
            o, n = old[x['key']].get('главная_цифра'), x['главная_цифра']
            x['было'], x['стало'] = o, n
            if isinstance(o, (int, float)) and isinstance(n, (int, float)) and o:
                ch = (n - o) / abs(o)
                vid = 'стала хуже' if ch >= thr else ('исправлена частично' if ch <= -thr else 'сохраняется')
                x['статус'] = f"{vid}: {o:g} → {n:g}" + (f" ({ch:+.0%})" if vid == 'исправлена частично' else '')
            else:
                vid = 'сохраняется'; x['статус'] = vid
            x['статус_вид'] = vid
        cur = {x['key'] for x in F.items}
        for k, o in old.items():
            if k not in cur and o.get('блок') in selected:
                F.items.append(dict(key=k, блок=o['блок'], важность='К сведению', что_происходит=o['что_происходит'], факты='В новом периоде не обнаружено. Проверить: исправлено или просто нет запросов к этому адресу.',
                                    где_править='', что_сделать='Убедиться, что исправлено', главная_цифра=None, лист='', также_в='', статус='исправлена', статус_вид='исправлена', было=o.get('главная_цифра')))
        rows = []
        for b, sm in res['summary'].items():
            for k, v in sm.items():
                ov = prev.get('summary', {}).get(b, {}).get(k)
                rows.append(dict(блок=b, показатель=k, было=ov, стало=v))
        res['compare'] = pd.DataFrame(rows)
        res['prev_period'] = prev.get('period')
        res['prev_format'] = prev.get('format')   # /1 или /2: от формата зависит, что можно сравнить
    try:
        res['site_profile'] = profile.detect(c, res.get('site_map') or {})
    except Exception as e:
        res['site_profile'] = {'назначение': 'не определено', 'ошибка': str(e)}
    findings_meta.proofs(c, F.items, res['sheets'])
    flood_circumstance(F.items, res['sheets'])
    findings_text.humanize(F.items, res['sheets'], res['summary'])
    res['findings'] = F.items
    res['coverage'], res['loose_signals'] = coverage.check(res, F.items)
    res['query_params'] = getattr(c, 'query_params', None)
    from .thresholds import Sizes
    T_ = Sizes(визиты=int((V['group'] == 'Люди').sum()), запросы=len(R), ip=int(R['ip'].nunique()))   # пороги — доли от размера лога
    try:
        res['files'] = recon.files_inventory(R, T=T_, addr=c.addr, people=c.human | np.asarray(c.rg == 'Свои')).to_dict('records')
        T_c = res['errors']['коды']
        if len(T_c):   # «Файлы с ошибками» — тот же расчёт, что «Файлы», на файлах, которым хоть раз ответили 4xx/5xx
            # поломка — файл, на который ссылаются: страницы сайта, реклама, другие сайты. Просят только напрямую — перебор или
            # необязательный файл: для ИИ и роботов (llms.txt, ads.txt…) — рекомендацией, остальное — мусор, на вкладках по кодам
            Sr_ = res['errors'].get('источники')
            fb = set(T_c.loc[(T_c['форма'] == 'файл') & (T_c['код'] != 499), 'b'])
            linked = set(Sr_.loc[Sr_['вид'].isin(['страницы сайта', 'реклама', 'сайты', 'поиск']), 'b']) if Sr_ is not None and len(Sr_) else set()
            OPT_ = r'^/(llms(-full)?\.txt|ai\.txt|ads\.txt|app-ads\.txt|humans\.txt|security\.txt|\.well-known/security\.txt|apple-touch-icon[\w.-]*\.png|browserconfig\.xml|manifest\.json|site\.webmanifest)$'
            A_c = c.addr
            from_site = set(Sr_.loc[Sr_['вид'] == 'страницы сайта', 'b']) if Sr_ is not None and len(Sr_) else set()
            opt = {b for b in fb - from_site if re.search(OPT_, str(A_c['адрес'].values[b]))}   # нужны не сайту, а роботам и нейросетям
            eb = (fb & linked) - opt
            res['files_optional'] = sorted(str(A_c['адрес'].values[b]) for b in opt)
            Rm = np.isin(R['base'].cat.codes.values, list(eb))
            res['files_errors'] = recon.files_inventory(R[Rm], min_req=1, T=T_, addr=c.addr, people=(c.human | np.asarray(c.rg == 'Свои'))[Rm]).to_dict('records')
        res['unknown_extensions'] = classify.unknown_extensions(c.addr, R, T_('незнакомый_ключ'))
    except Exception as e:
        log(f'files_inventory: {e}'); res['files'] = None
    if res['files']:
        for x in res['findings']:
            if x['key'].split(':')[1] in ('missing_static', 'no_service', 'service_err', 'hotlink', 'ai_index', 'heavy_images'):
                x['ещё_листы'] = ['Файлы']
    try:
        res['anatomy'] = anatomy.build(c, res)
        sp_, np_ = res.get('site_profile') or {}, res['anatomy'].get('всего_страниц')
        if np_ and sp_.get('страниц'):   # одно число страниц везде: после склейки фильтров и без мусорных адресов
            sp_['страниц'] = np_; sp_['размер'] = 'маленький' if np_ <= 50 else 'средний' if np_ <= 5000 else 'большой'
    except Exception as e:
        import traceback; traceback.print_exc()
        res['anatomy'] = {'ошибка': str(e)}
    try:   # параметры — после «Анатомии»: нужны её системные папки и закрытые зоны; справочник — по найденному движку
        from .anatomy import PARAM_GROUPS, param_groups
        from . import reference
        A_ = res.get('anatomy') or {}
        site_ = (m.get('site_hosts') or ['site'])[0]
        ref = reference.load(m, R['base'].cat.categories.astype(str), site_)
        EP_ = res['sheets'].get('Ошибки', {}).get('Пустые страницы')   # пустой ответ служебного адреса движка — по справочнику
        if EP_ is not None and len(EP_):
            nt_ = [ref.system_note(b_) for b_ in EP_['base'].astype(str)]
            EP_['что'] = [x[0] if x else '' for x in nt_]
            EP_['комментарий'] = [x[1] if x else 'проверить: страница отдала почти пустой ответ' for x in nt_]
            EP_['норма'] = [bool(x) and str(x[1]).startswith('норма') for x in nt_]
        # системное — ядро, админка, API и закрытые зоны; шаблоны и доработки сайта (/local/ и т. п.) — это код самого сайта, не движок
        # системное — только папки движка по справочнику (ядро, админка, API); закрытые разделы сайта — отдельно: их сделал программист
        sysp = [p_ for p_ in ref.folders(('система', 'админка', 'api', 'служебное', 'обмен')) if p_.startswith('/')]
        if not sysp: sysp = [x['папка'] for x in A_.get('папки') or [] if not re.search(r'загруж|шаблон', str(x.get('что', '')))]
        zones_ = [x['адрес'] for x in A_.get('зоны') or [] if str(x.get('адрес', '')).startswith('/') and not any(x['адрес'].startswith(p_) for p_ in sysp)]
        FC = res['sheets'].get('Общий анализ', {}).get('Фасеты')
        navk = set(FC.groupby('ключ')['запросов'].sum().loc[lambda x: x >= T_('ключ_фасета')].index.astype(str)) if FC is not None and len(FC) else set()   # мусор из битых адресов — не фасет
        allref = reference.Reference([n_ for n_ in reference.all_engine_names()], (), site_)
        ref.other = allref
        ref.foreign_paths = reference.foreign_paths(allref, ref)
        Pr = recon.query_params_inventory(R, c.human, PARAM_GROUPS, navk, sysp, ref, staff=np.asarray(c.rg == 'Свои'), zone_prefixes=zones_, T=T_)
        res['params'] = Pr.to_dict('records')
        # незнакомые: нет в справочнике (или запись из поиска устарела) и заметное число запросов — Детектив ищет их в сети
        unk = Pr[(Pr['источник'] == 'дедукция') & ~Pr['группа'].isin(['Атаки и зонды', 'Логика сайта']) & (Pr['запросов'] >= T_('незнакомый_ключ'))
                 & ~((Pr['группа'] == 'Служебные движка') & (Pr['людей'] == 0))]   # логику сайта в сети не найти; служебное движка, которым пользуются только свои, искать незачем
        stale = [r_ for r_ in res['params'] if r_['источник'].startswith('поиск') and ref.stale(ref.match(r_['ключ']))]
        res['unknown_params'] = [dict(ключ=r_['ключ'], ключи=r_['ключи'][:8], сейчас=r_['группа'], по=r_['источник'] or 'нет', запросов=r_['запросов'],
                                      людей=r_['людей'], значения=r_['значения'], где=r_['где'], роботы=r_['роботы'], вместе_с=r_['вместе_с'])
                                 for r_ in unk.head(40).to_dict('records')] + [dict(ключ=r_['ключ'], сейчас=r_['группа'], по='поиск, устарело', запросов=r_['запросов']) for r_ in stale[:10]]
        # подсказка Детективу: ключ описан у другого движка (на сайте его нет — часто это зонды под чужой движок)
        for u in res['unknown_params']:
            h_ = allref.match(u['ключ'])
            if h_ and h_.get('файл', '').startswith('engines/'): u['есть_у_другого_движка'] = f"{h_['название_файла']}: {h_['группа']} — {h_.get('что', '')}"
        res['reference_files'] = [f['файл'] for f in ref.files]
        adm_ = [p_ for p_ in ref.folders(('админка',)) if p_.startswith('/')]
        res['embedded'] = recon.embedded_inventory(R, c.human, m.get('embedded_templates'), adm_, zones_, T=T_).to_dict('records')
        ref.save()
        if 'параметры' in A_: A_['параметры'] = param_groups(m, res)
    except Exception as e:
        import traceback; traceback.print_exc(); res['params'] = None
    from . import intake
    res['intake'] = intake.build(c, res)   # реестр точек приёма данных — один для 01, 03 и (позже) 05
    intake.findings(res, F.items)
    if 'Нагрузка и безопасность' in selected:   # срезы 03 на общих расчётах (common): после реестров, ошибок и параметров
        from . import security
        if os.environ.get('NXLD_DUMP_CTX'): pickle.dump((c, res), open(os.environ['NXLD_DUMP_CTX'], 'wb'), protocol=4)   # отладка срезов 03 без полного пересчёта
        res['security'] = security.build(c, res, res['sheets'].get('Нагрузка и безопасность', {}))
        security.findings(res, F.items)
    from . import profiles   # «Дела» атакующих для 04: обвинения, сигнатуры, состав — после реестров, ошибок и срезов 03
    try:
        res['profiles'] = profiles.build(c, res)
        res['bots_extra'] = profiles.extras(c, res)
    except Exception:
        import traceback; traceback.print_exc(); res['profiles'], res['bots_extra'] = None, None
    try:   # User-Agent по IP — для подделок и сканеров (04): самый частый и сколько ещё вариантов
        from .common import ua_by_ip
        ips_ = set(res['sheets'].get('Боты', {}).get('Подделки', pd.DataFrame(columns=['ip']))['ip'].astype(str))
        sc_ = (res.get('security') or {}).get('сканеры')
        if isinstance(sc_, tuple) and len(sc_) > 1 and sc_[1] is not None and len(sc_[1]): ips_ |= set(sc_[1]['ip'].astype(str))
        res['ua_ip'] = ua_by_ip(V, ips_)
    except Exception:
        import traceback; traceback.print_exc(); res['ua_ip'] = {}
    if 'Маркетинг' in selected:   # 05: журнал, карты по времени, качество каналов, боты в рекламе
        from . import marketing
        try: res['marketing'] = marketing.build(c, res)
        except Exception:
            import traceback; traceback.print_exc(); res['marketing'] = None
    if 'SEO' in selected:   # 06: обход поисковиками, файлы для роботов, страницы без обхода; карточки о поиске переезжают сюда (ключи прежние)
        from . import seo
        try:
            res['seo'] = seo.build(c, res)
            seo.findings(res, F.items)
            if prev: restatus_late(prev, F.items)   # карточки SEO появились после сравнения с прошлым снимком
        except Exception:
            import traceback; traceback.print_exc(); res['seo'] = None
    if prev:
        from .snapshot import check_keys
        res['ключи'] = check_keys(prev, {'findings': F.items})   # стабильность ключей проблем относительно прошлой проверки
    from . import alarms, derive
    alarms.apply(res, F.items)   # «Тревога» — после всех карточек и срезов
    derive.build(res)   # признаки и сводки для оформления, выжимки и снимка
    pickle.dump(res, open(os.path.join(workdir, 'results.pkl'), 'wb'))
    brief.save(brief.build(res, c, prev), workdir)
    log(f'Проблем найдено: {len(F.items)}')
    return res


def flood_circumstance(items, sheets):
    """Подделка, которая ещё и флудит, — обстоятельство к карточке подделок (не отдельная проблема)."""
    fl = sheets.get('Нагрузка и безопасность', {}).get('Флуд', pd.DataFrame())
    fk = sheets.get('Боты', {}).get('Подделки', pd.DataFrame())
    if not len(fl) or not len(fk): return
    top = fl[fl['запросов_в_минуту'] >= 1000].groupby('ip')['запросов_в_минуту'].max()
    hit = top[top.index.astype(str).isin(fk['ip'].astype(str))].sort_values(ascending=False)
    for x in items:
        if x['key'].split(':')[1] == 'fake_crawlers' and len(hit):
            add = f"подделка ещё и нагружает сервер: {hit.index[0]} — до {int(hit.iloc[0])} запросов в минуту" + (f" (и ещё {len(hit) - 1})" if len(hit) > 1 else '')
            x['почему'] = '; '.join(v for v in (x.get('почему'), add) if v)
