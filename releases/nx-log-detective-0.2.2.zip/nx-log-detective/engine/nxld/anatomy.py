"""NXLD: анатомия сайта — как он устроен по логу (ТЗ, лист «Анатомия сайта»).

Показываем только то, что реально существует: страницы, которые отдавались людям с ответом 200.
Движок описывает устройство нейтрально; названия уровней — по словарю частых слов в адресах,
иначе «Уровень N». Смысл и тематику даёт Детектив (подсказки — в brief, раздел «тематика»).
"""
import re
from urllib.parse import unquote
from collections import Counter
import numpy as np
import pandas as pd

# слово в адресе → (элемент, список)
SLUG = {
    'flat': ('квартира', 'квартиры'), 'flats': ('квартира', 'квартиры'), 'apartments': ('квартира', 'квартиры'), 'kvartiry': ('квартира', 'квартиры'),
    'parking': ('машиноместо', 'парковки'), 'pantry': ('кладовая', 'кладовые'), 'commercial': ('помещение', 'коммерческие помещения'),
    'product': ('товар', 'товары'), 'products': ('товар', 'товары'), 'goods': ('товар', 'товары'), 'catalog': ('позиция каталога', 'каталог'),
    'katalog': ('позиция каталога', 'каталог'), 'shop': ('товар', 'магазин'), 'item': ('элемент', 'элементы'),
    'news': ('новость', 'новости'), 'novosti': ('новость', 'новости'), 'blog': ('запись блога', 'блог'), 'articles': ('статья', 'статьи'),
    'article': ('статья', 'статьи'), 'stati': ('статья', 'статьи'), 'journal': ('статья', 'журнал'), 'press': ('публикация', 'пресс-центр'),
    'reviews': ('отзыв', 'отзывы'), 'otzyvy': ('отзыв', 'отзывы'), 'action': ('акция', 'акции'), 'actions': ('акция', 'акции'),
    'akcii': ('акция', 'акции'), 'sales': ('акция', 'акции'), 'promo': ('акция', 'акции'), 'services': ('услуга', 'услуги'),
    'uslugi': ('услуга', 'услуги'), 'projects': ('проект', 'проекты'), 'portfolio': ('работа', 'портфолио'), 'gallery': ('альбом', 'галерея'),
    'faq': ('вопрос', 'вопросы'), 'vacancy': ('вакансия', 'вакансии'), 'vacancies': ('вакансия', 'вакансии'), 'events': ('событие', 'события'),
    'brands': ('бренд', 'бренды'), 'category': ('категория', 'категории'), 'tag': ('тег', 'теги'), 'realty': ('объект', 'объекты'),
    'docs': ('документ', 'документы'), 'documents': ('документ', 'документы'), 'video': ('видео', 'видео'), 'photo': ('фото', 'фото'),
    'filter': ('фильтр', 'фильтр'), 'search': ('поиск', 'поиск'),
}
FEED_HINT = {'news', 'novosti', 'blog', 'articles', 'article', 'stati', 'journal', 'press', 'reviews', 'otzyvy', 'action', 'actions', 'akcii', 'sales', 'promo', 'events', 'vacancy', 'vacancies', 'faq'}
CABINET = r'^/(personal|lk|cabinet|account|profile|my|dashboard|user|users|kabinet|lichnyy-kabinet|lichnyj-kabinet)/'
ENGINE_DIRS = {
    '1С-Битрикс': {'/bitrix/': 'ядро движка и служебные скрипты', '/local/': 'шаблоны и доработки сайта', '/upload/': 'загруженные файлы: картинки, документы'},
    'WordPress': {'/wp-content/': 'темы, плагины и загрузки', '/wp-includes/': 'ядро движка', '/wp-admin/': 'админка', '/wp-json/': 'REST API'},
    'Joomla': {'/components/': 'компоненты', '/modules/': 'модули', '/templates/': 'шаблоны', '/media/': 'медиа движка', '/images/': 'картинки', '/administrator/': 'админка'},
    'Drupal': {'/sites/': 'файлы сайта', '/core/': 'ядро движка', '/modules/': 'модули', '/themes/': 'темы'},
    'MODX': {'/assets/': 'шаблоны и файлы', '/manager/': 'админка', '/core/': 'ядро движка', '/connectors/': 'служебные запросы'},
    'OpenCart': {'/catalog/': 'шаблоны и скрипты витрины', '/image/': 'картинки', '/admin/': 'админка', '/system/': 'ядро'},
    'Tilda': {'/tild': 'файлы Тильды'},
}
MEDIA_EXT = {'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg', 'ico', 'bmp', 'tif', 'tiff', 'mp4', 'webm', 'mov', 'avi', 'mp3', 'ogg', 'wav',
             'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'zip', 'rar', '7z'}
MEDIA_KIND = {**{e: 'картинки' for e in ('jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg', 'ico', 'bmp', 'tif', 'tiff')},
              **{e: 'видео и звук' for e in ('mp4', 'webm', 'mov', 'avi', 'mp3', 'ogg', 'wav')},
              **{e: 'документы' for e in ('pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx')}, **{e: 'архивы' for e in ('zip', 'rar', '7z')}}
FORM_NAME = [(r'callback|call_?back|zvonok|perezvon', 'обратный звонок'), (r'excurs', 'запись на экскурсию'), (r'price|cena|tsena|prais', 'запрос цены'),
             (r'consult', 'консультация'), (r'finish|otdelk', 'отделка'), (r'invest', 'для инвесторов'), (r'ipotek|mortgage|credit|kredit', 'ипотека и кредит'),
             (r'order|zakaz|checkout|basket|cart', 'заказ'), (r'subscr|podpis', 'подписка'), (r'feedback|contact|svyaz', 'обратная связь'),
             (r'question|vopros', 'вопрос'), (r'review|otzyv', 'отзыв'), (r'vacan|resume|rezyume', 'отклик на вакансию'), (r'register|registr|signup', 'регистрация'),
             (r'login|auth|signin', 'вход'), (r'tradein|trade-in', 'трейд-ин'), (r'booking|bron', 'бронирование')]
PARAM_GROUPS = [
    ('Реклама и аналитика', r'^(utm_\w+|yclid|gclid|fbclid|wbraid|gbraid|erid|calltouch\w*|roistat\w*|_openstat|from|ref|cm_id|ad_?id|campaign_?id|_ga|_gl|ymclid|vkclid|mc_\w+)$'),
    ('Поисковики и Яндекс', r'^(etext|ybaip|ysclid|y_ref|yabizcmpgn|yabizcmpgn\w*|lr|text|_ym\w*|utm_referer|utm_ya_campaign|utm_candidate|turbo\w*|amp)$'),
    ('Данные форм', r'(^form|form_|submit|^btn_|mail|phone|^tel$|email|comment|message|question|^name$|_name$|^fio$|theme|captcha|sessid)'),
    ('Сброс кэша', r'^(v|ver|version|_|t|ts|timestamp|rnd|rand|nocache|nc|cb|\(число без имени\))$'),
]
FILTER_WORDS = r'(filter|sort|order|page|pagen|limit|view|show|ajax|type|price|min|max|rooms|floor|sq|area|set_|arr|items|objects)'   # строка «Фильтры» у каталога
PARAM_ORDER = ['Реклама и аналитика', 'Поисковики и Яндекс', 'Данные форм', 'Поиск и навигация', 'Служебные движка', 'Логика сайта', 'Метки сервисов', 'Сброс кэша', 'Атаки и зонды', 'Неизвестные']
SERVICE_GROUPS = [
    ('Для роботов', r'^/(robots\.txt|sitemap[\w.-]*\.xml(\.gz)?|sitemap/.*)$'),
    ('Фиды и выгрузки', r'(/export/|/feeds?(/|\.xml|$)|\.yml$|\.csv$|yandex[\w-]*\.xml$|google[\w-]*\.xml$|/rss)'),
    ('Иконки и манифест', r'(favicon|apple-touch|manifest\.json|site\.webmanifest|browserconfig\.xml|\.ico$)'),
    ('Подтверждение прав', r'(yandex_[0-9a-f]+\.html|google[0-9a-f]+\.html|\.well-known/acme-challenge/)'), ('Служебные (.well-known)', r'\.well-known/'),
    ('Стили и скрипты', r'\.(css|js|mjs|map)$'),
    ('Данные для виджетов', r'\.(xml|json)$'),
]


def first_seg(p):
    s = p.strip('/').split('/')
    return '/' if not s[0] else f'/{s[0]}/'


def slug_name(seg, form):
    v = SLUG.get(seg.lower())
    return v[form] if v else None


def name_of(x, rules):
    for rx, nm in rules:
        if re.search(rx, x, re.I): return nm
    return None


def build(c, res):
    R = c.R
    st = R['status'].values
    m = res.get('site_map') or {}
    engine = ((m.get('engines') or [{}])[0] or {}).get('движок', '')
    cats, codes = R['base'].cat.categories, R['base'].cat.codes.values
    pg = c.human & R['is_page'].values & (st == 200) & (R['method'].values == 'GET')
    P = pd.DataFrame({'code': codes[pg], 'vid': R['vid'].values[pg]})
    views = P.groupby('code').size()
    visits = P.drop_duplicates().groupby('code').size()
    pages = pd.DataFrame({'адрес': cats[views.index].astype(str), 'просмотров': views.values, 'визитов': visits.reindex(views.index).values})
    junk = pages['адрес'].str.contains(r'[&;=\s]|%20|text/html', regex=True) | pages['адрес'].map(junk_path)
    pages = pages[~junk]          # битые и мусорные адреса — не часть устройства          # битые адреса — не часть устройства
    cl = pages['адрес'].map(clean_path)
    pages['фильтр'] = [f for _, f in cl]; pages['адрес'] = [p_ for p_, _ in cl]
    flt_pages = pages[pages['фильтр']].groupby('адрес').size()
    flt_visits = pages[pages['фильтр']].groupby('адрес')['визитов'].sum()
    pages = pages.groupby('адрес', as_index=False).agg(просмотров=('просмотров', 'sum'), визитов=('визитов', 'sum'))
    pages['раздел'] = pages['адрес'].map(first_seg)
    pages['глубина'] = pages['адрес'].map(lambda p: 0 if p.strip('/') == '' else len(p.strip('/').split('/')))
    tot_visits = int(P['vid'].nunique())
    sec_visits = P.assign(раздел=pd.Series(cats[P['code'].values].astype(str)).map(first_seg).values).drop_duplicates(['раздел', 'vid']).groupby('раздел').size()
    eng_dirs = ENGINE_DIRS.get(engine, {})
    min_v = max(20, int(0.0005 * tot_visits))
    A = dict(движок=engine, всего_страниц=len(pages), визитов=tot_visits)
    # --- админка и закрытые зоны
    zones, not_closed = [], set()
    if m.get('admin_regex'):
        adm = str(m['admin_regex']).lstrip('^')
        staff = m.get('staff_ips') or []
        staff = staff if isinstance(staff, list) else re.findall(r'\d+\.\d+\.\d+\.\d+', str(staff))
        zones.append(dict(что='Админка движка', адрес=adm, подробно=f"входили {len(staff)} адресов сотрудников" if staff else 'входов сотрудников по логу не видно', входили=len(staff)))
    OS = res.get('sheets', {}).get('Нагрузка и безопасность', {}).get('Открытые служебные разделы', pd.DataFrame())
    for _, r in (OS[(OS['форма_входа'] == 'да') & (OS['IP_с_200'] >= 3)].iterrows() if len(OS) and 'IP_с_200' in OS else []):
        zones.append(dict(что='Служебный раздел', адрес=r['раздел'], подробно='вход по паролю (форма входа)', входили=int(r['адресов_вошло']), неудачных=int(r.get('неудачных', 0)), POST=int(r.get('POST_входов', 0)),
                          без_входа=r['страницы_без_входа'] if r.get('адресов_без_входа', 0) else ''))
    for sec, v in sec_visits.items():
        if re.match(CABINET, sec) and v >= 5:
            g_ = pages[pages['раздел'] == sec]
            sm_ = np.isin(codes, np.where(cats.str.startswith(sec))[0])
            posts = int((sm_ & (R['method'].values == 'POST') & c.human).sum())
            if len(g_) < 2 and not posts:      # по названию кабинет, но входа и внутренних страниц нет — обычная страница
                not_closed.add(sec); continue
            sub = [x for x in levels(g_, sec) if x['глубина'] >= 2] if len(g_) else []
            ipc = np.isin(codes, np.where(cats.str.startswith(sec))[0]) & pg
            zones.append(dict(что='Личный кабинет', адрес=sec, визитов=int(v), IP=int(R['ip'].values[ipc].nunique() if hasattr(R['ip'].values[ipc], 'nunique') else len(set(R['ip'].values[ipc]))), подробно='', уровни=sub))
    hosts = m.get('site_hosts') or []
    for h in hosts[1:]:
        if re.search(r'(^|\.)(dev|test|stage|staging|demo|beta)\.', h + '.'):
            zones.append(dict(что='Тестовая копия', адрес=h, подробно='запросы к ней есть в этих логах'))
    A['зоны'] = zones
    # --- разделы: каталоги, ленты, простые
    cats_, feeds, simple = [], [], []
    for sec, g in pages.groupby('раздел'):
        v = int(sec_visits.get(sec, 0))
        if sec == '/' or v < min_v or sec in eng_dirs or any(sec.startswith(k) for k in eng_dirs) or (re.match(CABINET, sec) and sec not in not_closed):
            continue
        lv = levels(g, sec)
        heavy = [x for x in lv if x['адресов'] >= 10]
        word = sec.strip('/').lower()
        feedish = word in FEED_HINT and any(x['глубина'] == 2 and x['адресов'] >= 3 for x in lv) and max(x['глубина'] for x in lv) <= 2
        if not heavy and not feedish:
            simple.append(dict(раздел=sec, страниц=len(g), визитов=v))
            continue
        deep = max(x['глубина'] for x in (heavy or lv))
        el = [x for x in lv if x['глубина'] == deep][0]
        nf = int(flt_pages[flt_pages.index.str.startswith(sec)].sum()) if len(flt_pages) else 0
        nfv = int(flt_visits[flt_visits.index.str.startswith(sec)].sum()) if len(flt_visits) else 0
        cnt = Counter()
        for x in collapse(roles(lv), v): cnt[x['роль']] += x['адресов']
        lv = roles(lv)
        card = dict(раздел=sec, визитов=v, страниц=len(g), уровни=collapse(lv, v), элементов=el['адресов'], элемент=el['название'] if not el['название'].startswith('Уровень') else 'элемент',
                    глубина_элементов=deep, фильтры=filters_of(R, pg, sec), страниц_фильтра=nf, визитов_фильтра=nfv,
                    разделов=cnt['раздел'], подразделов=cnt['подраздел'], шаблоны=templates_of(R, pg, sec, deep))
        (feeds if (feedish or (deep <= 2 and word in FEED_HINT)) else cats_).append(card)
    A['каталоги'] = sorted(cats_, key=lambda x: -x['визитов'])
    A['ленты'] = sorted(feeds, key=lambda x: -x['визитов'])
    marks = section_marks(res)
    for s_ in simple:
        mk = [marks.get(s_['раздел'], '')]
        if s_['раздел'] in not_closed: mk.append('называется как кабинет, но входа по логу нет')
        if filters_of(R, pg, s_['раздел']) or (len(flt_pages) and flt_pages[flt_pages.index.str.startswith(s_['раздел'])].sum()): mk.append('фильтры')
        s_['пометки'] = ', '.join(x for x in mk if x)
    A['простые'] = sorted(simple, key=lambda x: -x['визитов'])
    A['главная'] = int(sec_visits.get('/', 0))
    # --- формы
    A['формы'], A['не_цели'] = forms(R, res, m)
    # --- папки движка
    A['папки'] = []
    for d, what in eng_dirs.items():
        idx = np.where(cats.str.startswith(d))[0]
        mm = np.isin(codes, idx)
        if mm.sum():   # виды — группами из справочника расширений, все, с числом запросов (не примеры)
            from . import classify
            uc, cn = np.unique(codes[mm], return_counts=True)
            kinds = Counter()
            from .visits import probe_rx
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter('ignore', UserWarning)
                prx = re.compile(probe_rx(('однозначный', 'неоднозначный')), re.I)
            for u_, n_ in zip(uc, cn):
                if prx.search(str(cats[u_])): continue   # зонды сканеров — не содержимое папки
                f_ = classify.form_of(str(cats[u_]))
                kinds[f_[1] if f_[0] == 'файл' else 'страницы и обработчики'] += int(n_)
            A['папки'].append(dict(папка=d, что=what, запросов=int(mm.sum()), доля=float(round(mm.mean() * 100, 1)),
                                   типы='\n'.join(f"{k.lower()} — {n:,}".replace(',', ' ') for k, n in kinds.most_common())))
    # --- папки с файлами: все виды файлов из реестра (справочник расширений), не только картинки; с ошибками
    from . import classify
    grp_c = np.array([(lambda f: f[1] if f[0] == 'файл' else '')(classify.form_of(p_)) for p_ in cats.astype(str)], dtype=object)
    from .visits import probe_rx
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', UserWarning)
        probe_c = pd.Series(np.asarray(cats).astype(str)).str.contains(probe_rx(('однозначный', 'неоднозначный')), regex=True, case=False).values
    grp_c[probe_c] = ''   # зонды сканеров — не файлы сайта
    gg = grp_c[codes]
    mm = gg != ''
    MD = pd.DataFrame({'p': cats[codes[mm]].astype(str), 'вид': gg[mm], 'b': R['bytes'].values[mm], 'st': st[mm]})
    MD['папка'] = MD['p'].map(lambda p: '/' + '/'.join(p.strip('/').split('/')[:1]) + '/' if '/' in p.strip('/') else '/ (корень)')
    media = []
    for f, g in MD.groupby('папка'):
        if len(g) < max(100, 0.005 * len(MD)): continue
        ok = (g['st'] < 400)
        err = int(((g['st'] >= 400) & (g['st'] != 499)).sum())
        kinds = g.groupby('вид').size().sort_values(ascending=False)
        deep = g['p'][g['p'].str.strip('/').str.count('/') >= 2]   # подпапка — только настоящая папка, не файл в корне папки
        sub_all = deep.map(lambda p: '/' + '/'.join(p.strip('/').split('/')[:2]) + '/').value_counts()
        sub = sub_all.head(3)
        media.append(dict(папка=f, запросов=len(g), ГБ=float(round(g.loc[ok, 'b'].sum() / 1024 ** 3, 1)), ошибок=err,
                          виды='; '.join(f"{k.lower()} — {int(n):,}".replace(',', ' ') for k, n in kinds.head(5).items()),
                          подпапки=', '.join(sub.index), подпапок=int(len(sub_all)), почти_ошибки=err > 0.5 * len(g)))
    A['медиа'] = sorted(media, key=lambda x: -x['запросов'])
    # --- служебные файлы, подгружаемые блоки, параметры
    A['служебные'] = service_groups(m, res)
    A['подгружаемые'] = embedded_groups(m)
    A['параметры'] = param_groups(m, res)
    A['подсказки'] = hints(pages, res, m)
    A['get_приём'] = get_receivers(R, c, st)
    A['api'] = api_points(R, c, st)
    A['post_pages'] = post_profile(R)
    return A


def junk_path(p):
    if '//' in p: return True          # двойной слэш — битая ссылка, не отдельная страница
    for seg in p.strip('/').split('/'):
        if '.' in seg and not re.search(r'\.(html?|php)$', seg): return True
        if len(seg) >= 20 and re.search(r'[A-Z]', seg) and re.search(r'\d', seg): return True
    return False


def clean_path(p):
    """Страницы умного фильтра (/…/filter/…/apply/) относятся к своему списку: отрезаем хвост фильтра."""
    segs = p.strip('/').split('/')
    if 'filter' in segs:
        return '/' + '/'.join(segs[:segs.index('filter')]) + '/', True
    return p, False


def levels(g, sec):
    """Уровни раздела. Имя — по слову из адреса: список-подразделы (flat, parking) называются списком,
    а элемент получает имя ближайшего слова сверху. Промежуточные уровни без слова — «Уровень N»."""
    lv, word = [], sec.strip('/').lower()
    for d, gd in sorted(g.groupby('глубина'), key=lambda x: x[0]):
        segs = gd['адрес'].map(lambda p: p.strip('/').split('/')[d - 1].lower() if d else '')
        words = Counter(segs)
        small_set = d > 1 and len(words) <= 5 and all(re.fullmatch(r'[a-z_]+', w) for w in words)
        known = [w for w, _ in words.most_common() if w in SLUG]
        x = dict(глубина=int(d), адресов=len(gd), визитов=int(gd['визитов'].sum()), пример=gd.sort_values('визитов', ascending=False)['адрес'].iloc[0], шаблон=shape(gd['адрес']),
                 слова=', '.join(w for w, _ in words.most_common(4)) if small_set else '', слово_сверху=word, литерал=bool(small_set),
                 все=gd.sort_values('визитов', ascending=False)['адрес'].tolist()[:5] if len(gd) <= 5 else [],
                 примеры={w: gd[segs == w].sort_values('визитов', ascending=False)['адрес'].iloc[0] for w, _ in words.most_common(5)} if small_set else {})
        if d == 1:
            x['название'] = 'Список'
        elif small_set and known:
            x['название'] = ', '.join(dict.fromkeys(slug_name(w, 1) for w in known)); word = known[0]
        elif small_set:
            x['название'] = f'Уровень {d}'; word = ''
        else:
            x['название'] = None
        lv.append(x)
    # переменные уровни: имя слова сверху получает только самый посещаемый из идущих подряд после этого слова
    i = 0
    while i < len(lv):
        if lv[i]['название'] is None:
            j = i
            while j < len(lv) and lv[j]['название'] is None and lv[j]['слово_сверху'] == lv[i]['слово_сверху']: j += 1
            run = lv[i:j]
            best = max(run, key=lambda y: y['визитов'])
            for y in run:
                nm = slug_name(y['слово_сверху'], 0) if y is best else None
                y['название'] = nm or f"Уровень {y['глубина']}"
            i = j
        else:
            i += 1
    return lv


def shape(addrs):
    """Шаблон уровня: одинаковые части — как есть, небольшой набор слов — {a|b}, остальное — *."""
    rows = [a.strip('/').split('/') for a in addrs]
    if not rows or rows == [['']]: return '/'
    out = []
    for i in range(max(len(r) for r in rows)):
        vals = Counter(r[i] for r in rows if len(r) > i)
        if len(vals) == 1: out.append(next(iter(vals)))
        elif len(vals) <= 5 and all(re.fullmatch(r'[a-z_]+', v) for v in vals): out.append('{' + '|'.join(v for v, _ in vals.most_common()) + '}')
        else:
            pre = re.match(r'^([a-z_-]*?)(?=\d)', next(iter(vals)))
            pre = pre.group(1) if pre else ''
            out.append(f'{pre}*' if pre and all(re.fullmatch(re.escape(pre) + r'\d+', v) for v in vals) else '*')
    return '/' + '/'.join(out) + '/'


def roles(lv):
    """Роль уровня: индексная, раздел, подраздел, элемент."""
    if not lv: return lv
    deep = max((x for x in lv if x['адресов'] >= 10), key=lambda y: y['глубина'], default=lv[-1])['глубина']
    for x in lv:
        d = x['глубина']
        x['роль'] = ('индексная' if d == 1 else 'элемент' if d == deep else 'подраздел' if x.get('литерал') else 'раздел' if d < deep else 'страница внутри элемента')
    return lv


def collapse(lv, sec_visits):
    """Промежуточные неназванные уровни с малым трафиком склеиваем в одну строку."""
    out, buf = [], []
    for x in lv:
        weak = x['название'].startswith('Уровень') and x['визитов'] < 0.02 * max(1, sec_visits)
        if weak:
            buf.append(x); continue
        if buf:
            out.append(merge(buf)); buf = []
        out.append(x)
    if buf: out.append(merge(buf))
    return out


def merge(buf):
    if len(buf) == 1: return buf[0]
    return dict(глубина=buf[0]['глубина'], до=buf[-1]['глубина'], адресов=sum(x['адресов'] for x in buf), визитов=sum(x['визитов'] for x in buf),
                пример=buf[-1]['пример'], шаблон=buf[-1].get('шаблон', ''), название='промежуточные уровни', роль='промежуточные', слова='')


def filters_of(R, pg, sec):
    qc = R['query'].cat.codes.values
    idx = np.where(R['base'].cat.categories.str.startswith(sec))[0]
    mm = pg & np.isin(R['base'].cat.codes.values, idx) & (qc >= 0)
    if not mm.any(): return []
    qs = R['query'].cat.categories[qc[mm]].astype(str)
    keys = Counter(k.split('=')[0] for q in qs for k in q.split('&') if k)
    keys = [(k, n) for k, n in keys.most_common(30) if re.search(FILTER_WORDS, k, re.I) and not re.match(PARAM_GROUPS[0][1], k, re.I)]
    out = []
    for k, n in keys:
        base = re.sub(r'(_\d+)+$|\d+$', '_*', k)
        if base not in [b for b, _ in out]: out.append((base, n))
    return [f"{b}" for b, _ in out[:6]]


def templates_of(R, pg, sec, depth):
    idx = np.where(R['base'].cat.categories.str.startswith(sec))[0]
    mm = pg & np.isin(R['base'].cat.codes.values, idx)
    t = pd.Series(R['tpl'].values[mm]).astype(str)
    t = t[t.map(lambda p: len(p.strip('/').split('/')) == depth)]
    return t.value_counts().head(3).index.tolist()


def section_marks(res):
    out = {}
    OS = res.get('sheets', {}).get('Нагрузка и безопасность', {}).get('Открытые служебные разделы', pd.DataFrame())
    for _, r in (OS.iterrows() if len(OS) else []):
        if r.get('форма_входа') == 'да': out[r['раздел']] = 'вход'
    C = res.get('sheets', {}).get('Общий анализ', {}).get('Конверсии', pd.DataFrame())
    return out


def forms(R, res, m):
    C = res.get('sheets', {}).get('Общий анализ', {}).get('Конверсии', pd.DataFrame())
    rules = m.get('form_success_rules') or {}
    if isinstance(rules, str):
        try: rules = eval(rules)
        except Exception: rules = {}
    out = []
    if len(C):
        H = C[C['группа'] == 'Люди']
        for goal, g in C.groupby('цель'):
            hg = H[H['цель'] == goal]
            ent = hg['вход'].astype(str).map(first_seg).value_counts()
            where = 'на страницах всех разделов' if len(ent) >= 5 else ', '.join(ent.index[:3])
            rule = str(rules.get(goal, '')).replace('цель: ', '').replace('успех = 3xx (редирект после отправки)', 'переадресация после отправки (3xx)').replace('успех по коду не различим (200)', 'по коду ответа не различим (всегда 200)')
            nm = name_of(str(goal), FORM_NAME) or ('общий обработчик форм' if re.search(r'/form\.php$', str(goal)) else f"форма {re.sub(r'.*/', '', str(goal)).split('.')[0]}")
            ent = ent[[not re.match(r'^/(bitrix|local|upload|wp-\w+)/', e) for e in ent.index]]
            where = 'на страницах всех разделов' if len(ent) >= 5 else ', '.join(ent.index[:3])
            out.append(dict(форма=nm, адрес=str(goal), где=where,
                            успех=rule or 'по коду ответа', отправлено=len(hg), принято=int((hg['принята'] == 'да').sum()), ботов=int((g['группа'] == 'Боты').sum())))
    grp_ = {}
    for f in out:
        y = grp_.setdefault(f['форма'], dict(форма=f['форма'], адреса=[], где=Counter(), успех=Counter(), отправлено=0, принято=0, ботов=0))
        y['адреса'].append(f['адрес']); y['отправлено'] += f['отправлено']; y['принято'] += f['принято']; y['ботов'] += f['ботов']
        for w in (f['где'] or '').split(', '):
            if w: y['где'][w] += f['отправлено'] or 1
        y['успех'][f['успех']] += 1
    out = []
    for y in grp_.values():
        wh = [w for w, _ in y['где'].most_common()]
        out.append(dict(форма=y['форма'], адреса=y['адреса'], где='на страницах всех разделов' if 'на страницах всех разделов' in wh or len(wh) >= 5 else ', '.join(wh[:3]),
                        успех='; '.join(dict.fromkeys(y['успех'])), отправлено=y['отправлено'], принято=y['принято'], ботов=y['ботов']))
    out = sorted(out, key=lambda x: -x['отправлено'])
    nf = m.get('forms') or []
    if isinstance(nf, str):
        try: nf = eval(nf)
        except Exception: nf = []
    grp = Counter()
    for f in nf:
        if not isinstance(f, dict) or str(f.get('вывод', '')).startswith('цель'): continue
        a = str(f.get('адрес', ''))
        k = ('админка движка' if re.search(r'/bitrix/admin/|/wp-admin/|/administrator/', a) else 'загрузка файлов' if 'upload' in a
             else 'AJAX и служебные скрипты' if re.search(r'ajax|/tools/|/services/|autosave|\.php$', a) else 'отправки на главную и разделы (в основном сканеры)' if a.count('/') <= 2 else 'прочие')
        grp[k] += int(f.get('отправок', 0) or 0)
    return out, [dict(группа=k, отправок=v) for k, v in grp.most_common()]


def service_groups(m, res):
    if res.get('files'):   # полный перечень по логу (recon.files_inventory)
        from .recon import FILE_GROUPS
        g = {}
        for f in res['files']:
            x = g.setdefault(f['группа'], dict(группа=f['группа'], файлов=0, запросов=0, ошибок=0, примеры=[]))
            x['файлов'] += int(f['файлов']); x['запросов'] += int(f['запросов'])
            x['ошибок'] += sum(int(n) for k, n in re.findall(r'(\d{3}):\s*(\d+)', str(f['коды'])) if k[0] in '45' and k != '499')
            if len(x['примеры']) < 3: x['примеры'].append(f['адрес'])
        from .classify import REF
        import json as _json, os as _os
        E_ = _json.load(open(_os.path.join(REF, 'extensions.json'), encoding='utf-8'))
        order_ = [x['группа'] for x in E_.get('по_адресу', [])] + [x['группа'] for x in E_.get('группы', [])] + ['Неизвестный вид']
        return [g[k] for k in order_ if k in g] + [v for k, v in g.items() if k not in order_]
    sf = m.get('service_files') or []
    if isinstance(sf, str):
        try: sf = eval(sf)
        except Exception: sf = []
    g = {}
    for f in sf:
        if not isinstance(f, dict): continue
        a = str(f.get('адрес', ''))
        name = next((nm for nm, rx in SERVICE_GROUPS if re.search(rx, a, re.I)), 'Прочие')
        x = g.setdefault(name, dict(группа=name, файлов=0, запросов=0, ошибок=0, примеры=[]))
        x['файлов'] += 1; x['запросов'] += int(f.get('запросов', 0) or 0)
        x['ошибок'] += sum(int(n) for k, n in re.findall(r'(\d{3}):\s*(\d+)', str(f.get('коды', ''))) if k[0] in '45' and k != '499')
        if len(x['примеры']) < 3: x['примеры'].append(a)
    SV = res.get('sheets', {}).get('Ошибки', {}).get('Служебные файлы', pd.DataFrame())
    if len(SV):   # robots, sitemap и фиды — по полному листу, даже если их нет среди частых
        ok200 = set(SV.loc[SV['коды'].astype(str).str.contains(r'\b200:'), 'адрес'].astype(str))
        feeds_ = [a for a in SV['адрес'].astype(str).unique() if re.search(SERVICE_GROUPS[1][1], a, re.I) and '/.' not in a
                  and not re.search(r'config|application|database|docker|secret|credential|settings|env|compose|swagger|openapi|travis|gitlab|circleci', a, re.I)
                  and (a in ok200 and SV.loc[SV['адрес'].astype(str) == a, 'запросов'].sum() >= 20 or SV.loc[SV['адрес'].astype(str) == a, 'запросов'].sum() >= 50)]
        for a in feeds_:
            s = SV[SV['адрес'].astype(str) == a]
            x = g.setdefault('Фиды и выгрузки', dict(группа='Фиды и выгрузки', файлов=0, запросов=0, ошибок=0, примеры=[]))
            if a in x['примеры']: continue
            x['файлов'] += 1; x['запросов'] += int(s['запросов'].sum())
            x['ошибок'] += sum(int(n) for cc in s['коды'] for k, n in re.findall(r'(\d{3}):\s*(\d+)', str(cc)) if k[0] in '45' and k != '499')
            if len(x['примеры']) < 3: x['примеры'].append(a)
        for a in ('/robots.txt', '/sitemap.xml'):
            s = SV[SV['адрес'].astype(str) == a]
            if len(s) and 'Для роботов' not in g:
                g['Для роботов'] = dict(группа='Для роботов', файлов=0, запросов=0, ошибок=0, примеры=[])
            if len(s):
                x = g['Для роботов']
                if a not in x['примеры']:
                    x['файлов'] += 1; x['запросов'] += int(s['запросов'].sum()); x['примеры'].append(a)
                    x['ошибок'] += sum(int(n) for cc in s['коды'] for k, n in re.findall(r'(\d{3}):\s*(\d+)', str(cc)) if k[0] in '45' and k != '499')
    order = [nm for nm, _ in SERVICE_GROUPS] + ['Прочие']
    return [g[k] for k in order if k in g]


def embedded_groups(m):
    e = m.get('embedded_templates') or []
    if isinstance(e, str):
        try: e = eval(e)
        except Exception: e = []
    g = {}
    for x in e:
        if not isinstance(x, dict): continue
        a = str(x.get('шаблон', ''))
        name = ('Всплывающие формы' if re.search(r'form|modal|popup|callback', a, re.I) else 'Панель админки' if re.search(r'/admin/|wp-admin', a)
                else 'AJAX-блоки' if re.search(r'ajax|component', a, re.I) else 'Прочие блоки')
        y = g.setdefault(name, dict(группа=name, шаблонов=0, подгрузок=0, папка=re.sub(r'/[^/]*$', '/', a)))
        y['шаблонов'] += 1; y['подгрузок'] += int(float(x.get('запросов', 0) or 0))
    return sorted(g.values(), key=lambda y: -y['подгрузок'])


def param_groups(m, res):
    if res.get('params'):   # полный перечень по логу (recon.query_params_inventory)
        out = []
        for nm in PARAM_ORDER:
            xs = [p for p in res['params'] if p['группа'] == nm]
            if xs: out.append(dict(группа=nm, параметров=len(xs), примеры=', '.join(p['параметр'] for p in xs[:8]), применений=sum(p['запросов'] for p in xs)))
        return out
    cnt = Counter()
    for k in ('ad_params', 'other_entry_params'):
        v = m.get(k) or {}
        if isinstance(v, str):
            try: v = eval(v)
            except Exception: v = {}
        for p, n in v.items():
            if len(str(p)) >= 2: cnt[p] += int(n)
    F = res.get('query_params') if res.get('query_params') is not None else pd.DataFrame()
    if len(F):
        for p, n in F.groupby('ключ')['применений'].sum().items():
            if len(str(p)) >= 2: cnt[p] = max(cnt[p], int(n))
    g = {nm: [] for nm, _ in PARAM_GROUPS}; g['Прочие'] = []
    for p, n in cnt.most_common():
        nm = next((nm for nm, rx in PARAM_GROUPS if re.search(rx, p, re.I)), 'Прочие')
        if nm == 'Прочие' and len(p) < 4: continue   # обрывки параметров из битых адресов
        g[nm].append((p, n))
    out = []
    for nm, xs in g.items():
        if not xs: continue
        shown = []
        for p, n in xs:
            b = re.sub(r'(_\d+)+$', '_*', p)
            if b not in [s for s, _ in shown]: shown.append((b, n))
        out.append(dict(группа=nm, параметров=len(xs), примеры=', '.join(s for s, _ in shown[:8]), применений=sum(n for _, n in xs)))
    return out


def hints(pages, res, m):
    """Подсказки о тематике для Детектива: слова из адресов, рекламные фразы, кампании, формы."""
    words = Counter(w for p, v in zip(pages['адрес'], pages['визитов']) for w in re.split(r'[/_.-]+', p.lower())
                    if len(w) >= 4 and not re.fullmatch(r'[0-9a-f]+|\d+|index|php|html|filter|apply|page', w) for _ in range(1))
    MK = res.get('sheets', {}).get('Маркетинг', {})
    ph = MK.get('Реклама: Фразы', pd.DataFrame())
    kc = MK.get('Реклама: Кампании', pd.DataFrame())
    col = next((c_ for c_ in ('фраза', 'utm_term', 'term') if c_ in ph), None) if len(ph) else None
    return dict(слова_адресов=[w for w, _ in words.most_common(30)],
                рекламные_фразы=[f for f in dict.fromkeys(unquote(str(q)).split('|')[0].strip() for q in ph.sort_values(ph.columns[1], ascending=False)[col].head(40))
                                 if f and not f.startswith('---')][:20] if col else [],
                кампании=kc['кампания'].astype(str).head(10).tolist() if len(kc) and 'кампания' in kc else [])


def appendix(res):
    """Подробные таблицы к «Анатомии» — доказательства, по которым собраны сводки."""
    import re as _re
    m = res.get('site_map') or {}
    ev = lambda v: (eval(v) if isinstance(v, str) and v[:1] in '[{' else v) or []
    out = {}
    E_ = pd.DataFrame(ev(m.get('embedded_templates')))
    if len(E_):
        E_['доля_сразу_после_страницы'] = (E_['доля_сразу_после_страницы'].astype(float) * 100).round(1)
        if not res.get('embedded'): out['Анатомия — подгружаемые блоки'] = E_.rename(columns={'доля_сразу_после_страницы': 'запрошен сразу после страницы, %'})
    cnt = Counter()
    for k in ('ad_params', 'other_entry_params'):
        for p_, n_ in (ev(m.get(k)) or {}).items(): cnt[p_] += int(n_)
    Fl = res.get('query_params') if res.get('query_params') is not None else pd.DataFrame()
    if len(Fl):
        for p_, n_ in Fl.groupby('ключ')['применений'].sum().items(): cnt[p_] = max(cnt[p_], int(n_))
    if cnt and not res.get('params'):
        rows = [dict(параметр=p_, группа=next((nm for nm, rx in PARAM_GROUPS if _re.search(rx, p_, _re.I)), 'Прочие'), применений=n_) for p_, n_ in cnt.most_common() if len(str(p_)) >= 2]
        out['Анатомия — параметры'] = pd.DataFrame(rows)
    return out


GET_KINDS = [   # параметр в адресе → что это (только люди, только страницы сайта)
    ('Фильтр каталога', r'(?:^|&)(set_filter|del_filter|arrfilter\w*)='),
    ('Поиск по сайту', r'(?:^|&)(q|search|query|find|poisk)='),
    ('Форма (GET)', r'(?:^|&)(submit|send|web_form_submit|web_form_apply)='),
    ('Пагинация', r'(?:^|&)(pagen_\d+|page|p)='),
    ('Тип отображения', r'(?:^|&)(view|display|show|mode)='),
    ('Сортировка', r'(?:^|&)(sort\w*|order\w*|by)='),
]
API_KINDS = [
    ('Обмен с 1С', r'1c_exchange|commerceml|/1c[_/-]'),
    ('Вебхук', r'webhook|/hooks?/'),
    ('API', r'^/(api|rest)/|/bitrix/services/rest/|/rest/\d+/'),
]


def get_receivers(R, c, st):
    """GET: фильтры, поиск, пагинация, вид и сортировка — по параметру в адресе, только у людей и на страницах (не во вставках)."""
    qc = R['query'].cat.categories.to_series()
    base_ok = ~R['is_embedded'].values if 'is_embedded' in R else np.ones(len(R), bool)
    out = []
    for kind, rx in GET_KINDS:
        hit = qc.str.contains(rx, regex=True, case=False).values[R['query'].cat.codes.values]
        m = hit & (R['method'].values == 'GET') & c.human & base_ok & ~R['is_static'].values
        if not m.any(): continue
        Q = pd.DataFrame({'tpl': R['tpl'].values[m].astype(str), 'q': R['query'].values[m].astype(str), 'ip': R['ip'].values[m].astype(str), 'st': st[m], 'ts': R['ts'].values[m]})
        Q['ключ'] = Q['q'].str.extract(rx, flags=re.I)[0].str.lower().str.replace(r'_\d+$', '_*', regex=True)
        Q['раздел'] = Q['tpl'].map(first_seg)
        Q = Q[~Q['раздел'].str.match(r'^/(bitrix|local|upload|wp-\w+)/$')]
        for sec, g in Q.groupby('раздел'):   # одна строка на раздел и вид, параметры перечислены
            if len(g) < 10: continue
            np_ = g['tpl'].nunique()
            codes = Counter(g['st'])
            ks = [k for k, _ in Counter(g['ключ']).most_common(3)]
            sub = g['tpl'].map(lambda t: '/filter/' in t)        # вложенные страницы умного фильтра …/filter/…/apply/
            n_main = g.loc[~sub, 'tpl'].nunique()
            n_sub = g.loc[sub, 'tpl'].nunique()
            word = lambda k: 'страница' if k % 10 == 1 and k % 100 != 11 else 'страницы' if 2 <= k % 10 <= 4 and not 12 <= k % 100 <= 14 else 'страниц'
            form = lambda k, f: f[0] if k % 10 == 1 and k % 100 != 11 else f[1] if 2 <= k % 10 <= 4 and not 12 <= k % 100 <= 14 else f[2]
            ADJ_M, ADJ_F, NOUN = ('основная', 'основные', 'основных'), ('фасетная', 'фасетные', 'фасетных'), ('страница', 'страницы', 'страниц')
            where = (f"{sec}* — {n_main} {form(n_main, ADJ_M)} + {n_sub} {form(n_sub, ADJ_F)} {form(n_sub, NOUN)}" if n_sub
                     else f"{sec}* — {n_main} {form(n_main, ADJ_M)} {form(n_main, NOUN)}")   # основные — адреса структуры; фасетные — генерирует фильтр
            out.append(dict(адрес=where, метод='GET', что=kind,
                            почему=('параметр' if len(ks) == 1 else 'параметры') + ' в адресе: ' + ', '.join(ks)
                                   + ('; параметрические дубли: тот же список в другом порядке или виде' if kind in ('Пагинация', 'Сортировка', 'Тип отображения') else ''),
                            отправок=len(g), IP=g['ip'].nunique(), коды=', '.join(f'{a}:{b}' for a, b in codes.most_common(4)),
                            первый=pd.to_datetime(g['ts'].min(), unit='s'), последний=pd.to_datetime(g['ts'].max(), unit='s')))
    return sorted(out, key=lambda x: (x['что'], -x['отправок']))


def api_points(R, c, st):
    """Точки входа API и обмена (1С, CRM, вебхуки): успешные обращения не от сканеров и не от роботов-поисковиков."""
    bc = R['base'].cat.categories.to_series()
    out = []
    scan = R['fam_cat'].astype(str).isin(['Сканеры безопасности']).values if 'fam_cat' in R else np.zeros(len(R), bool)
    for kind, rx in API_KINDS:
        hit = bc.str.contains(rx, regex=True, case=False).values[R['base'].cat.codes.values]
        m = hit & (st >= 200) & (st < 300) & ~scan & ~R['is_static'].values
        if not m.any(): continue
        Q = pd.DataFrame({'b': R['base'].values[m].astype(str), 'meth': R['method'].values[m].astype(str), 'ip': R['ip'].values[m].astype(str),
                          'fam': R['fam'].values[m].astype(str), 'st': st[m], 'ts': R['ts'].values[m]})
        Q = Q[~Q['b'].str.contains(r'\.(js|css|map|png|svg)$|/\.env|/\.git', regex=True)]
        for b, g in Q.groupby('b'):
            if len(g) < 3: continue
            out.append(dict(адрес=b, метод='/'.join(sorted(set(g['meth']))), что=kind, почему='успешные обращения (2xx) не от сканеров', отправок=len(g), IP=g['ip'].nunique(),
                            коды=', '.join(f'{a}:{n}' for a, n in Counter(g['st']).most_common(3)), первый=pd.to_datetime(g['ts'].min(), unit='s'),
                            последний=pd.to_datetime(g['ts'].max(), unit='s'), кто=', '.join(f"{k or 'без подписи'}: {n}" for k, n in Counter(g['fam']).most_common(2))))
    return out



def post_profile(R):
    """Кто шлёт POST на адрес: доля браузеров, пришедших со страниц сайта, и частый хвост запроса (для «обычных страниц»)."""
    m = R['method'].values == 'POST'
    if not m.any(): return {}
    D = pd.DataFrame({'b': R['base'].values[m].astype(str), 'ok': (R['ua_browser'].values[m] & R['ref_internal'].values[m]),
                      'q': R['query'].values[m].astype(str)})
    out = {}
    for b, g in D.groupby('b'):
        if len(g) < 3: continue
        qs = g.loc[g['q'] != '', 'q'].str.split('=').str[0].value_counts()
        out[b] = dict(свои=round(float(g['ok'].mean()), 2), параметр=qs.index[0] if len(qs) else '')
    return out
