"""#22: для магазина основная конверсия — заказ: разные номера на странице успеха оформления. Пересчёты оформления, проверка подписки, кабинет и админка — не цели."""
import os
import tempfile
from datetime import timedelta

import pandas as pd

import synth
from nxld import analyze, prepare

AJAX = '/bitrix/components/bitrix/sale.order.ajax/ajax.php'
SUBSCRIBE = '/bitrix/components/bitrix/catalog.product.subscribe/ajax.php'
OK = 'https://site.ru/personal/order/make/'


def _log(shop=True, calls=(3, 7, 10, 4, 5)):
    log = synth.Log()
    for k in range(30):   # люди: движок определяется по 20 и больше IP
        ip = f'95.165.{k // 200}.{k + 1}'
        log.visit(ip, synth.T0 + timedelta(hours=8, minutes=9 * k), ref='https://yandex.ru/')
    for k in range(4):   # форма обратной связи — цель, как раньше
        ip = f'95.166.0.{k + 1}'
        t = synth.T0 + timedelta(days=1, hours=9, minutes=5 * k)
        log.visit(ip, t)
        log.line(ip, t + timedelta(seconds=100), '/contacts/send/', 200, ref='https://site.ru/contacts/', method='POST')
    if not shop: return log
    for n, calls_ in enumerate(calls, 1):   # 5 заказов: на каждый 3–10 пересчётов оформления, проверки подписки, кабинет
        ip = f'95.167.0.{n}'
        t = synth.T0 + timedelta(days=2, hours=10, minutes=20 * n)
        log.visit(ip, t)
        for j in range(calls_): log.line(ip, t + timedelta(seconds=60 + 3 * j), AJAX, 200, ref='https://site.ru/personal/order/make/', method='POST')
        log.line(ip, t + timedelta(seconds=40), SUBSCRIBE, 200, ref='https://site.ru/catalog/', method='POST')
        log.line(ip, t + timedelta(seconds=400), f'/personal/order/make/?ORDER_ID={1000 + n}', 200, ref='https://site.ru/personal/order/make/')
        log.line(ip, t + timedelta(seconds=460), f'/personal/order/make/?ORDER_ID={1000 + n}', 200, ref='https://site.ru/personal/order/make/')   # обновил страницу успеха
        log.line(ip, t + timedelta(seconds=520), '/personal/order/', 200, ref='https://site.ru/', method='POST')   # кабинет
    return log


def _prepare(log):
    with tempfile.TemporaryDirectory() as d:
        path, work = os.path.join(d, 'access.log'), os.path.join(d, 'work')
        log.write(path)
        prepare.run([path], work, log=lambda *a: None)
        return pd.read_pickle(os.path.join(work, 'R.pkl')), pd.read_pickle(os.path.join(work, 'V.pkl'))


def test_orders_counted_by_number():
    R, V = _prepare(_log())
    g = R['goal'].astype(str)
    assert int(R['is_order'].sum()) == 5   # пять номеров, обновление страницы успеха не считается
    assert int((g == '/contacts/send/').sum()) == 4 and int(g.str.contains('sale.order.ajax|subscribe|/personal/order/$|admin', regex=True).sum()) == 0   # форма — цель; шаги, подписка, кабинет — нет
    assert int(R['goal_success'].sum()) == 9   # 5 заказов + 4 заявки
    assert int(V['n_conv'].sum()) == 9 and int(V['n_goal'].sum()) == 9
    assert int(R['order_step'].sum()) == 3 + 7 + 10 + 4 + 5   # шаги оформления отмечены для карточки о потерянных заявках


def test_order_counted_once_in_first_visit():
    log = _log(calls=(3,) * 5)
    ip = '95.167.0.1'
    log.line(ip, synth.T0 + timedelta(days=5, hours=10), '/personal/order/make/?ORDER_ID=1001', 200, ref='-')   # позже тот же номер из другого визита
    R, V = _prepare(log)
    assert int(R['is_order'].sum()) == 5
    first = R.loc[R['is_order'], 'vid']
    assert first.is_unique   # по заказу — свой визит, номер в позднем визите не посчитан


def test_shop_without_orders_and_forms_as_before():
    """Сайт без магазина: нет страниц успеха заказа — цели только по формам, как раньше."""
    R, V = _prepare(_log(shop=False))
    assert int(R['is_order'].sum()) == 0 and int(R['goal_success'].sum()) == 4 and int(V['n_conv'].sum()) == 4


def test_analyze_accepted_count_follows_orders(monkeypatch):
    monkeypatch.setenv('NXLD_STRICT_CATALOG', '1')
    with tempfile.TemporaryDirectory() as d:
        path, work = os.path.join(d, 'access.log'), os.path.join(d, 'work')
        _log().write(path)
        prepare.run([path], work, log=lambda *a: None)
        res = analyze.run(work, log=lambda *a: None)
        s = res['summary']['Общий анализ']
        assert s['Принято от людей'] == 9 and s['Отправок целей всего'] == 9, s


def _lost_log(win_ok=True):
    """3 ошибки 504 на оформлении, после двух — заказ в течение часа; третий покупатель заказа не оформил."""
    log = _log(calls=(3, 3, 3, 3, 3))
    for k in range(3):
        ip = f'95.168.0.{k + 1}'
        t = synth.T0 + timedelta(days=3, hours=10, minutes=30 * k)
        log.visit(ip, t)
        log.line(ip, t + timedelta(seconds=60), AJAX, 504, ref='https://site.ru/personal/order/make/', method='POST')
        if k < 2: log.line(ip, t + timedelta(minutes=40), f'/personal/order/make/?ORDER_ID={2000 + k}', 200, ref='https://site.ru/personal/order/make/')
    return log


def _card(log, monkeypatch):
    monkeypatch.setenv('NXLD_STRICT_CATALOG', '1')
    with tempfile.TemporaryDirectory() as d:
        path, work = os.path.join(d, 'access.log'), os.path.join(d, 'work')
        log.write(path)
        prepare.run([path], work, log=lambda *a: None)
        res = analyze.run(work, log=lambda *a: None)
        return [x for x in res['findings'] if x['key'].split(':')[1] == 'lost_leads']


def test_lost_leads_two_numbers_main_is_without_order(monkeypatch):
    card = _card(_lost_log(), monkeypatch)
    assert len(card) == 1, card
    c0 = card[0]
    assert c0['главная_цифра'] == 1   # потеряно 1 из 3
    assert 'Ошибок всего 3, из них закончились заказом 2, без заказа 1' in c0['факты'], c0['факты']


def test_lost_leads_all_ended_with_orders_no_card(monkeypatch):
    log = _log(calls=(3,) * 5)
    for k in range(2):
        ip = f'95.168.0.{k + 1}'
        t = synth.T0 + timedelta(days=3, hours=10, minutes=30 * k)
        log.visit(ip, t)
        log.line(ip, t + timedelta(seconds=60), AJAX, 504, ref='https://site.ru/personal/order/make/', method='POST')
        log.line(ip, t + timedelta(minutes=50), f'/personal/order/make/?ORDER_ID={3000 + k}', 200, ref='https://site.ru/personal/order/make/')
    assert _card(log, monkeypatch) == []


def test_lost_leads_forms_without_number_as_before(monkeypatch):
    log = _log(shop=False)
    for k in range(2):   # форма обратной связи отвечает ошибкой, номера нет — потеря, как раньше
        ip = f'95.169.0.{k + 1}'
        t = synth.T0 + timedelta(days=3, hours=10, minutes=30 * k)
        log.visit(ip, t)
        log.line(ip, t + timedelta(seconds=60), '/contacts/send/', 500, ref='https://site.ru/contacts/', method='POST')
    card = _card(log, monkeypatch)
    assert len(card) == 1 and card[0]['главная_цифра'] == 2 and 'Ошибок всего' not in card[0]['факты']


def test_order_with_error_on_success_page_counted_and_flagged(monkeypatch):
    """B1: номер заказа на странице успеха с ответом 403 — заказ засчитан, есть карточка с кодом."""
    monkeypatch.setenv('NXLD_STRICT_CATALOG', '1')
    log = _log()
    ip = '95.167.0.9'
    t = synth.T0 + timedelta(days=2, hours=15)
    log.visit(ip, t)
    log.line(ip, t + timedelta(seconds=400), '/personal/order/make/?ORDER_ID=1999', 403, ref='https://site.ru/personal/order/make/')
    with tempfile.TemporaryDirectory() as d:
        path, work = os.path.join(d, 'access.log'), os.path.join(d, 'work')
        log.write(path)
        prepare.run([path], work, log=lambda *a: None)
        assert int(pd.read_pickle(os.path.join(work, 'R.pkl'))['is_order'].sum()) == 6
        res = analyze.run(work, log=lambda *a: None)
    card = [x for x in res['findings'] if x['key'].split(':')[1] == 'order_page_error']
    assert len(card) == 1 and '403 (1)' in card[0]['факты'] and 'из 6' in card[0]['факты'], card
    import re
    assert re.search(r'Первый — \d\d\.\d\d\.\d{4} \d\d:\d\d', card[0]['факты']), card[0]['факты']   # время — дата, а не секунды эпохи
    # заказ создан — это не потерянная заявка: в «потерянных» его нет
    assert not [x for x in res['findings'] if x['key'].split(':')[1] == 'lost_leads'], [x['факты'] for x in res['findings'] if 'lost_leads' in x['key']]


def test_no_error_card_when_success_page_ok(monkeypatch):
    monkeypatch.setenv('NXLD_STRICT_CATALOG', '1')
    with tempfile.TemporaryDirectory() as d:
        path, work = os.path.join(d, 'access.log'), os.path.join(d, 'work')
        _log().write(path)
        prepare.run([path], work, log=lambda *a: None)
        res = analyze.run(work, log=lambda *a: None)
    assert not [x for x in res['findings'] if x['key'].split(':')[1] == 'order_page_error']


def _funnel_log():
    """Магазин: 5 заказов, 8 корзин (5 с заказом и 3 без), оформление в тех же 8 визитах; 25 визитов с действием «в корзину» (17 просто смотрят каталог + 8 дошли до корзины), ещё 60 визитов без корзины."""
    log = _log()
    for k in range(60):
        log.visit(f'95.170.{k // 200}.{k + 1}', synth.T0 + timedelta(days=1, hours=11, minutes=7 * k), ref='https://yandex.ru/')
    def act(ip, t, k): log.line(ip, t, '/catalog/add/', 200, ref=f'https://site.ru/catalog/p{k}/', method='POST')
    for k in range(17): act(f'95.165.0.{k + 1}', synth.T0 + timedelta(hours=8, minutes=9 * k, seconds=30), k)
    for n in range(1, 6):   # все 5 заказов прошли корзину (с 3 ниже — 8 корзин) и оформление
        ip, t = f'95.167.0.{n}', synth.T0 + timedelta(days=2, hours=10, minutes=20 * n)
        act(ip, t + timedelta(seconds=10), 16 + n)
        log.line(ip, t + timedelta(seconds=20), '/personal/cart/', 200, ref='https://site.ru/catalog/')
        log.line(ip, t + timedelta(seconds=30), '/personal/order/make/', 200, ref='https://site.ru/personal/cart/')
    for k in range(3):   # корзина и оформление без заказа
        ip, t = f'95.168.0.{k + 1}', synth.T0 + timedelta(days=3, hours=10, minutes=20 * k)
        log.visit(ip, t)
        act(ip, t + timedelta(seconds=10), 22 + k)
        log.line(ip, t + timedelta(seconds=20), '/personal/cart/', 200, ref='https://site.ru/catalog/')
        log.line(ip, t + timedelta(seconds=30), '/personal/order/make/', 200, ref='https://site.ru/personal/cart/')
    return log


def test_order_funnel_steps(monkeypatch):
    """B2: 5 заказов, 8 корзин, 3 визита с оформлением без заказа → числа шагов воронки."""
    monkeypatch.setenv('NXLD_STRICT_CATALOG', '1')
    with tempfile.TemporaryDirectory() as d:
        path, work = os.path.join(d, 'access.log'), os.path.join(d, 'work')
        _funnel_log().write(path)
        prepare.run([path], work, log=lambda *a: None)
        res = analyze.run(work, log=lambda *a: None)
    of = res['sheets']['Маркетинг']['Воронка заказа']
    st = dict(of['шаги'])
    assert st['order'] == 5 and st['cart'] == 8 and st['checkout'] == 8 and st['action'] == 25, st
    assert st['people'] >= 100 and of['заказ_через_корзину'] == 5 and of['действия_определены']


def test_order_funnel_absent_without_shop(monkeypatch):
    monkeypatch.setenv('NXLD_STRICT_CATALOG', '1')
    with tempfile.TemporaryDirectory() as d:
        path, work = os.path.join(d, 'access.log'), os.path.join(d, 'work')
        _log(shop=False).write(path)
        prepare.run([path], work, log=lambda *a: None)
        res = analyze.run(work, log=lambda *a: None)
    assert res['sheets']['Маркетинг']['Воронка заказа'] is None


def test_order_funnel_on_funnels_sheet(tmp_path):
    """B2: на листе «Воронки» файла 05 — воронка заказа с подписями из data/locale/ru/funnel.json и примечанием; строк «Заказ» среди форм нет."""
    import glob
    import openpyxl
    _, out, _ = synth.run(_funnel_log(), str(tmp_path))
    f = glob.glob(os.path.join(out, 'NXLD_05*.xlsx'))[0]
    ws = openpyxl.load_workbook(f)['Воронки']
    cells = [(c.row, c.value) for row in ws.iter_rows() for c in row if c.value is not None]
    texts_ = [str(v) for _, v in cells]
    assert 'ВОРОНКА ЗАКАЗА' in texts_
    for lab in ('Визиты людей', 'Действия с товаром', 'Корзина', 'Оформление', 'Заказ'): assert lab in texts_, lab
    row = {v: r for r, v in cells if v in ('Корзина', 'Оформление', 'Заказ')}
    vals = {k: [c.value for c in ws[row[k]] if c.value is not None] for k in row}
    assert vals['Корзина'][1:3] == [8, vals['Корзина'][2]] and vals['Оформление'][1] == 8 and vals['Заказ'][1] == 5 and vals['Заказ'][2] == round(5 / 8 * 100, 1), vals
    assert any('Через корзину прошли 5 из 5 визитов с заказом.' in t for t in texts_), [t for t in texts_ if 'корзин' in t]
    assert not any('/personal/order/make/?ORDER_ID' in t for t in texts_)   # строка цели «Заказ» среди форм заменена воронкой


def _custom_cart_log():
    """Свой обработчик действий с товаром у шаблона (/include/actions.php, вызовы с 3 страниц — по поведению не определить) и своя корзина (/basket/)."""
    log = _log()
    for k in range(12):
        ip = f'95.165.0.{k + 1}'
        log.line(ip, synth.T0 + timedelta(hours=8, minutes=9 * k, seconds=30), '/include/actions.php', 200, ref=f'https://site.ru/catalog/p{k % 3}/', method='POST')
    for n in range(1, 4):
        ip, t = f'95.167.0.{n}', synth.T0 + timedelta(days=2, hours=10, minutes=20 * n)
        log.line(ip, t + timedelta(seconds=20), '/basket/', 200, ref='https://site.ru/catalog/')
    return log


def _funnel_with(log, override, monkeypatch):
    monkeypatch.setenv('NXLD_STRICT_CATALOG', '1')
    with tempfile.TemporaryDirectory() as d:
        path, work = os.path.join(d, 'access.log'), os.path.join(d, 'work')
        log.write(path)
        prepare.run([path], work, log=lambda *a: None, map_override=override)
        res = analyze.run(work, log=lambda *a: None)
        import json
        brief = json.load(open(os.path.join(work, 'brief.json')))
    return res['sheets']['Маркетинг']['Воронка заказа'], brief


def test_funnel_site_handler_and_cart_from_map_override(monkeypatch):
    """Свой обработчик действий и своя корзина — из поправок карты (product_action, cart_pages), а не из справочника движка."""
    of, _ = _funnel_with(_custom_cart_log(), {'product_action': ['^/include/actions\\.php$'], 'cart_pages': ['^/basket/']}, monkeypatch)
    st = dict(of['шаги'])
    assert st['action'] == 12 and st['cart'] == 3 and of['действия_определены'] and of['заказ_через_корзину'] == 3, of


def test_funnel_undetermined_handler_hint_in_brief(monkeypatch):
    """Обработчик действий не определён — шага нет, в выжимке подсказка указать его в поправках карты."""
    of, brief = _funnel_with(_custom_cart_log(), None, monkeypatch)
    assert 'action' not in dict(of['шаги']) and not of['действия_определены']
    assert any('product_action' in t for t in json_caveats(brief)), brief


def json_caveats(brief):
    import json
    return [t for t in json.dumps(brief, ensure_ascii=False).split('"') if 'product_action' in t]
