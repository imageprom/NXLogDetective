"""NXLD: файл 03 «Нагрузка и безопасность» — по тем же правилам, что 01 и 02.

Обзор (шапка с логотипом, плашка тревог, ключевые цифры, блоки безопасности и нагрузки) → Проблемы → Статистика →
важные срезы (безопасность и нагрузка вперемешку, по важности) → подробные списки в конце.
Данные — security.build (на общих расчётах common), оформление — общие модули report_tables и report_index."""
from . import sheets
from .catalog import order as catalog_order
import pandas as pd
from openpyxl.styles import Font
from .report_index import Wide, brand_header, GREY, F_NOTE, ORANGE
from .report_tables import first_heading, data_sheet, journal_sheet, legend, heat_sheet, extra_table, post_all, _day, header_groups, fit_widths
from .report_activity import size
from .report_tables import split_codes


def fmt_raw(v):
    """«404:1232, 301:860» — как есть (split_codes понимает и «404 (1 232)», и «404:1232»)."""
    return v

F_GREY = 'EFEFEF'
# старые имена листов в карточках → новые
LINK = sheets.LINK_03
KEEP = ('Исследователи сайта', 'Подозрительные файлы')   # листы расчёта, которые идут в файл как есть (GET — под новым именем)


def relink(findings):
    for x in findings:
        if x.get('блок') == 'Нагрузка и безопасность' and x.get('лист') in LINK: x['лист'] = LINK[x['лист']]


def sheets_for(S):
    """Что пишется в файл из расчётов блока: только листы без своей вёрстки; остальные строит build."""
    return {k: v for k, v in S.items() if k in KEEP}


def _d(v):
    try: return pd.to_datetime(v).strftime('%d.%m.%Y')
    except Exception: return str(v or '')


from .report_tables import notes, notes_of, legend_of   # примечания и легенда — общие, тексты из каталога (#11)


def _ok(X, k):
    v = X.get(k)
    return v is not None and (len(v) if not isinstance(v, dict) else True)


def overlap_note(H):
    """Заметка о пересечении нагрузок — вывод готовит движок (derive.overlap_text)."""
    if not H: return ''
    if H.get('вывод'): return 'Куда смотреть: ' + H['вывод']
    if H.get('_пересечение') is None or not len(H['_пересечение']): return ''
    X = H['_пересечение']
    top = ', '.join(f"{_day(r['d'])} {int(r['h']):02d}:00" for _, r in X.head(3).iterrows())
    b, o = H.get('_499_обычно') or 0, H.get('_499_в_пересечении')
    tail = ''
    if o is not None and b:
        k = o / b
        tail = (f' В эти часы люди уходили, не дождавшись ответа (499), в {k:.1f} раза чаще обычного — сервер не справляется с общей нагрузкой.'.replace('.', ',', 1) if k >= 1.3
                else ' Обрывов 499 у людей в эти часы не больше обычного — сервер справляется.')
    return f'Куда смотреть: часы, где много и людей, и роботов с ботами, — {top}.{tail}'


def build_sheets(wb, res, S):
    X = res.get('security') or {}
    E = res.get('errors') or {}
    names = set()
    # ---- Статистика ----
    J = X.get('журнал')
    if J is not None and len(J):
        if 'Статистика' not in wb.sheetnames: wb.create_sheet('Статистика')
        def kpi(body):
            full = body[body['_полный'].astype(bool)] if body['_полный'].astype(bool).any() else body
            return [('Запросов в день', int(round(full['Запросов|Все'].mean()))), ('Пик в минуту', int(body['Пик|В минуту'].max())),
                    ('Находок сканеров', int(body['Сканеры|Находок'].sum()))]
        journal_sheet(wb, 'Статистика', J, kpi, kpi_col='Запросов|Боты', outages=E.get('сбои'))
        names.add('Статистика')
    # ---- Служебные данные: утечки, служебные разделы, токены ----
    L, Z, Tk = X.get('утечки'), X.get('разделы'), X.get('токены')
    from .report_tables import fmt_codes
    nm = 'Служебные данные'
    parts = [k for k, v in (('утечки', L), ('разделы', Z), ('токены', Tk)) if v is not None and len(v)]
    from .catalog import K
    code_ = {'утечки': 'leaks', 'разделы': 'sections', 'токены': 'tokens'}
    parts = sorted(parts, key=lambda k: K(nm).order(list(code_.values())).index(code_[k]))   # порядок таблиц — из каталога
    if parts:
        if nm not in wb.sheetnames: wb.create_sheet(nm)
        def leaks_df():
            return pd.DataFrame({'Файл': L['файл'], 'Отдан раз': L['отдан_раз'], 'Уникальных IP': L['IP'], 'Размер ответа, байт': L['размер'],
                                 'История': L['история'], 'Последний ответ': L['последний_ответ'], 'Проверка из сети': L['проверка'], 'Что внутри': L['внутри'],
                                 'Первый': L['первый'].map(_d), 'Последний': L['последний'].map(_d)})
        def sections_df():
            seen = Z['кто_без_входа'].astype(str).str.replace(r' — (\d+)', r' (\1)', regex=True)   # подписи роботов — из движка (blocks.FAM_LABEL)
            return pd.DataFrame({'Раздел': Z['раздел'], 'Настоящий': Z['настоящий'].map({True: 'да', False: 'нет'}), 'Запросов': Z.get('запросов', Z['IP']).astype(int),
                                 'Уникальных': Z['IP'].astype(int), 'С кодом 200': Z['IP_с_200'].astype(int), 'Ответов 200': Z['ответов_200'].astype(int),
                                 'Поисковики': Z['поисковики'].astype(int), 'Форма входа': Z['форма_входа'], 'Попыток входа': Z['POST_входов'].astype(int),
                                 'Неудачных': Z['неудачных'].astype(int), 'Подбирали пароль (IP)': Z['подбор_IP'].astype(int), 'Вошли (IP)': Z['адресов_вошло'].astype(int),
                                 'Страниц': Z['внутренних_без_входа'].astype(int), 'Страницы': Z['страницы_без_входа'], 'Опознание': seen,
                                 'Ответы': Z['коды'].map(lambda v: split_codes(fmt_raw(v))[0]) if 'коды' in Z else '',
                                 'Ошибки': Z['коды'].map(lambda v: split_codes(fmt_raw(v))[1]) if 'коды' in Z else '',
                                 'Первый': Z['первый'].map(_d) if 'первый' in Z else '', 'Последний': Z['последний'].map(_d)})
        def tokens_df():
            return pd.DataFrame({'Адрес': Tk['b'], 'Параметр': Tk['p'], 'Запросов': Tk['запросов'].astype(int), 'Свои': Tk['свои'].astype(int), 'Посторонние': Tk['посторонние'].astype(int),
                                 'Поисковики': Tk['поисковики'].astype(int), 'Первый': Tk['первый'], 'Последний': Tk['последний']})
        sec_fill = lambda: [F_GREY if not real else (F_NOTE if op > 0 else None) for real, op in zip(Z['настоящий'], Z['внутренних_без_входа'])]
        tok_fill = lambda: [F_NOTE if o > 0 else F_GREY for o in Tk['посторонние']]
        kpi = [('Утечек', len(L) if L is not None else 0), ('Разделов', len(Z) if Z is not None else 0), ('Токенов', len(Tk) if Tk is not None else 0)]
        first = parts[0]
        T1 = {'утечки': ('leaks', leaks_df, lambda: [F_NOTE] * len(L)), 'разделы': ('sections', sections_df, sec_fill),
              'токены': ('tokens', tokens_df, tok_fill)}   # код блока в каталоге: заголовок таблицы, примечания, легенда
        t0, f0, r0 = T1[first]
        data_sheet(wb, nm, f0(), None, wrap=('Файл', 'История', 'Что внутри', 'Страницы', 'Опознание', 'Ответы', 'Ошибки', 'Адрес'),
                   kpi=kpi, row_rule=lambda r, _it=iter(r0()): next(_it), red=('Ошибки',))
        ws = wb[nm]
        first_heading(ws, t0)   # заголовок первой таблицы — над шапкой, без сдвига строк
        ws.freeze_panes = None
        leg_ = {'утечки': ['утечка'], 'разделы': ['открыто', 'ложный'], 'токены': ['посторонние', 'свои_норма']}
        notes_of(ws, t0); legend_of(ws, leg_[first], t0)
        GRP = {'разделы': {'IP': ['Уникальных', 'С кодом 200'], 'Вход': ['Форма входа', 'Попыток входа', 'Неудачных', 'Подбирали пароль (IP)', 'Вошли (IP)'],
                           'Без входа': ['Страниц', 'Страницы', 'Опознание']}}
        for k in parts[1:]:
            t_, f_, r_ = T1[k]
            fills = r_()
            extra_table(ws, f_(), t_, wrap=('Файл', 'История', 'Что внутри', 'Страницы', 'Опознание', 'Ответы', 'Ошибки', 'Адрес'),
                        row_rule=lambda r, _it=iter(fills): next(_it), groups=GRP.get(k))
            notes_of(ws, t_); legend_of(ws, leg_[k], t_)
        fit_widths(ws, start_row=5, hi=40)
        names.add(nm)
    # ---- Админка: люди и программы ----
    A = X.get('админка')
    if A is not None and len(A):
        nm = 'Админка'
        if nm not in wb.sheetnames: wb.create_sheet(nm)
        mk = lambda D: pd.DataFrame({'IP': D['ip'], 'Кто': D['кто'], 'Сеть': D['org'].fillna('').astype(str), 'Страна': D['страна'],
                                      'Запросов': D['запросов'].astype(int), 'Успешных': D['успешных_200'].astype(int), 'POST': D['POST'].astype(int), 'Дней': D['дней'].astype(int),
                                      'Первый визит': D['первый'], 'Последний визит': D['последний']})
        Hm, Pg = A[A['живой']], A[~A['живой']]
        fills = [F_GREY if st_ else F_NOTE for st_ in Hm['сотрудник']]
        data_sheet(wb, nm, mk(Hm), {'IP': 16, 'Кто': 34, 'Сеть': 30, 'Первый визит': 16, 'Последний визит': 16},
                   wrap=('Кто', 'Сеть'), center=('Страна',), kpi=[('Сотрудников', int(A['сотрудник'].sum())), ('Посторонних людей', int((A['живой'] & ~A['сотрудник']).sum())), ('Роботов и ботов', len(Pg))],
                   kpi_col='Запросов', row_rule=lambda r, _it=iter(fills): next(_it), red=())
        ws = wb[nm]
        first_heading(ws, 'main')   # заголовок первой таблицы — над шапкой, без сдвига строк
        notes_of(ws)
        legend_of(ws, ['сотрудник', 'посторонний'])
        if len(Pg):
            extra_table(ws, mk(Pg), 'robots_bots', wrap=('Кто', 'Сеть'))
        names.add(nm)
    # ---- Всплески ----
    B = X.get('всплески')
    if B is not None and len(B):
        nm = 'Всплески нагрузки'
        if nm not in wb.sheetnames: wb.create_sheet(nm)
        d = pd.DataFrame({'Всплеск': B['всплеск'], 'Начало': B['начало'], 'Конец': B['конец'], 'Длительность (мин)': B['минут'].astype(int), 'Запросов': B['запросов'].astype(int),
                          'Пик в минуту': B['пик_в_минуту'].astype(int), 'В норме': B['в_норме'].astype(int), 'Уникальных IP': B['IP'].astype(int), 'Сетей': B['сетей'].astype(int),
                          'Картина': B['картина'], 'Главный IP': B['главный_IP'], 'Кто главный': B['кто_главный'], 'Виновник': B['кто'], 'Цели': B['что_били'],
                          'Ответы': B['ответы'], 'Ошибки': B['ошибки'], 'Отказы сервера': B['отказы'].astype(int), 'Последствия': B['последствия']})
        bad = [(not p.startswith('наплыв людей')) or (q != 'не видно') for p, q in zip(B['картина'], B['последствия'])]
        data_sheet(wb, nm, d, {'Начало': 16, 'Конец': 16, 'Картина': 34, 'Главный IP': 22, 'Кто главный': 28, 'Виновник': 30, 'Цели': 44, 'Ответы': 26, 'Ошибки': 20, 'Последствия': 24},
                   wrap=('Картина', 'Кто главный', 'Виновник', 'Цели', 'Ответы', 'Ошибки', 'Последствия'), kpi=[('Всплесков', len(d)), ('От роботов и ботов', int(sum(not p.startswith('наплыв людей') for p in B['картина'])))], kpi_col='В норме',
                   row_rule=lambda r, _it=iter(bad): F_NOTE if next(_it) else None, red=('Ошибки',))
        notes_of(wb[nm])
        legend_of(wb[nm], ['всплеск', 'обычно'])
        names.add(nm)
    # ---- Источники нагрузки и каналы людей ----
    Q = X.get('источники')
    if Q is not None and len(Q):
        nm = 'Источники нагрузки'
        if nm not in wb.sheetnames: wb.create_sheet(nm)
        Q = Q.head(300)
        d = pd.DataFrame({'Категория': Q['категория'], 'Тип': Q['тип'].replace('', '—'), 'Подозреваемый': Q['подозреваемый'], 'Запросов': Q['запросов'].astype(int),
                          'Страниц': Q['страниц'].astype(int), 'Трафик': Q['байт'].map(size), 'Трафик (%)': Q['трафик_%'].round(2), 'Макс. в мин.': Q['максимум'].astype(int)})
        data_sheet(wb, nm, d, {'Категория': 22, 'Тип': 34, 'Подозреваемый': 30},
                   wrap=('Категория', 'Тип', 'Подозреваемый'), kpi=[('Источников', len(X['источники']))], kpi_col='Трафик', red=())
        notes_of(wb[nm])
        Ch = X.get('каналы')
        if Ch is not None and len(Ch):
            extra_table(wb[nm], pd.DataFrame({'Канал': Ch['канал'], 'Запросов': Ch['запросов'].astype(int), 'Страниц': Ch['страниц'].astype(int), 'Трафик': Ch['байт'].map(size),
                                              'Трафик (%)': Ch['трафик_%'].round(2), 'Макс. стр. в мин.': Ch['макс'].astype(int)}),
                        'people_channels', wrap=('Канал',))   # длинное имя канала — на две колонки
        names.add(nm)
    # ---- Нагрузка по часам ----
    H = X.get('часы')
    if H:
        note = overlap_note(H)
        heat_sheet(wb, 'Нагрузка по часам', [('all', H.get('Все')), ('people', H.get('Люди')), ('robots', H.get('Роботы')), ('bots', H.get('Боты'))], overlap=note)
        names.add('Нагрузка по часам')
    # ---- Серверный фильтр ----
    if filter_sheet(wb, X.get('фильтр')) is not None: names.add('Серверный фильтр')
    # ---- Сканеры ----
    sc = X.get('сканеры')
    if sc is not None and sc[0] is not None and len(sc[0]):
        T, I = sc
        nm = 'Сканеры'
        if nm not in wb.sheetnames: wb.create_sheet(nm)
        d = pd.DataFrame({'Цель': T['цель'], 'Попыток': T['запросов'].astype(int), 'Уникальных': T['IP'].astype(int), 'С кодом 200': T['IP_с_200'].astype(int),
                          'Всего': T['отдано_200'].astype(int), 'Обычных страниц': T['страницы_сайта'].astype(int), 'Заглушки и формы входа': T['заглушки'].astype(int),
                          'Находки': T['находки'].astype(int), 'Добыча': T['что_отдано'], 'Ответы': T['ответы'], 'Ошибки': T['ошибки']})
        fills = [F_NOTE if f > 0 else (F_GREY if o > 0 else None) for f, o in zip(T['находки'], T['отдано_200'])]
        data_sheet(wb, nm, d, {'Цель': 30, 'Добыча': 44, 'Ответы': 30, 'Ошибки': 30, 'Обычных страниц': 11, 'Заглушки и формы входа': 13, 'Находки': 10},
                   wrap=('Цель', 'Добыча', 'Ответы', 'Ошибки'), kpi=[('Попыток', int(d['Попыток'].sum())), ('Находок', int(d['Находки'].sum()))], kpi_col='Всего',
                   row_rule=lambda r, _it=iter(fills): next(_it), red=('Ошибки',))
        header_groups(wb[nm], {'IP': ['Уникальных', 'С кодом 200'], 'Ответ 200': ['Всего', 'Обычных страниц', 'Заглушки и формы входа', 'Находки'],
                               'Ответы сервера': ['Ответы', 'Ошибки']})
        notes_of(wb[nm])
        legend_of(wb[nm], ['находка', 'ответ_200'])
        F_ = I[I['находок'] > 0]
        if len(F_):
            # колонки подряд, длинные — на широкие колонки первой таблицы (B — «Цель»), чтобы не было разрывов
            extra_table(wb[nm], pd.DataFrame({'Фигурант': F_['кто'], 'IP': F_['ip'], 'Страна': F_['страна'].fillna(''), 'Находок': F_['находок'].astype(int),
                                              'Попыток': F_['запросов'].astype(int), 'Первый': F_['первый'].map(_d), 'Последний': F_['последний'].map(_d), 'Сеть': F_['сеть'].fillna('')}),
                        'ips_found', wrap=('Фигурант', 'Сеть'))
            wb[nm].column_dimensions['C'].width = 16; wb[nm].column_dimensions['I'].width = 24
        names.add(nm)
    # ---- Методы ----
    M = X.get('методы')
    if M is not None and M[0] is not None and len(M[0]):
        T, Raw = M
        nm = 'Методы и протоколы'
        if nm not in wb.sheetnames: wb.create_sheet(nm)
        d = pd.DataFrame({'Метод': T['метод'], 'Опознание': T['что'], 'Запросов': T['запросов'].astype(int), 'Уникальных IP': T['IP'].astype(int), 'Куда': T['куда'],
                          'Ответы': T['ответы'], 'Ошибки': T['ошибки'], 'Принято (2xx)': T['принято'].astype(int), 'Первый': T['первый'], 'Последний': T['последний']})
        usual = T['метод'].isin(['GET', 'POST', 'HEAD'])
        fills = [None if u else (F_NOTE if a > 0 else None) for u, a in zip(usual, T['принято'])]
        data_sheet(wb, nm, d, {'Метод': 22, 'Опознание': 40, 'Куда': 40, 'Ответы': 30, 'Ошибки': 26, 'Первый': 16, 'Последний': 16},
                   wrap=('Опознание', 'Куда', 'Ответы', 'Ошибки'), kpi=[('Методов', len(d)), ('Необычных запросов', int(T.loc[~usual, 'запросов'].sum()))], kpi_col='Принято (2xx)',
                   row_rule=lambda r, _it=iter(fills): next(_it), red=('Ошибки',))
        notes_of(wb[nm])
        legend_of(wb[nm], ['принято', 'обычно'])
        names.add(nm)
        if len(Raw):
            nm2 = 'Необычные запросы'
            if nm2 not in wb.sheetnames: wb.create_sheet(nm2)
            Raw = Raw.head(20000)
            d2 = pd.DataFrame({'Время': Raw['время'], 'IP': Raw['ip'], 'Фигурант': Raw['кто'], 'Метод': Raw['метод'], 'Опознание': Raw['опознание'], 'Адрес': Raw['адрес'],
                               'Код': Raw['код'].astype(int), 'User-Agent': Raw['user_agent']})
            data_sheet(wb, nm2, d2, {'Время': 16, 'IP': 16, 'Фигурант': 30, 'Метод': 16, 'Опознание': 40, 'Адрес': 40, 'User-Agent': 46},
                       wrap=('Фигурант', 'Опознание', 'Адрес', 'User-Agent'), center=('Код',), red=())
            notes_of(wb[nm2])
            names.add(nm2)
    # ---- POST и GET — из реестра точек приёма ----
    from .report_tables import method_all
    for m_ in ('POST', 'GET'):
        if method_all(wb, res, m_, after='Методы и протоколы') is not None: names.add(m_)
    # ---- Конструкты ----
    K = X.get('конструкты')
    if K is not None and len(K):
        nm = 'Конструкты'
        if nm not in wb.sheetnames: wb.create_sheet(nm)
        sp = K['коды'].map(lambda v: split_codes(v))
        d = pd.DataFrame({'Адрес': K['адрес'], 'Вид': K['вид'], 'Запросов': K['запросов'].astype(int), 'Уникальных IP': K['IP'].astype(int), 'Люди': K['люди'].astype(int),
                          'Роботы': K['роботы'].astype(int), 'Запросов с сайта': K['со_страниц_сайта'].astype(int), 'Ответы': sp.str[0], 'Ошибки': sp.str[1],
                          'Последний': K['последний'].map(_d), 'Вывод': K['вывод']})
        data_sheet(wb, nm, d, {'Адрес': 50, 'Вид': 22, 'Ответы': 22, 'Ошибки': 22, 'Вывод': 40},
                   wrap=('Адрес', 'Ответы', 'Ошибки', 'Вывод'), kpi=[('Адресов', len(d)), ('С ответом 200', int(K['опасно'].sum()))], kpi_col='Люди',
                   row_rule=lambda r, _it=iter(list(K['опасно'])): F_NOTE if next(_it) else None, red=('Ошибки',))
        notes_of(wb[nm])
        legend_of(wb[nm], ['подозрительно', 'обычно'])
        names.add(nm)
    # ---- Паразитные адреса — только в 06 «SEO» (каталог #8: запасных мест SEO-листов в 02–05 нет) ----
    # ---- Файловый трафик: виды файлов и внешнее встраивание ----
    Ft = X.get('типы_файлов')
    Em = X.get('встраивание')
    if Ft is not None and len(Ft):
        nm = 'Файловый трафик'
        if nm not in wb.sheetnames: wb.create_sheet(nm)
        d = pd.DataFrame({'Группа': Ft['группа'].replace('', '—'), 'Расширение': Ft['расширение'], 'Запросов': Ft['запросов'].astype(int), 'Трафик': Ft['байт'].map(size),
                          'Трафик (%)': Ft['трафик_%'].round(2), 'Средний размер': Ft['средний'].map(size), 'Из кэша (304), %': (Ft['кэш'] * 100).round(1), 'Главные потребители': Ft['кто']})
        data_sheet(wb, nm, d, {'Группа': 22, 'Главные потребители': 36}, wrap=('Главные потребители',),
                   kpi=[('Видов', len(d)), ('Сайтов со встраиванием', len(Em) if Em is not None else 0)], kpi_col='Из кэша (304), %', red=())
        ws = wb[nm]
        first_heading(ws, 'main')   # заголовок первой таблицы — над шапкой, без сдвига строк
        notes_of(ws)
        if Em is not None and len(Em):
            extra_table(ws, pd.DataFrame({'Сайт': Em['сайт'], 'Запросов': Em['запросов'].astype(int), 'Трафик': Em['байт'].map(size), 'Файлы': Em['файлы'], 'Вывод': Em['вывод'],
                                          'Первый': Em['первый'].map(_d), 'Последний': Em['последний'].map(_d)}),
                        'hotlink', wrap=('Файлы', 'Вывод'))
            notes_of(ws, 'hotlink')
        fit_widths(ws, start_row=5, hi=46)
        names.add(nm)
    Hv = X.get('тяжёлые')
    if Hv is not None and len(Hv):
        nm = 'Тяжёлые файлы'
        if nm not in wb.sheetnames: wb.create_sheet(nm)
        d = pd.DataFrame({'Файл': Hv['файл'], 'Вид': Hv['вид'], 'Размер': Hv['средний'].map(size), 'Запросов': Hv['запросов'].astype(int), 'Трафик': Hv['байт'].map(size),
                          'Запросов с сайта': Hv['с_сайта'].astype(int), 'Потребители': Hv['кто'], 'Первый': Hv['первый'].map(_d), 'Последний': Hv['последний'].map(_d)})
        data_sheet(wb, nm, d, {'Файл': 56, 'Вид': 16, 'Потребители': 34}, wrap=('Файл', 'Потребители'),
                   kpi=[('Файлов', len(d))], kpi_col='Трафик', red=())
        notes_of(wb[nm])
        names.add(nm)
    # ---- Атаки ----
    At = X.get('атаки')
    if At is not None and len(At):
        nm = 'Атаки в параметрах'
        if nm not in wb.sheetnames: wb.create_sheet(nm)
        At = At.head(2000)
        d = pd.DataFrame({'Адрес': At['адрес'], 'Вид атаки': At['вид'], 'Запросов': At['запросов'].astype(int), 'Уникальных IP': At['IP'].astype(int), 'Главный IP': At['главный_IP'],
                          'Фигурант': At['кто'], 'Ответы': At['ответы'], 'Ошибки': At['ошибки'], 'Ответ 200': At['отдано_200'].astype(int),
                          'Размер ответа 200': At['размер_200'].map(lambda v: int(v) if pd.notna(v) else None), 'Обычный размер': At['обычный_размер'],
                          'Пример': At['пример'], 'Первый': At['первый'], 'Последний': At['последний']})
        data_sheet(wb, nm, d, {'Адрес': 34, 'Вид атаки': 18, 'Главный IP': 22, 'Фигурант': 28, 'Ответы': 22, 'Ошибки': 22, 'Обычный размер': 16, 'Пример': 50, 'Первый': 16, 'Последний': 16},
                   wrap=('Адрес', 'Фигурант', 'Ответы', 'Ошибки', 'Пример'), kpi=[('Адресов', len(X['атаки'])), ('Проверить', int(X['атаки']['подозрительно'].sum()))], kpi_col='Ответ 200',
                   row_rule=lambda r, _it=iter(list(At['подозрительно'])): F_NOTE if next(_it) else None, red=('Ошибки',))
        notes_of(wb[nm])
        legend_of(wb[nm], ['подозрительно', 'обычно'])
        names.add(nm)
    # ---- Массовые запросы ----
    Mq = X.get('массовые')
    if Mq is not None and len(Mq):
        nm = 'Массовые запросы'
        if nm not in wb.sheetnames: wb.create_sheet(nm)
        d = pd.DataFrame({'IP': Mq['ip'], 'Фигурант': Mq['кто'], 'Сеть': Mq['сеть'], 'Страна': Mq['страна'], 'Макс. стр. в мин.': Mq['максимум'].astype(int),
                          'Минут': Mq['минут'].astype(int), 'Запросов': Mq['запросов'].astype(int), 'Ответы': Mq['ответы'], 'Ошибки': Mq['ошибки'],
                          'Отказы сервера': Mq['отказы'].astype(int), 'Первая минута': Mq['первая'], 'Последняя минута': Mq['последняя']})
        live = [str(k).split(' —')[0] in ('Люди', 'Свои') for k in Mq['кто']]
        data_sheet(wb, nm, d, {'IP': 16, 'Фигурант': 34, 'Сеть': 30, 'Ответы': 28, 'Ошибки': 24, 'Первая минута': 16, 'Последняя минута': 16},
                   wrap=('Фигурант', 'Сеть', 'Ответы', 'Ошибки'), center=('Страна',), kpi=[('IP', len(d))], kpi_col='Минут', red=('Ошибки',),
                   font_rule=lambda r, _it=iter(live): GREY if next(_it) else None)
        notes_of(wb[nm])
        legend_of(wb[nm], ['массовые_люди'])
        names.add(nm)
    return names


def filter_sheet(wb, Fl):
    """Серверный фильтр — кому защита сервера отказывает: подлинным поисковым роботам, роботам проверки объявлений, людям (данные — security.server_filter)."""
    if not Fl or not len(Fl.get('таблица', [])): return None
    D, G = Fl['таблица'], Fl['группы']
    nm = 'Серверный фильтр'
    if nm not in wb.sheetnames: wb.create_sheet(nm)
    d = pd.DataFrame({'Группа': D['группа'], 'Кто': D['кто'], 'Код': D['код'].astype(int), 'Тип сети': D['сеть'], 'Страна': D['страна'], 'Ответов': D['ответов'].astype(int),
                      'Доля отказов от всех запросов, %': D['доля_%'], 'Дней': D['дней'].astype(int), 'Волны': D['волны'], 'Пример адреса': D['пример']})
    k = lambda g: int(G.loc[G['группа'] == g, 'отказов'].sum())
    robots = list(D['группа'] != 'Люди')
    data_sheet(wb, nm, d, {'Группа': 22, 'Кто': 22, 'Тип сети': 22, 'Волны': 30, 'Пример адреса': 40},
               wrap=('Группа', 'Тип сети', 'Волны', 'Пример адреса'), center=('Код', 'Страна'),
               kpi=[('Поисковым роботам', k('Поисковые роботы')), ('Роботам проверки объявлений', k('Роботы проверки объявлений')), ('Людям', k('Люди'))], kpi_col='Ответов',
               row_rule=lambda r, _it=iter(robots): F_NOTE if next(_it) else None, red=())
    notes_of(wb[nm], conclusion=f"{Fl['вывод']}." if Fl.get('вывод') else None, todo=f"{Fl['что_сделать']}.")   # вывод и что сделать — из движка (security)
    legend_of(wb[nm], ['критично', 'обычно'])
    return wb[nm]


def parasites_sheet(wb, P):
    """Паразитные адреса — лист 06 «SEO» (или 03, если 06 не строится)."""
    if P is None or not len(P): return None
    nm = 'Паразитные адреса'
    if nm not in wb.sheetnames: wb.create_sheet(nm)
    d = pd.DataFrame({'Базовый адрес': P['адрес'], 'Вариантов адреса': P['вариантов'].astype(int), 'Запросов': P['запросов'].astype(int), 'Фигуранты дела': P['фигуранты'],
                      'Виновники': P['виновники'], 'Вид': P['вид'], 'Меры пресечения': P['меры']})
    data_sheet(wb, nm, d, {'Базовый адрес': 40, 'Фигуранты дела': 28, 'Виновники': 34, 'Вид': 16, 'Меры пресечения': 50},
               wrap=('Базовый адрес', 'Фигуранты дела', 'Виновники', 'Меры пресечения'), kpi=[('Страниц', len(d)), ('Вариантов', int(d['Вариантов адреса'].sum()))], kpi_col='Вид',
               row_rule=lambda r, _it=iter(list(P['вариантов'] >= 1000)): F_NOTE if next(_it) else None, red=())
    notes_of(wb[nm])
    legend_of(wb[nm], ['ловушка', 'обычно'])
    return wb[nm]


def overview(wb, res, site):
    X = res.get('security') or {}
    E = res.get('errors') or {}
    if 'Обзор' in wb.sheetnames: del wb['Обзор']
    ws = wb.create_sheet('Обзор', 0)
    W = Wide(ws)
    brand_header(ws, W, res, last='I', site=site.upper())
    names = set(wb.sheetnames)
    J = X.get('журнал')
    sc = X.get('сканеры') or (None, None)
    A = X.get('админка')
    B = X.get('всплески')
    tot = J[J['день'] == 'Итого'].iloc[0] if J is not None and len(J) else None
    W.r += 1
    W.kpis([('Трафик, ГБ', int(tot['Трафик|ГБ']) if tot is not None else 0), ('Пик в минуту', int(tot['Пик|В минуту']) if tot is not None else 0),
            ('Всплесков', len(B) if B is not None else 0), ('Запросов сканеров', int(tot['Сканеры|Запросов']) if tot is not None else 0),
            ('Находок сканеров', int(sc[0]['находки'].sum()) if sc[0] is not None and len(sc[0]) else 0),
            ('Чужих в админке', int(A['чужой'].sum()) if A is not None and len(A) else 0)])
    M = X.get('методы')
    # ---- Серверный фильтр: первым после ключевых цифр, только если отказы есть ----
    Fl = X.get('фильтр')
    if Fl and len(Fl.get('таблица', [])):
        G = Fl['группы']
        W.block('server_filter', conclusion=f"{Fl['вывод']}." if Fl.get('вывод') else None)   # вывод — из движка (security)
        W.table(['Группа', 'Отказов', 'Дней', 'Что это'], [[r['группа'], int(r['отказов']), int(r['дней']), (f"{r['кто']}: " if r['кто'] else '') + r['что']] for _, r in G.iterrows()],
                ['BC', 'D', 'E', 'FGHI'], num=(1, 2), wrap=0.95,
                fills={(i, j): F_NOTE for i, (_, r) in enumerate(G.iterrows()) if r['группа'] != 'Люди' and r['отказов'] for j in range(4)})
        W.links_of('server_filter', names)
    # ---- Безопасность ----
    if sc[0] is not None and len(sc[0]):
        T = sc[0]
        W.block('scanners')
        T6 = T.head(6)
        rows = [[r['цель'], int(r['запросов']), int(r['IP']), int(r['отдано_200']), int(r['находки']), r['что_отдано'] or '—'] for _, r in T6.iterrows()]
        fl = {}
        for k, (_, r) in enumerate(T6.iterrows()):   # находки — персиковым, ответы 200 без находок — светло-серым
            col_ = F_NOTE if r['находки'] > 0 else ('F3F3F3' if r['отдано_200'] > 0 else None)
            if col_: fl.update({(k, i): col_ for i in range(6)})
        W.table(['Цель', 'Попыток', 'Уникальных IP', 'Ответ 200', 'Находки', 'Добыча'], rows, ['B', 'C', 'D', 'E', 'F', 'GHI'], num=(1, 2, 3, 4), wrap=0.95, fills=fl)
        W.links_of('scanners', names)
    if A is not None and len(A):
        W.block('admin')
        g = (res.get('сводки') or {}).get('админка_по_кто')
        if g is None: g = A.groupby('кто').agg(IP=('ip', 'size'), запросов=('запросов', 'sum'), успешных=('успешных_200', 'sum')).sort_values('запросов', ascending=False).reset_index()
        W.table(['Кто', 'Уникальных IP', 'Запросов', 'Успешных'], [[r['кто'], int(r['IP']), int(r['запросов']), int(r['успешных'])] for _, r in g.head(6).iterrows()], ['BC', 'D', 'E', 'F'], num=(1, 2, 3))
        W.links_of('admin', names)
    if M is not None and M[0] is not None and len(M[0]):
        T = M[0][~M[0]['метод'].isin(['GET', 'POST', 'HEAD'])]
        if len(T):
            W.block('methods')
            W.table(['Метод', 'Опознание', 'Запросов', 'Принято (2xx)'], [[r['метод'], r['что'], int(r['запросов']), int(r['принято'])] for _, r in T.head(6).iterrows()], ['B', 'CDEF', 'G', 'H'], num=(2, 3), wrap=0.95)
            W.links_of('methods', names)
    # ---- Нагрузка ----
    if B is not None and len(B):
        W.block('surges')
        top = B.sort_values('_excess', ascending=False).head(5).sort_values('_t0')
        W.table(['Всплеск', 'Длительность (мин)', 'Запросов', 'Пик в минуту', 'Картина'], [[r['всплеск'], int(r['минут']), int(r['запросов']), int(r['пик_в_минуту']), r['картина']] for _, r in top.iterrows()],
                ['B', 'C', 'D', 'E', 'FGHI'], num=(1, 2, 3), wrap=0.95)
        W.links_of('surges', names, count=len(B))
    note = overlap_note(X.get('часы'))
    if note:
        W.block('overlap')
        W.notes_of('overlap', overlap=note.replace('Куда смотреть: ', 'Пересечение нагрузок: '))
        W.links_of('overlap', names)
    Q = X.get('источники')
    if Q is not None and len(Q):
        W.block('sources')
        W.table(['Категория', 'Тип', 'Подозреваемый', 'Запросов', 'Трафик (%)'], [[r['категория'], r['тип'] or '—', r['подозреваемый'], int(r['запросов']), f"{r['трафик_%']:.1f}%".replace('.', ',')] for _, r in Q.head(6).iterrows()],
                ['B', 'CD', 'EF', 'G', 'H'], num=(3,), wrap=0.95)
        W.links_of('sources', names)
    Mq = X.get('массовые')
    if Mq is not None and len(Mq):
        W.block('mass')
        W.table(['IP', 'Фигурант', 'Макс. стр. в мин.', 'Запросов'], [[r['ip'], r['кто'], int(r['максимум']), int(r['запросов'])] for _, r in Mq.head(5).iterrows()], ['B', 'CDEF', 'G', 'H'], num=(2, 3), wrap=0.95)
        W.links_of('mass', names, count=len(Mq))
    P = X.get('паразиты')
    if P is not None and len(P) and 'SEO' not in res.get('selected', ()):
        W.block('parasites')
        W.table(['Базовый адрес', 'Вариантов', 'Фигуранты', 'Виновники'], [[r['адрес'], int(r['вариантов']), r['фигуранты'], r['виновники']] for _, r in P.head(5).iterrows()], ['BC', 'D', 'EF', 'GHI'], num=(1,), wrap=0.95)
        W.links_of('parasites', names)
    W.related(res, 'Нагрузка и безопасность')
    W.finish()   # блоки — в порядке каталога (#11)
    ws.page_setup.orientation = 'portrait'; ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    return ws


def build(wb, res, S, site):
    for k_ in ('Сводка', 'О данных'):
        if k_ in wb.sheetnames: del wb[k_]
    build_sheets(wb, res, S)
    from .catalog import prune
    prune(wb, 'Нагрузка и безопасность')   # до Обзора: строки на невыведенные листы не появляются (#8)
    overview(wb, res, site)
    byname = {w.title: w for w in wb._sheets}
    head_ = [byname[n_] for n_ in catalog_order('Нагрузка и безопасность') if n_ in byname]   # порядок — из каталога (#8)
    wb._sheets = head_ + [w for w in wb._sheets if w not in head_]


def scanner_ips_sheet(wb, res, name='IP сканеров'):
    """04 «Боты»: все IP сканеров — кто, откуда, что искали и что получили."""
    sc = (res.get('security') or {}).get('сканеры')
    if not sc or sc[1] is None or not len(sc[1]): return None
    I = sc[1]
    if name not in wb.sheetnames: wb.create_sheet(name)
    d = pd.DataFrame({'IP': I['ip'], 'Кто': I['кто'], 'Сеть': I['сеть'].fillna(''), 'Страна': I['страна'].fillna(''), 'Попыток': I['запросов'].astype(int), 'Дней': I['дней'].astype(int),
                      'Цели': I['целей'], 'Ответ 200': I['отдано'].astype(int), 'Находок': I['находок'].astype(int), 'Первый': I['первый'].map(_d), 'Последний': I['последний'].map(_d),
                      'User-Agent': I['ip'].astype(str).map(res.get('ua_ip') or {}).fillna('')})
    data_sheet(wb, name, d, {'IP': 16, 'Кто': 32, 'Сеть': 30, 'Цели': 44, 'User-Agent': 50}, wrap=('Кто', 'Сеть', 'Цели', 'User-Agent'), center=('Страна',),
               kpi=[('IP', len(d)), ('С находками', int((d['Находок'] > 0).sum()))], kpi_col='Попыток',
               row_rule=lambda r: F_NOTE if r.get('Находок') else None, red=())
    legend_of(wb[name], ['находка', 'обычно'])
    return wb[name]
