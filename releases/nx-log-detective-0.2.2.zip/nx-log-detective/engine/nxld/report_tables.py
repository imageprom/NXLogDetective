"""NXLD: простые листы-таблицы в общем стиле (заголовок, пояснение, оранжевая шапка, фильтр, закреплённая шапка)."""
import numbers
import numpy as np, pandas as pd
from openpyxl.styles import Font, Alignment, Border, PatternFill, Side
from .report_index import ORANGE, ORANGE2, INK, GREY, F_NOTE, NUM_FMT, RED

from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE as ILLEGAL
SEP = Side(style='thin', color='D9D9D9')
BIG_OUT = {'файл': '', 'csv': []}   # большие листы текущего файла: report.build задаёт имя файла и пишет CSV после сохранения xlsx


def big_cut(name, df):
    """Лист больше порога (sheets.BIG): полный — в очередь CSV, в Excel — первые строки. Возвращает (df для Excel, строка-пояснение или None)."""
    from .sheets import BIG
    tag = BIG['листы'].get(name)
    if tag is None or not BIG_OUT['файл'] or len(df) <= BIG['порог']: return df, None
    fn = f"{BIG_OUT['файл']}_{tag}.csv"
    BIG_OUT['csv'] = [x for x in BIG_OUT['csv'] if x[0] != fn] + [(fn, df)]   # лист пересобран — CSV по последней версии
    show = BIG['показать']
    return df.head(show), f"Показаны {show:,} из {len(df):,}. Полный список со всеми колонками — файл {fn} в архиве отчёта".replace(',', '\u00a0')


def write_big_csv(outdir):
    """CSV больших листов текущего файла: те же колонки, порядок и заголовки; UTF-8 с BOM, «;», числа без разрядов. Возвращает пути."""
    import os
    out = []
    for fn, df in BIG_OUT['csv']:
        p = os.path.join(outdir, fn)
        df.to_csv(p, sep=';', index=False, encoding='utf-8-sig')
        out.append(p)
    BIG_OUT['csv'] = []
    return out
WHITE = Side(style='thin', color='FFFFFF')


def data_sheet(wb, name, df, title, note='', widths=None, wrap=(), fill_rule=None, bold_rule=None, center=(), sort_by=None, kpi=None, kpi_col=None, links=(), size=9, row_rule=None, red=('Ошибки',), font_rule=None):
    """Пересобирает лист name: строка 1 — заголовок, 2 — пояснение, 4 — шапка, дальше данные.
    widths — ширины колонок; wrap — колонки с переносом; fill_rule(col, value) → цвет заливки или None."""
    idx = wb.sheetnames.index(name) if name in wb.sheetnames else len(wb.sheetnames)
    if name in wb.sheetnames: del wb[name]
    ws = wb.create_sheet(name, idx)
    ws.sheet_view.showGridLines = True
    df, cut = big_cut(name, df)   # большой лист: в Excel — первые строки, полный — CSV в архиве
    if cut:
        ws['B3'] = cut; ws['B3'].font = Font(name='Arial', size=10, bold=True, color=INK)
    cols = list(df.columns)
    ws.column_dimensions['A'].width = 2.5          # поле слева, как на остальных листах
    ws['B1'] = title.upper(); ws['B1'].font = Font(name='Montserrat', size=16, bold=True, color=ORANGE)
    ws.row_dimensions[1].height = 34
    if note:   # подзаголовок — фирменным Comfortaa, как на обзоре
        ws['B2'] = note; ws['B2'].font = Font(name='Comfortaa', size=11, bold=True, color=GREY)
        ws['B2'].alignment = Alignment(vertical='center', wrap_text=False)
    ws.row_dimensions[2].height = 24
    X = 1   # сдвиг колонок
    def put_kpi():   # цифры сводки — справа от заголовка: подпись мелко, число крупно; не налезают на подзаголовок
        from openpyxl.utils import get_column_letter as L_
        c0 = (cols.index(kpi_col) if kpi_col in cols else max(0, len(cols) - len(kpi))) + 1 + X
        need = max(len(str(title)) * 2.2, len(str(note or '')) * 1.45)   # заголовок (Montserrat 16) и подзаголовок (Comfortaa 11) шире обычного текста
        while c0 <= len(cols) + X + 2 and sum((ws.column_dimensions[L_(j)].width or 10) for j in range(2, c0)) < need: c0 += 1
        for k, (lab, val) in enumerate(kpi):
            a = ws.cell(1, c0 + k, lab); a.font = Font(name='Arial', size=9, color=INK); a.alignment = Alignment(horizontal='center', vertical='bottom', wrap_text=True)
            b = ws.cell(2, c0 + k, val); b.font = Font(name='Arial', size=14, bold=True, color='000000'); b.alignment = Alignment(horizontal='center', vertical='center')
            if isinstance(val, int) and val >= 1000: b.number_format = NUM_FMT
            cw = ws.column_dimensions[L_(c0 + k)].width or 10
            if isinstance(val, str) and len(val) * 1.5 + 2 > cw: ws.column_dimensions[L_(c0 + k)].width = len(val) * 1.5 + 2   # «Пн 28.09» и другие подписи-значения — целиком
    H = 4
    for j, c in enumerate(cols, 1):
        cell = ws.cell(H, j + X, c)
        cell.font = Font(name='Arial', size=size, bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor=ORANGE)
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(left=WHITE, right=WHITE)
    ws.cell(H, 1 + X)
    ws.row_dimensions[H].height = 32
    for i, row in enumerate(df.itertuples(index=False), H + 1):
        rf = row_rule(dict(zip(cols, row))) if row_rule else None   # заливка всей строки
        ff = font_rule(dict(zip(cols, row))) if font_rule else None   # цвет текста всей строки (неактуальное — серым)
        for j, v in enumerate(row, 1):
            if isinstance(v, float) and pd.isna(v): v = None
            if hasattr(v, 'item'): v = v.item()
            if isinstance(v, float) and v.is_integer() and abs(v) >= 1000: v = int(v)   # целые в дробном виде — как целые, с разрядами
            if isinstance(v, str): v = ILLEGAL.sub('�', v)   # управляющие символы из адресов сканеров Excel не принимает
            cell = ws.cell(i, j + X, v)
            col = cols[j - 1]
            isnum = isinstance(v, numbers.Number) and not isinstance(v, bool)
            cell.font = Font(name='Arial', size=size, bold=bool(bold_rule and bold_rule(col, v)), color=ff or (RED if col in red else '000000'))
            hz = 'center' if col in center else ('right' if isnum else 'left')
            cell.alignment = Alignment(horizontal=hz, vertical='top', wrap_text=col in wrap, indent=1 if hz != 'center' else 0)
            if isnum and isinstance(v, int) and abs(v) >= 1000: cell.number_format = NUM_FMT
            elif isnum and isinstance(v, float): cell.number_format = '# ##0.0#' if abs(v) >= 1000 else '0.0#'
            cell.border = Border(bottom=SEP)
            f = rf or (fill_rule(col, v) if fill_rule else None)
            if f: cell.fill = PatternFill('solid', fgColor=f)
    for j, c in enumerate(cols, 1):
        letter = ws.cell(H, j + X).column_letter
        q90 = df[c].astype(str).str.len().quantile(0.9) if len(df) else None   # пустая колонка (категория из одних NaN) — длина NaN
        ws.column_dimensions[letter].width = (widths or {}).get(c) or min(45, max(10, len(str(c)) + 2, int(q90) + 2 if q90 is not None and pd.notna(q90) else 10))
        lw = max((len(w_) for w_ in str(c).split()), default=0) * 1.1 * size / 9 + 1.5   # слово шапки не рвётся посередине
        if ws.column_dimensions[letter].width < lw: ws.column_dimensions[letter].width = lw
    fit_header(ws, H, cols, X)
    if kpi: put_kpi()
    r_ = H + len(df) + 2   # ссылки — под таблицей, как на других листах
    for text, target in links:
        if isinstance(target, tuple):   # лист другого файла отчёта
            c = ws.cell(r_, 1 + X, f'{text}: {target[0]}, лист «{target[1]}» →'); c.hyperlink = f"{target[0]}#'{target[1]}'!A1"
        else:
            c = ws.cell(r_, 1 + X, f'{text}: лист «{target}» →'); c.hyperlink = f"#'{target}'!A1"
        c.font = Font(name='Arial', size=10, color=ORANGE2, underline='single'); r_ += 1
    ws.freeze_panes = ws.cell(H + 1, 1 + X)
    if len(df):
        ws.auto_filter.ref = f"{ws.cell(H, 1 + X).coordinate}:{ws.cell(H + len(df), len(cols) + X).coordinate}"
        if sort_by and sort_by in cols:   # отметка сортировки в фильтре — Excel покажет, по чему отсортировано
            c_ = cols.index(sort_by) + 1 + X
            ws.auto_filter.add_sort_condition(f"{ws.cell(H + 1, c_).coordinate}:{ws.cell(H + len(df), c_).coordinate}")
    return ws


def fit_header(ws, H, cols, X=1, first=None):
    """Высота шапки — по самому длинному названию колонки при её ширине, чтобы ничего не обрезалось."""
    import math
    lines = 1
    for j, c in enumerate(cols):
        from openpyxl.utils import get_column_letter as L_
        w = ws.column_dimensions[L_((first or (1 + X)) + j)].width or 10
        for word_line in str(c).split('\n'):
            lines = max(lines, math.ceil(len(word_line) * 1.15 / max(4, w - 1)) + str(c).count('\n'))
    ws.row_dimensions[H].height = max(20, 13 * lines + 8)


def header_groups(ws, groups, H=4, X=1):
    """Двухуровневая шапка для листа data_sheet: groups — {верх: [колонки]}. Верх — в строке над шапкой, объединённой по своим колонкам;
    колонки без верха — одной ячейкой на два уровня."""
    cols = {ws.cell(H, j).value: j for j in range(1 + X, ws.max_column + 1) if ws.cell(H, j).value}
    inner = {c for v in groups.values() for c in v}
    for top, cs in groups.items():
        js = sorted(cols[c] for c in cs if c in cols)
        if not js: continue
        c_ = ws.cell(H - 1, js[0], top)
        c_.font = Font(name='Arial', size=9, bold=True, color='FFFFFF'); c_.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for j in range(js[0], js[-1] + 1):
            ws.cell(H - 1, j).fill = PatternFill('solid', fgColor=ORANGE); ws.cell(H - 1, j).border = Border(left=WHITE, right=WHITE, bottom=WHITE)
        if len(js) > 1: ws.merge_cells(start_row=H - 1, start_column=js[0], end_row=H - 1, end_column=js[-1])
    for c, j in cols.items():
        if c in inner: continue
        ws.cell(H - 1, j).fill = PatternFill('solid', fgColor=ORANGE)
        v = ws.cell(H, j).value
        ws.cell(H, j).value = None
        ws.cell(H - 1, j).value = v
        ws.cell(H - 1, j).font = Font(name='Arial', size=9, bold=True, color='FFFFFF')
        ws.cell(H - 1, j).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws.merge_cells(start_row=H - 1, start_column=j, end_row=H, end_column=j)
    ws.row_dimensions[H - 1].height = 20


def fit_widths(ws, start_row=4, lo=9, hi=44, skip=()):
    """Ширины колонок по содержимому всех таблиц листа — для листов, где таблиц несколько."""
    from openpyxl.utils import get_column_letter as L_
    best = {}
    for row in ws.iter_rows(min_row=start_row):
        if sum(c.value is not None for c in row) < 3: continue   # заметки, ссылки и заголовки таблиц — одна ячейка, на ширину не влияют
        for c in row:
            if c.value is None or c.column == 1 or c.coordinate in ws.merged_cells: continue
            n = max(len(x) for x in str(c.value).split('\n'))
            best[c.column] = max(best.get(c.column, 0), n)
    hw = {}   # шапки таблиц (оранжевая заливка): слово названия не рвётся посередине
    for row in ws.iter_rows(min_row=3):
        for c in row:
            if isinstance(c.value, str) and c.fill is not None and c.fill.fgColor is not None and str(c.fill.fgColor.rgb)[-6:] == ORANGE[-6:] \
                    and c.coordinate not in ws.merged_cells:
                hw[c.column] = max(hw.get(c.column, 0), max((len(w_) for w_ in c.value.split()), default=0) * 1.1 + 1.5)
    for j, n in best.items():
        if L_(j) in skip: continue
        ws.column_dimensions[L_(j)].width = max(lo, min(hi, n * 0.9 + 2), hw.get(j, 0))


LEGEND = {'критично': (F_NOTE, None, 'Критично — см. «Почему важно»'), 'обычно': ('FFFFFF', None, 'Ошибка есть, не критична'),
          'неактуально': ('FFFFFF', GREY, 'Уже неактуально: починилось или давно не встречалось'),
          'чужое': ('EFEFEF', None, 'Чужое: сканеры и посторонние'), 'норма': ('EFEFEF', None, 'Норма'),
          'люди': (F_NOTE, None, 'Ошибку получили люди, и она встречается сейчас'),
          'со_страниц': (F_NOTE, None, 'Файл просят страницы сайта, и ошибка встречается сейчас'),
          '5xx': (F_NOTE, None, 'Сервер отвечает ошибкой 5xx'), 'клик_впустую': (F_NOTE, None, 'Клик привёл на ошибку: деньги впустую'),
          'сбой': (F_NOTE, None, 'Сбой: сервер отвечал ошибками на многие страницы сразу'), 'выходные': ('F3F3F3', None, 'Выходные'),
          'неполный': ('FFFFFF', GREY, 'Неполный день: в лог попала только часть суток'),
          'находка': (F_NOTE, None, 'Сервер отдал постороннему то, что ему не положено'),
          'не_улика': ('EFEFEF', None, 'Только обычные страницы сайта и заглушки — не улика'),
          'чужой': (F_NOTE, None, 'Чужой: не сотрудник'), 'программа': ('FFFFFF', GREY, 'Не человек: программа или бот'),
          'ложный': ('EFEFEF', None, 'Ложный раздел: на сайте его нет, сканеры угадывали'),
          'открыто': (F_NOTE, None, 'Настоящий раздел: есть страницы, которые открываются без входа'),
          'всплеск': (F_NOTE, None, 'Всплеск от программ, похожий на DDoS, или с последствиями для людей'),
          'подозрительно': (F_NOTE, None, 'Сервер ответил 200, и ответ не похож на обычную страницу — проверить'),
          'посторонние': (F_NOTE, None, 'Адрес с токеном видели посторонние'), 'свои_норма': ('EFEFEF', None, 'Видели только свои — норма'),
          'ловушка': (F_NOTE, None, 'Больше 1 000 вариантов адреса'),
          'принято': (F_NOTE, None, 'Сервер принял необычный метод (ответ 2xx)'),
          'утечка': (F_NOTE, None, 'Утечка: содержимое файла отдано постороннему'),
          'сотрудник': ('EFEFEF', None, 'Сотрудник — норма'), 'посторонний': (F_NOTE, None, 'Посторонний человек в админке'),
          'ответ_200': ('EFEFEF', None, 'Сервер ответил 200, но это не улика: обычные страницы, заглушки, формы входа'), 'закрыт': ('FFFFFF', GREY, 'Закрыт: больше не отдаётся'),
          'опасная_точка': (F_NOTE, None, 'Загрузка файлов посторонними или персональные данные в адресе'), 'сканер_точка': ('EFEFEF', None, 'Сканер: адреса на сайте нет'),
          'задевает': ('EFEFEF', None, 'Из тех же сетей приходят люди: сеть целиком не закрывать'), 'принята_заявка': (F_NOTE, None, 'Сайт принял заявку бота как настоящую'),
          'приговор_блок': (F_NOTE, None, 'Заблокировать: дело серьёзное, людей из этой сети нет'),
          'массовые_люди': ('FFFFFF', GREY, 'Люди и свои: проверить, не общий ли это IP (офис, мобильный оператор)')}


def legend(ws, keys):
    """Легенда цветов под таблицей: подпись прямо на образце цвета. Ширину образца по тексту подбирает sanitize перед сохранением."""
    r_ = ws.max_row + 2
    rows = getattr(ws, '_nxld_legend', [])
    for k in keys:
        fill, font, text = LEGEND[k]
        c0 = ws.cell(r_, 2, text)
        c0.fill = PatternFill('solid', fgColor=fill); c0.border = Border(left=SEP, right=SEP, top=SEP, bottom=SEP)
        c0.font = Font(name='Arial', size=9, color=font or '000000')
        c0.alignment = Alignment(vertical='center', indent=1)
        rows.append((r_, fill))
        r_ += 1
    ws._nxld_legend = rows


def _w(ws, j):
    from openpyxl.utils import get_column_letter as L_
    return ws.column_dimensions[L_(j)].width or 8.43


def _shown(v, fmt):
    """Как число выглядит в ячейке: разряды пробелом, дробная часть по формату."""
    if isinstance(v, float) and not float(v).is_integer():
        d = len(fmt.split('.')[-1].replace('#', '0')) if '.' in (fmt or '') else 2
        t = f'{v:,.{min(d, 3)}f}'
    else:
        t = f'{int(v):,}'
    return t.replace(',', ' ')


def sanitize(wb):
    """Последний проход перед сохранением, общий для всех файлов:
    — представление листа без закрепления не ссылается на области закрепления (иначе Excel «восстанавливает» файл);
    — легенды: образец цвета — на ширину текста (ячейки объединяются);
    — числа не превращаются в ##### : колонка (или последняя колонка объединения) расширяется под число в его виде."""
    from openpyxl.worksheet.views import Selection
    from openpyxl.utils import get_column_letter as L_
    for ws in wb.worksheets:
        sv = ws.sheet_view
        if sv.pane is None or ws.freeze_panes is None:
            sv.pane = None
            sv.selection = [Selection(activeCell='A1', sqref='A1')]
        merged = {}
        for m in ws.merged_cells.ranges:
            merged[(m.min_row, m.min_col)] = m
        for r_, fill in getattr(ws, '_nxld_legend', []):
            c0 = ws.cell(r_, 2)
            if not c0.value or (r_, 2) in merged: continue
            need = len(str(c0.value)) * 0.95 + 3
            j, tot = 2, _w(ws, 2)
            while tot < need and j < 30:
                j += 1; tot += _w(ws, j)
            for q in range(3, j + 1):
                cq = ws.cell(r_, q); cq.fill = PatternFill('solid', fgColor=fill); cq.border = Border(top=SEP, bottom=SEP, right=SEP if q == j else None)
            if j > 2:
                ws.merge_cells(start_row=r_, start_column=2, end_row=r_, end_column=j)
                merged[(r_, 2)] = None
        for row in ws.iter_rows():
            for c in row:
                v = c.value
                if not isinstance(v, numbers.Number) or isinstance(v, bool) or c.coordinate in ws.merged_cells and (c.row, c.column) not in merged: continue
                sz = (c.font.sz or 11) if c.font else 11
                need = len(_shown(v, c.number_format or '')) * sz / 10 * (1.12 if c.font and c.font.b else 1.0) + 2.2
                m = merged.get((c.row, c.column))
                cols_ = range(m.min_col, m.max_col + 1) if m is not None else [c.column]
                have = sum(_w(ws, j) for j in cols_)
                if have < need:
                    last = list(cols_)[-1]
                    ws.column_dimensions[L_(last)].width = round(_w(ws, last) + need - have, 1)
    return wb


def conversions(wb, C, name='Конверсии'):
    """Все отправки форм: кто, какая форма, принята ли, откуда пришёл."""
    if C is None or not len(C) or name not in wb.sheetnames: return
    from .anatomy import name_of, FORM_NAME
    import re
    d = pd.DataFrame({
        'Время': pd.to_datetime(C['время']).dt.strftime('%d.%m.%Y %H:%M'),
        '_t': pd.to_datetime(C['время']),
        'Кто': C['группа'].astype(str),
        'Форма': C['форма'] if 'форма' in C else C['цель'].astype(str).map(lambda g: (name_of(g, FORM_NAME) or ('общий обработчик форм' if re.search(r'/form\.php$', g) else 'форма')).capitalize()),   # имя — из движка (blocks.form_name)
        'Принята': C['принята'].astype(str),
        'Статус': C['статус'].astype(str) if 'статус' in C else '',
        'Код ответа': pd.to_numeric(C['код'], errors='coerce').astype('Int64'),
        'Канал': C['канал'].astype(str),
        'Страница входа': C['вход'].astype(str),
        'Откуда пришёл': C['вход_реферер'].astype(str).replace({'-': '', 'nan': ''}),
        'Страниц до отправки': pd.to_numeric(C['страниц_до'], errors='coerce').astype('Int64'),
        'Секунд от входа': pd.to_numeric(C['сек_от_входа'], errors='coerce').astype('Int64'),
        'Почему бот': C['подгруппа'].astype(str).where(C['группа'] == 'Боты', '').str.replace('спам форм: ', '', regex=False),
        'IP': C['ip'].astype(str),
        'Сеть': C['сеть'].astype(str),
        'Обработчик': C['цель'].astype(str),
    }).sort_values('_t').drop(columns='_t')   # по времени
    d = d.astype(object).where(d.notna(), None)
    n_ = lambda g: int((C['группа'] == g).sum())
    kpi = [('Отправок', len(C)), ('Люди', n_('Люди')), ('Принято у людей', int(((C['группа'] == 'Люди') & (C['принята'] == 'да')).sum())), ('Боты', n_('Боты')), ('Свои', n_('Свои'))]
    widths = {'Время': 17, 'Кто': 13, 'Форма': 22, 'Принята': 10, 'Статус': 44, 'Код ответа': 9, 'Канал': 18, 'Страница входа': 28, 'Откуда пришёл': 24,
              'Страниц до отправки': 11, 'Секунд от входа': 10, 'Почему бот': 34, 'IP': 16, 'Сеть': 22, 'Обработчик': 50}
    fill = None
    row_rule = lambda r: F_NOTE if r.get('Кто') == 'Боты' else ('EFEFEF' if r.get('Кто') == 'Свои' else None)
    bold = lambda col, v: col == 'Принята' and v == 'да'
    data_sheet(wb, name, d, 'Конверсии', 'Все отправки форм за период', widths, wrap=('Почему бот', 'Статус'), fill_rule=fill, bold_rule=bold,
               center=('IP', 'Код ответа', 'Принята'), kpi=kpi, kpi_col='Канал', links=[('Сводка по формам', 'Анатомия сайта')], row_rule=row_rule)


# ---- точки приёма данных и POST-отправки ----
from .intake import SITE_KINDS, _codes, classify_post, post_rows as _post_rows   # реестр точек приёма — в движке (intake.py)


def _finish(rows):
    d = pd.DataFrame(rows)
    if not len(d): return d
    d['Первый'] = d['_t0'].dt.strftime('%d.%m.%Y %H:%M'); d['Последний'] = d['_t1'].dt.strftime('%d.%m.%Y %H:%M')
    sp_ = d['Коды ответа'].map(split_codes)
    d['Ответы'], d['Ошибки'] = sp_.str[0], sp_.str[1]
    d = d.sort_values('Запросов', ascending=False).drop(columns=['_t0', '_t1', 'Коды ответа'])   # по числу запросов; группы — фильтром
    order = ['Адрес точки', 'Запросов', 'Уникальных IP', 'Метод', 'Опознано как', 'Улики', 'Ответы', 'Ошибки', 'Первый', 'Последний']
    d = d[[c_ for c_ in order if c_ in d.columns]]
    return d


WIDTHS = {'Адрес точки': 55, 'Метод': 8, 'Опознано как': 22, 'Запросов': 10, 'Уникальных IP': 11, 'Улики': 50, 'Ответы': 30, 'Ошибки': 24, 'Первый': 16, 'Последний': 16}


def intake(wb, res, name='Точки приёма данных', before='Конверсии'):
    """Overview: только то, что сайт реально принимает — заявки, вход, фильтры и поиск, свои скрипты, админка."""
    if res.get('intake') is not None:   # реестр точек приёма (intake.py): здесь — то, что сайт принимает на самом деле
        rows = [dict(r) for r in res['intake'] if r['Опознано как'] != 'Сканер' and r.get('источник') != 'скрипт']
    else:   # старый анализ без реестра
        rows = [r for r in _post_rows(res) if r['Опознано как'] != 'Сканер']
        for g in (res.get('anatomy') or {}).get('api', []) + (res.get('anatomy') or {}).get('get_приём', []):
            rows.append({'Адрес точки': g['адрес'], 'Метод': 'GET', 'Опознано как': g['что'], 'Запросов': g['отправок'], 'Уникальных IP': g['IP'], 'Улики': g['почему'],
                         'Коды ответа': g['коды'], '_t0': pd.to_datetime(g['первый']), '_t1': pd.to_datetime(g['последний'])})
    d = _finish(rows)
    if not len(d): return
    if name not in wb.sheetnames: wb.create_sheet(name, wb.sheetnames.index(before) if before in wb.sheetnames else len(wb.sheetnames))
    cnt = d['Опознано как'].value_counts()
    cat_ = int(sum(cnt.get(k, 0) for k in ('Фильтр каталога', 'Поиск по сайту', 'Форма (GET)', 'Пагинация', 'Тип отображения', 'Сортировка')))
    serv_ = int(sum(cnt.get(k, 0) for k in ('Служебный скрипт', 'Подгрузка на странице', 'Админка', 'Загрузка файлов')))
    api_ = int(sum(cnt.get(k, 0) for k in ('Обмен с 1С', 'API', 'Вебхук')))
    kpi = [('Точек приёма', len(d)), ('Заявки', int(cnt.get('Заявка', 0))), ('Поиск и навигация', cat_),
           ('Вход', int(cnt.get('Вход', 0))), ('Служебные', serv_), ('API и обмен', api_)]
    kpi = kpi[:1] + sorted(kpi[1:], key=lambda x: x[1] == 0)   # нули — в конец
    row_rule = lambda r: 'EFEFEF' if r.get('Опознано как') in ('Служебный скрипт', 'Подгрузка на странице', 'Админка', 'Загрузка файлов') else None
    bold = lambda col, v: col == 'Опознано как' and v in ('Заявка', 'Вход')
    data_sheet(wb, name, d, 'Точки приёма данных', 'Где сайт принимает данные', WIDTHS,
               wrap=('Улики', 'Адрес точки', 'Ответы', 'Ошибки'), bold_rule=bold, center=('Метод',), kpi=kpi, kpi_col='Метод', row_rule=row_rule,
               links=[('Все отправки форм', 'Конверсии'), ('Сводка по формам', 'Анатомия сайта')])
    ws = wb[name]   # сноска и чего нет — тоже результат
    if d['Адрес точки'].astype(str).str.contains('фасетн').any():
        r0 = ws.max_row + 2
        c = ws.cell(r0, 2, 'Основные страницы — адреса структуры сайта. Фасетные страницы — адреса, которые генерирует фильтр каталога из комбинаций условий (…/filter/…/apply/); в структуре сайта их нет.')
        c.font = Font(name='Arial', size=10, italic=True, color=INK)
    absent = [lab for lab, keys in (('Поиск по сайту', ('Поиск по сайту',)), ('API и обмен с 1С, CRM, вебхуки', ('Обмен с 1С', 'API', 'Вебхук'))) if not any(cnt.get(k, 0) for k in keys)]
    if absent:
        r_ = ws.max_row + 2
        c = ws.cell(r_, 2, 'Обращений не найдено: ' + '; '.join(absent) + '.')
        c.font = Font(name='Arial', size=10, italic=True, color=INK)


def method_all(wb, res, method='POST', name=None, after=None):
    """03: все точки приёма одного метода из реестра (intake.py), вместе со сканерами; опознание — колонкой, отбор — фильтром."""
    name = name or method
    rows = [dict(r) for r in (res.get('intake') if res.get('intake') is not None else _post_rows(res)) if r['Метод'] == method]
    if not rows: return None
    d = _finish(rows)
    extra = pd.DataFrame(rows).sort_values('Запросов', ascending=False)
    pos_ = list(d.columns).index('Уникальных IP') + 1
    if 'свои' in extra:   # у сводных строк «Анатомии» (/projects/* — …) разбивки нет — пусто
        iv = lambda col: pd.Series([None if v is None or pd.isna(v) else int(v) for v in extra[col]], dtype=object, index=d.index)
        d.insert(pos_, 'Свои', iv('свои')); d.insert(pos_ + 1, 'Посторонние', iv('посторонние'))
    if method == 'GET' and 'пд' in extra and extra['пд'].fillna(0).astype(int).any():
        d.insert(pos_ + 2, 'Персональные данные', extra['пд'].fillna(0).astype(int).values)
    d = d.drop(columns=['Метод']).rename(columns={'Адрес точки': 'Адрес', 'Опознано как': 'Опознание'})
    if name not in wb.sheetnames:
        pos = wb.sheetnames.index(after) + 1 if after in wb.sheetnames else len(wb.sheetnames)
        wb.create_sheet(name, pos)
    sc = d[d['Опознание'] == 'Сканер']
    kpi = [('Адресов', len(d)), ('Принимает сайт', len(d) - len(sc)), ('Адресов сканеров', len(sc)), ('Запросов сканеров', int(sc['Запросов'].sum()))]
    up = list(((d['Опознание'] == 'Загрузка файлов') & (d.get('Посторонние', 0).fillna(0) > 0)) | (d.get('Персональные данные', pd.Series(0, index=d.index)).fillna(0) > 0))
    fills = [F_NOTE if u else ('EFEFEF' if o == 'Сканер' else None) for u, o in zip(up, d['Опознание'])]
    sub = {'POST': 'Все адреса, на которые за период отправляли данные методом POST: и сайт, и сканеры',
           'GET': 'Где сайт принимает данные в адресе (GET): фильтры, поиск, API и скрипты — и обращения сканеров'}[method]
    w = dict(WIDTHS, **{'Адрес': 55, 'Опознание': 22, 'Свои': 9, 'Посторонние': 11, 'Персональные данные': 12})
    data_sheet(wb, name, d, name, sub, w, wrap=('Улики', 'Адрес', 'Ответы', 'Ошибки'), kpi=kpi, kpi_col='Опознание',
               row_rule=lambda r, _it=iter(fills): next(_it), red=('Ошибки',))
    ws = wb[name]
    r_ = ws.max_row + 2
    for t_ in ['Опознание — что это за адрес: заявка, вход, фильтр, служебный скрипт, загрузка файлов, API или сканер; отбор — фильтром по колонке.',
               'Свои — запросы сотрудников; посторонние — все остальные.' + (' Персональные данные — запросы, в адресе которых телефон, почта или ФИО (в отчёте — маскированно).' if method == 'GET' else '')]:
        c_ = ws.cell(r_, 2, t_); c_.font = Font(name='Arial', size=9, italic=True, color=GREY); r_ += 1
    c = ws.cell(r_ + 1, 2, 'Что сайт принимает на самом деле: лист «Точки приёма данных» в NXLD_01_Overview.xlsx →')
    c.hyperlink = "NXLD_01_Overview.xlsx#'Точки приёма данных'!A1"; c.font = Font(name='Arial', size=10, color=ORANGE2, underline='single')
    legend(ws, ['опасная_точка', 'сканер_точка'])
    return ws


def post_all(wb, res, name='POST', after=None):
    return method_all(wb, res, 'POST', name, after)


def split_codes(s):
    """«200:65634, 404:12, 499:3» → («200 (65 634), 499 (3)», «404 (12)»): ответы и ошибки (4xx/5xx, кроме 499 — человек ушёл сам)."""
    ok, bad = [], []
    for k, v in _codes(s).items():
        (bad if k >= 400 and k != 499 else ok).append(f"{k} ({int(v):,})".replace(',', '\u00a0'))
    return ', '.join(ok), ', '.join(bad)


def nlist(s, sep=', '):
    """«/projects/: 66119, /realty/: 34665» → по строке на значение: «/projects/ (66 119)». Общий формат «название (число)»."""
    import re
    out = []
    for part in str(s or '').split(sep):
        m_ = re.match(r'^(.*?):\s*([\d\s\u00a0]+)$', part.strip())
        if m_:
            n_ = int(re.sub(r'\D', '', m_.group(2)))
            out.append(f"{m_.group(1)} ({n_:,})".replace(',', '\u00a0'))
        else: out.append(part.strip())
    return '\n'.join(x for x in out if x)


_PV = None


def paren_values(wb):
    """04–06: «Googlebot: 28, YandexBot: 15» → «Googlebot (28), YandexBot (15)» — общий формат «название (значение)» (ТЗ, вычитка 04–06).
    Только в оформлении: в данных движка формат прежний, его читают разборщики. Коды ответа («404: 297») и время не трогаются —
    перед двоеточием должна стоять не цифра."""
    import re
    global _PV
    if _PV is None: _PV = re.compile(r'(?<=[^\s\d:]): (\d(?:[\d\u00a0 ]*\d)?)(?=$|,|;|\n|\)|\.\s|\.$)')
    for ws in wb.worksheets:
        if ws.sheet_state != 'visible': continue
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if isinstance(v, str) and ': ' in v and not v.startswith('='):
                    nv = _PV.sub(r' (\1)', v)
                    if nv != v: cell.value = nv


def fmt_codes(s):
    """«200:65634, 499:632» → «200 (65 634), 499 (632)» — чтобы не читалось как порт."""
    out = []
    for k, v in _codes(s).items():
        out.append(f"{k} ({int(v):,})".replace(',', '\u00a0'))
    return ', '.join(out) or str(s)



def facets_sheet(wb, F, name='Фасеты'):
    if F is None or not len(F) or name not in wb.sheetnames: return
    d = pd.DataFrame({'Раздел': F['раздел'], 'Ключ': F['ключ'], 'Значение': F['значение'], 'Условие': F['условие'], 'Расшифровка': F['расшифровка'],
                      'Запросов': F['запросов'].astype(int), 'Уникальных IP (люди)': F['людей'].astype(int), 'Откуда': F['откуда']})
    kpi = [('Условий', int(d['Условие'].nunique())), ('Значений', len(d)), ('Запросов', int(d['Запросов'].sum()))]
    widths = {'Раздел': 14, 'Ключ': 26, 'Значение': 34, 'Условие': 16, 'Расшифровка': 30, 'Запросов': 11, 'Уникальных IP (люди)': 10, 'Откуда': 30}
    data_sheet(wb, name, d, 'Фасеты', 'Что люди выбирают в фильтре каталога', widths, wrap=('Ключ', 'Значение', 'Условие', 'Расшифровка', 'Откуда'), kpi=kpi, kpi_col='Запросов',
               row_rule=lambda r: 'EFEFEF' if str(r.get('Откуда', '')).startswith('параметры') else None,
               links=[('Где фильтр принимает запросы', 'Точки приёма данных'), ('Устройство каталога', 'Анатомия сайта')])




def _who(s):
    """«браузеры/прочие:41384, Applebot:122» → «браузеры (41 384), Applebot (122)»."""
    import re
    out = []
    for part in str(s).split(', '):
        k, _, v = part.rpartition(':')
        if k and v.strip().isdigit():
            out.append(f"{k.replace('браузеры/прочие', 'браузеры')} ({int(v):,})".replace(',', '\u00a0'))
        elif part: out.append(part)
    return ', '.join(out)


def leaks_sheet(wb, L, name='Утечки служебных файлов'):
    """03: служебные файлы, которые сервер отдал посторонним, — каждый адрес проверить и закрыть."""
    if L is None or not len(L) or name not in wb.sheetnames: return None
    day = lambda v: pd.to_datetime(v).strftime('%d.%m.%Y') if v else ''
    d = pd.DataFrame({'Файл': L['файл'].astype(str), 'Отдан раз': L['ответов_200'].astype(int), 'Уникальных IP': L['IP'].astype(int),
                      'Размер ответа, байт': L['размер_у_чужих'].fillna(L['размер']).round().astype(int),
                      'Получили свои': L['получили_свои'].astype(int), 'Первый': L['первый'].map(day), 'Последний': L['последний'].map(day)})
    data_sheet(wb, name, d, name, 'Служебные файлы, которые сервер отдал посторонним', {'Файл': 50, 'Отдан раз': 11, 'Уникальных IP': 10, 'Размер ответа, байт': 14, 'Получили свои': 12, 'Первый': 12, 'Последний': 12},
               wrap=('Файл',), kpi=[('Файлов', len(d)), ('Отдан раз', int(d['Отдан раз'].sum()))], kpi_col='Уникальных IP', row_rule=lambda r: F_NOTE,
               links=[('Что искали сканеры', 'Сканеры — что искали')])
    ws = wb[name]
    r_ = ws.max_row + 2
    for t_ in ['Размер ответа не похож на страницу входа или заглушку соседних адресов — значит, отдано настоящее содержимое файла.',
               'Что сделать: открыть каждый адрес, закрыть доступ в настройках сервера (deny в nginx, правило в .htaccess) и сменить пароли и ключи, если они были в файле.']:
        c_ = ws.cell(r_, 2, t_); c_.font = Font(name='Arial', size=9, italic=True, color=GREY); r_ += 1
    return ws


def service_files(wb, res, name='Файлы', title='Файлы', note='Что забирают с сайта как отдельный файл', links=None, errors_mode=False):
    """Все файлы сайта, кроме страниц: кто забирает, откуда, коды. errors_mode — тот же лист в срезе ошибок (02 «Файлы с ошибками»):
    персиковым — файлы, которые подгружают страницы сайта, серым — те, что просят только роботы."""
    import re
    from .recon import FILE_GROUPS
    sf = res.get('files')
    if sf is None:   # старый анализ: только служебные файлы из карты
        from .anatomy import SERVICE_GROUPS
        sf = (res.get('site_map') or {}).get('service_files') or []
        if isinstance(sf, str):
            try: sf = eval(sf)
            except Exception: sf = []
        for f in sf:
            if isinstance(f, dict): f.setdefault('группа', next((nm for nm, rx in SERVICE_GROUPS if re.search(rx, str(f.get('адрес', '')), re.I)), 'Прочие'))
    rows = []
    leaked = {x['файл'] for x in res.get('leaks') or []}
    for f in sf:
        if not isinstance(f, dict): continue
        cd = _codes(f.get('коды'))
        err = sum(v for k, v in cd.items() if 400 <= k and k != 499)
        from urllib.parse import unquote
        a = unquote(str(f.get('адрес', '')), errors='replace') + (f"\n{f['внутри']}" if f.get('внутри') else '')
        if str(f.get('адрес', '')) in leaked: a += '\nотдан посторонним — см. NXLD_03, «Служебные данные»'
        day = lambda k: pd.to_datetime(f.get(k)).strftime('%d.%m.%Y') if f.get(k) else ''
        rows.append({'Файл': a, 'Размер, КБ': float(f.get('средний_размер_КБ') or 0), 'Группа': f.get('группа', 'Прочие'),
                     'Файлов': int(f.get('файлов') or 1), 'Запросов': int(f.get('запросов') or 0),
                     'Ответы': split_codes(f.get('коды'))[0], 'Ошибки': split_codes(f.get('коды'))[1], '_err': int(err),
                     **({'Браузеры': int(f.get('браузеры') or 0), 'Роботы': _who(f.get('роботы', '')) if f.get('роботы') else ''} if 'браузеры' in f
                        else {'Кто забирает': _who(f.get('кто_забирает', ''))}),
                     'Со страниц сайта': int(f.get('со_страниц') or 0), 'Напрямую': int(f.get('напрямую') or 0),
                     'Другие сайты': _who(f.get('другие_сайты', '')) if f.get('другие_сайты') else '',
                     'Первый': day('первый_день'), 'Последний': day('последний_день'), '_leak': str(f.get('адрес', '')) in leaked, '_last': str(f.get('последний_день') or ''),
                     '_crit': f.get('критично'), '_act': f.get('актуально')})
    d = pd.DataFrame(rows)
    if not len(d): return None
    if 'со_страниц' not in (sf[0] if sf and isinstance(sf[0], dict) else {}) or (d['Со страниц сайта'].sum() == 0 and not d['Другие сайты'].astype(bool).any()):   # старый анализ или в логе нет Referer
        d = d.drop(columns=['Со страниц сайта', 'Напрямую', 'Другие сайты'])
    d = d.sort_values('Запросов', ascending=False)
    if name not in wb.sheetnames: wb.create_sheet(name)
    kpi = [('Файлов', int(d['Файлов'].sum())), ('Запросов', int(d['Запросов'].sum())), ('С ошибками', int((d['_err'] > 0).sum()))]
    fonts_ = [None] * len(d)
    if errors_mode:   # критично — файл просят страницы сайта, и ошибка встречается сейчас; давно не встречалась — серым текстом
        recent = errors_mode if isinstance(errors_mode, str) else ''
        own = (d['Со страниц сайта'] > 0) if 'Со страниц сайта' in d else (d['_err'] > 0)
        act = pd.Series([str(x) >= recent for x in d['_last']], index=d.index)
        if '_crit' in d and d['_crit'].notna().all():   # критичность и актуальность — из движка (derive)
            act = d['_act'].astype(bool); own = d['_crit'].astype(bool)
        fills_ = [F_NOTE if o and a else None for o, a in zip(own, act)]
        fonts_ = [None if a else GREY for a in act]
        kpi = [('Файлов', int(d['Файлов'].sum())), ('Ошибок', int(d['_err'].sum())), ('Критично', int((own & act).sum()))]
    else:
        fills_ = [F_NOTE if b_ else None for b_ in ((d['_err'] > 0) | d['_leak'])]   # ошибки и утечки — персиковым
    d = d.drop(columns=['_err', '_leak', '_last', '_crit', '_act'])
    widths = {'Файл': 52, 'Размер, КБ': 10, 'Группа': 18, 'Файлов': 9, 'Запросов': 11, 'Ответы': 34, 'Ошибки': 26, 'Кто забирает': 44, 'Браузеры': 11, 'Роботы': 44, 'Со страниц сайта': 11, 'Напрямую': 11, 'Другие сайты': 40, 'Первый': 12, 'Последний': 12}
    missing = [nm for nm in ('Документы', 'Видео и звук') if nm not in set(d['Группа'])] if res.get('files') is not None and not errors_mode else []   # заметные отсутствия
    links = links if links is not None else [('Сводка по группам', 'Анатомия сайта'), ('Логи, по которым всё посчитано', 'Логи')]
    data_sheet(wb, name, d, title, note, widths, wrap=('Файл', 'Кто забирает', 'Роботы', 'Другие сайты', 'Ответы', 'Ошибки'),
               kpi=kpi, kpi_col='Файлов', links=links, row_rule=lambda r, _it=iter(fills_): next(_it), font_rule=lambda r, _it=iter(fonts_): next(_it),
               red=() if errors_mode else ('Ошибки',))
    ws = wb[name]
    if missing:
        r = ws.max_row + 2
        ws.cell(r, 2, 'Не найдено: ' + ', '.join(missing).lower() + '. Обращения сканеров к несуществующим файлам сюда не попадают.')
        ws.cell(r, 2).font = Font(name='Arial', size=9, italic=True, color=GREY)
    if errors_mode:
        r = ws.max_row + 2
        for t_ in ['Файлы, которые никто не запрашивал по ссылке, — перебор и мусор, их здесь нет: они на вкладках по кодам. Зонды сканеров — в отчёте по безопасности.']:
            ws.cell(r, 2, t_).font = Font(name='Arial', size=9, italic=True, color=GREY); r += 1
        legend(ws, ['со_страниц', 'обычно', 'неактуально'])
    return wb[name]


def _err_share(codes):
    """Доля ошибок 4xx/5xx без 499 (человек ушёл, не дождавшись) и есть ли 5xx."""
    cd = _codes(codes); tot = sum(cd.values()) or 1
    err = sum(v for k, v in cd.items() if k >= 400 and k != 499)
    return err / tot, any(k >= 500 for k in cd)


def embedded_sheet(wb, res, name='Динамические блоки'):
    """Блоки внутри страницы: что браузер подгружает сам и что человек вызывает действием."""
    E = res.get('embedded')
    if not E: return None
    def blk(e):
        n = int(e.get('блоков') or 1)
        w = 'адрес' if n % 10 == 1 and n % 100 != 11 else 'адреса' if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14 else 'адресов'
        return e['блок'] + (f' — {n} {w}' if n > 1 else '')
    day = lambda v: pd.to_datetime(v).strftime('%d.%m.%Y') if v else ''
    d = pd.DataFrame([{'Блок': blk(e), 'Размер, КБ': float(e['средний_размер_КБ']), 'Вид': e['вид'], 'Загрузка': e['загрузка'],
                       'Запросов': int(e['запросов']), 'Визитов (люди)': int(e['визитов_людей']),
                       'Автозагрузка, %': e['автозагрузка'] if e.get('автозагрузка') is not None else '',
                       'Охват страниц': int(e['охват_страниц']), 'Ответы': split_codes(e['коды'])[0], 'Ошибки': split_codes(e['коды'])[1],
                       'Первый': day(e['первый_день']), 'Последний': day(e['последний_день'])} for e in E])
    bad = [bool(split_codes(e['коды'])[1]) for e in E]
    d['_bad'] = bad
    cnt = d['Загрузка'].value_counts()
    kpi = [('Блоков', len(d)), ('Подгрузок', int(d['Запросов'].sum())), ('Авто', int(cnt.get('авто', 0))), ('По действию', int(cnt.get('по действию', 0))), ('С ошибками', int(sum(bad)))]
    if name not in wb.sheetnames: wb.create_sheet(name)
    widths = {'Блок': 52, 'Размер, КБ': 10, 'Вид': 26, 'Загрузка': 13, 'Запросов': 13, 'Визитов (люди)': 13, 'Автозагрузка, %': 13,
              'Охват страниц': 11, 'Ответы': 34, 'Ошибки': 26, 'Первый': 12, 'Последний': 12}
    data_sheet(wb, name, d.drop(columns='_bad'), 'Динамические блоки', 'Что подгружается внутри страницы: само или по действию человека', widths,
               wrap=('Блок', 'Вид', 'Ответы', 'Ошибки'), center=('Загрузка',), kpi=kpi, kpi_col='Запросов',
               row_rule=lambda r, _it=iter(bad): F_NOTE if next(_it) else None,   # блоки с ошибками — персиковым, как в «Файлах»
               links=[('Сводка по видам', 'Анатомия сайта'), ('Куда формы отправляют данные', 'Точки приёма данных'), ('Сочетания фильтров', 'Фасеты')])
    ws = wb[name]
    for i, k_ in enumerate(d['Вид']):   # неопознанные — серым; ошибки видны красным в колонке «Ошибки», много это или мало — решает аналитик
        fill = 'EFEFEF' if k_ == 'Неопознанные' else None
        if fill:
            for c in range(2, 2 + len(d.columns) - 1): ws.cell(5 + i, c).fill = PatternFill('solid', fgColor=fill)
    return ws


def pages_sheet(wb, T, name, mode):
    """«Разделы», «Типы страниц», «Страницы» — один лист на срезе реестра адресов (blocks.top_pages)."""
    if T is None or not len(T) or name not in wb.sheetnames: return None
    from urllib.parse import unquote
    from .blocks import TOP_CHANNELS
    chans = [lab for _, lab in TOP_CHANNELS] + ['Прочие']
    dec = lambda x: unquote(str(x), errors='replace')
    first = {'Разделы': 'Раздел', 'Типы страниц': 'Тип страницы', 'Страницы': 'Страница'}[mode]
    cols = {first: T['страница'].map(dec)}
    if mode == 'Разделы': cols['Статус'] = T['статус']
    if mode in ('Разделы', 'Типы страниц'): cols['Страниц'] = T['страниц'].astype(int)
    cols.update({'Просмотров': T['просмотров'].astype(int), 'Визитов (люди)': T['визитов'].astype(int), 'Уникальных IP (люди)': T['ip'].astype(int),
                 'Заявок отправлено': T['заявок'].astype(int)})
    if 'ответы' in T:
        sp = T['ответы'].fillna('').map(split_codes)
        cols['Ответы'], cols['Ошибки'] = sp.str[0], sp.str[1]
    else:
        cols['Ошибки'] = T['ошибки'].map(lambda x: split_codes(x)[1] if x else '')
    cols.update({c_: T[c_].astype(int) for c_ in chans})
    if mode == 'Типы страниц': cols['Пример'] = T['пример'].map(dec)
    d = pd.DataFrame(cols)
    dead = list(T['статус'].isin(['не существует', 'сломан'])) if mode == 'Разделы' else list(d['Ошибки'].astype(bool))   # на страницах — строки с ошибками
    kpi = [({'Разделы': 'Разделов', 'Типы страниц': 'Типов', 'Страницы': 'Страниц'}[mode], len(d))]
    if mode == 'Разделы': kpi.append(('Не существуют', int(sum(dead))))
    kpi += [('Визитов (люди)', int(d['Визитов (люди)'].sum())), ('Заявок', int(d['Заявок отправлено'].sum()))]
    if mode != 'Разделы': kpi.append(('С ошибками', int(d['Ошибки'].astype(bool).sum())))
    widths = {first: 55 if mode != 'Разделы' else 30, 'Статус': 14, 'Страниц': 9, 'Просмотров': 11, 'Визитов (люди)': 12, 'Уникальных IP (люди)': 11,
              'Заявок отправлено': 11, 'Ответы': 30, 'Ошибки': 22, 'Пример': 50, **{c_: 11 for c_ in chans}}
    note = {'Разделы': 'Запрашиваемые разделы сайта', 'Типы страниц': 'Страницы одного вида, собранные по шаблону адреса',
            'Страницы': 'TOP500 — самые посещаемые страницы сайта'}[mode]
    links = {'Разделы': [('Типы страниц внутри разделов', 'Типы страниц'), ('Устройство разделов', 'Анатомия сайта')],
             'Типы страниц': [('Разделы', 'Разделы'), ('Отдельные страницы', 'Страницы'), ('Каталоги по уровням', 'Анатомия сайта')],
             'Страницы': [('Типы страниц', 'Типы страниц'), ('Разделы', 'Разделы')]}[mode]
    data_sheet(wb, name, d, mode, note, widths, wrap=(first, 'Ответы', 'Ошибки', 'Пример'), center=('Статус',),
               kpi=kpi, kpi_col='Просмотров', row_rule=lambda r, _it=iter(dead): F_NOTE if next(_it) else None, links=links)
    ws = wb[name]
    r_ = ws.max_row + 2
    notes = {'Разделы': ['Раздел — первый уровень адреса страниц. «Не существует» — людям там ни разу не ответили 2xx.'],
             'Типы страниц': ['Тип страницы — адреса, которые различаются только номерами и названиями (* — изменяемая часть). Пример — самая посещаемая страница этого типа.'],
             'Страницы': ['Только страницы, которые отвечали людям 200.']}[mode]
    notes.append('Заявок отправлено — отправки форм с этих страниц. Каналы — с чего начался визит. Зонды, файлы и битые адреса — на своих листах.')
    for t_ in notes:
        c_ = ws.cell(r_, 2, t_); c_.font = Font(name='Arial', size=9, italic=True, color=GREY); r_ += 1
    return ws


WEEKDAY = ('Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс')


def journal_sheet(wb, name, A, subtitle, kpi, links, notes, top_labels=None, kpi_col=None, outages=None):
    """Журнал по дням с двухуровневой шапкой: «День» (день недели, дата, время в логе) и группы колонок вида «Верх|Низ».
    A — строки по дням (день, _с, _по, _полный, «Верх|Низ»…) и строка «Итого». Общий для «Журнала активности» и «Журнала ошибок»."""
    if A is None or not len(A) or name not in wb.sheetnames: return None
    top_labels = top_labels or {}
    body = A[A['день'] != 'Итого']
    tot = A[A['день'] == 'Итого']
    dt_ = pd.to_datetime(body['день'])
    groups = [c_ for c_ in A.columns if '|' in c_]
    cols = {'День': [WEEKDAY[d.weekday()] for d in dt_], 'Дата': dt_.dt.strftime('%d.%m.%Y').tolist(),
            'Время': ['00:00–23:59' if full else f'{a}–{b}' for a, b, full in zip(body['_с'], body['_по'], body['_полный'])]}
    for g in groups: cols[g] = body[g].astype(int).tolist()
    d = pd.DataFrame(cols)
    if len(tot):
        t_ = {'День': 'Итого', 'Дата': '', 'Время': f'{len(body)} дн.'}
        t_.update({g: int(tot[g].iloc[0]) for g in groups})
        d = pd.concat([d, pd.DataFrame([t_])], ignore_index=True)
    full_days = body['_полный'].values
    weekend = [x >= 5 for x in dt_.dt.weekday] + [False] * len(tot)
    od = {}
    if outages is not None and len(outages):   # дни со сбоями: строка персиковая, сбои — последней колонкой (порядок остальных колонок не меняется)
        for _, o in outages.iterrows():
            od.setdefault(o['день'], []).append(f"{o['сбой']}, {int(o['минут_всего'])} мин")
        d['Сбой'] = ['\n'.join(od.get(x, [])) for x in body['день']] + [''] * len(tot)
    row_fill = [F_NOTE if (i < len(body) and body['день'].iloc[i] in od) else ('F3F3F3' if w else None) for i, w in enumerate(weekend)]
    widths = {'День': 7, 'Дата': 12, 'Время': 13, 'Сбой': 20, **{g: 10 for g in groups}}
    data_sheet(wb, name, d, name, subtitle, widths, center=('День', 'Дата', 'Время'), wrap=('Сбой',),
               kpi=kpi(body) if callable(kpi) else kpi, kpi_col=kpi_col if kpi_col in groups else None,
               row_rule=lambda r, _it=iter(row_fill): next(_it), links=links)
    ws = wb[name]
    H, X = 4, 1
    # шапка в два уровня: строка 3 — группы (объединённые ячейки), строка 4 — колонки
    hdr = ['День', 'День', 'День'] + [top_labels.get(g.split('|')[0], g.split('|')[0]) for g in groups] + (['Сбой'] if od else [])
    j = 0
    while j < len(hdr):
        k = j
        while k + 1 < len(hdr) and hdr[k + 1] == hdr[j]: k += 1
        c_ = ws.cell(H - 1, j + 1 + X, hdr[j])
        c_.font = Font(name='Arial', size=9, bold=True, color='FFFFFF'); c_.fill = PatternFill('solid', fgColor=ORANGE)
        c_.alignment = Alignment(horizontal='center', vertical='center')
        for q in range(j, k + 1):
            cc = ws.cell(H - 1, q + 1 + X); cc.fill = PatternFill('solid', fgColor=ORANGE)
            cc.border = Border(left=WHITE if q == j else None, right=WHITE if q == k else None, bottom=WHITE)
        if k > j: ws.merge_cells(start_row=H - 1, start_column=j + 1 + X, end_row=H - 1, end_column=k + 1 + X)
        j = k + 1
    ws.row_dimensions[H - 1].height = 20
    for q, g in enumerate(groups):
        ws.cell(H, q + 4 + X).value = g.split('|')[1]
    if od:   # «Сбой» — одна колонка на два уровня шапки
        col_ = len(hdr) + X
        ws.cell(H, col_).value = None
        ws.merge_cells(start_row=H - 1, start_column=col_, end_row=H, end_column=col_)
    ws.row_dimensions[H].height = 20
    # неполные дни — серым курсивом; «Итого» — жирным с линией сверху
    for i, full in enumerate(full_days):
        if not full:
            for q in range(len(d.columns)):
                c_ = ws.cell(H + 1 + i, q + 1 + X); c_.font = Font(name='Arial', size=9, italic=True, color=GREY)
    if len(tot):
        r_ = H + len(d)
        for q in range(len(d.columns)):
            c_ = ws.cell(r_, q + 1 + X); c_.font = Font(name='Arial', size=9, bold=True)
            c_.border = Border(top=Side(style='thin', color=ORANGE), bottom=SEP)
        ws.auto_filter.ref = f"{ws.cell(H, 1 + X).coordinate}:{ws.cell(H + len(d) - 1, len(d.columns) + X).coordinate}"
    r_ = ws.max_row + 2
    for t_ in notes:
        c_ = ws.cell(r_, 2, t_); c_.font = Font(name='Arial', size=9, italic=True, color=GREY); r_ += 1
    legend(ws, (['сбой'] if od else []) + ['выходные', 'неполный'])
    return ws


def _day(ts): return f"{WEEKDAY[pd.Timestamp(ts).weekday()]} {pd.Timestamp(ts).strftime('%d.%m')}"


def activity_sheet(wb, A, name='Журнал активности', outages=None):
    """Журнал активности: визиты, уникальные IP и заявки по дням для людей, роботов, ботов и своих."""
    def kpi(body):
        hv = body.loc[body['_полный'], 'Визиты|Люди'] if body['_полный'].any() else body['Визиты|Люди']
        return [('Визиты людей в день', int(round(hv.mean())) if len(hv) else 0),
                ('Самый активный день', _day(body.loc[body['Визиты|Люди'].idxmax(), 'день']) if len(body) else ''),
                ('Заявки людей', int(body['Заявки|Люди'].sum()))]
    return journal_sheet(wb, name, A, 'Визиты, уникальные IP и заявки по дням', kpi,
                         [('Кто заходит на сайт', 'Активность'), ('Все отправки форм', 'Конверсии')] + ([('Сбои', ('NXLD_02_Errors.xlsx', 'Сбои'))] if outages is not None and len(outages) else []),
                         ['Визиты — по группам, как на листе «Активность». IP — разные адреса за день; в «Итого» — разные за весь период, поэтому меньше суммы по дням.',
                          'Заявки — отправки форм; у ботов — спам, у своих — тесты. Время — какая часть суток попала в лог; неполные дни в среднее не входят.'],
                         top_labels={'IP': 'Уникальные IP'}, kpi_col='IP|Люди', outages=outages)


SRC_LABEL = {'документация': 'Документация', 'сообщество': 'Сообщество', 'сборник': 'Сообщество', 'наблюдение': 'Сообщество',
             'поиск': 'Оперативный поиск', 'поиск, подтверждено': 'Оперативный поиск, подтверждено', 'дедукция': 'Дедукция', 'поведение': 'Дедукция', 'имя': 'Дедукция', '': ''}


def _mask_top(p):
    """Частое значение — без «ключ=», поэтому mask_pd_cells его не видит: маскируется здесь как значение своего параметра (recon.mask_value)."""
    from .recon import mask_value
    v = p['частое_значение']
    if not isinstance(v, str) or not v or v == '(пусто)': return v
    m = mask_value(p.get('ключ') or p['параметр'], v)
    return v if m is None else m


def params_sheet(wb, res, name='Параметры запросов'):
    """Каждый ключ (семейство ключей) после «?»: группа, что это, откуда знаем, запросы, люди, значения, где встречается."""
    P = res.get('params')
    if not P: return None
    from .anatomy import PARAM_ORDER as order
    d = pd.DataFrame([{'Параметр': p['параметр'], 'Группа': p['группа'], 'Запросов': int(p['запросов']), 'Визитов (люди)': int(p['людей']),
                       'Опознание': p.get('что', ''), 'Основание': SRC_LABEL.get(p.get('источник', ''), p.get('источник', '')),
                       'Значений': int(p['значений']), 'Частое значение': _mask_top(p),
                       'Точки обращения': _who(p['где']), 'Спутники': p.get('вместе_с', '')} for p in P])
    if not d['Спутники'].astype(bool).any(): d = d.drop(columns='Спутники')
    cnt = d['Группа'].value_counts()
    kpi = [('Параметров', len(d))] + [(g.split(',')[0], int(cnt[g])) for g in order if cnt.get(g)]
    kpi = [k for k in kpi if k[1]] + [k for k in kpi if not k[1]]
    if name not in wb.sheetnames: wb.create_sheet(name)
    widths = {'Параметр': 30, 'Группа': 24, 'Запросов': 11, 'Визитов (люди)': 11, 'Опознание': 50, 'Основание': 18, 'Значений': 10, 'Частое значение': 36, 'Точки обращения': 40, 'Спутники': 40}
    data_sheet(wb, name, d, 'Параметры запросов', 'Что передают в адресе после «?»', widths, wrap=('Параметр', 'Группа', 'Опознание', 'Основание', 'Частое значение', 'Точки обращения', 'Спутники'),
               kpi=kpi, kpi_col='Запросов', row_rule=lambda r: F_NOTE if r.get('Группа') == 'Атаки и зонды' else 'EFEFEF' if r.get('Группа') == 'Неизвестные' else 'F7F7F7' if r.get('Основание') == 'Дедукция' else None,
               links=[('Сводка по группам', 'Анатомия сайта'), ('Фильтры каталога по значениям', 'Фасеты')])
    ws = wb[name]
    return ws


ERR_TOKEN = None


_PCT = None


def human_url(v):
    """Раскодирует в адресе только не-латинские буквы (кириллицу и т. п.) и пробел. Закодированная латиница
    (%27, %3C, %65) остаётся как в логе — это улика: так прячут атаки и зонды."""
    import re
    global _PCT
    if not isinstance(v, str) or '%' not in v: return v
    if _PCT is None: _PCT = re.compile(r'(?:%[0-9A-Fa-f]{2})+')
    def rep(m):
        raw = m.group(0)
        toks = [raw[i:i + 3] for i in range(0, len(raw), 3)]
        bs = bytes(int(t[1:], 16) for t in toks)
        out, i = [], 0
        while i < len(bs):
            b = bs[i]
            if b < 0x80:
                out.append(' ' if b == 0x20 else toks[i]); i += 1; continue
            n = 2 if b >> 5 == 0b110 else 3 if b >> 4 == 0b1110 else 4 if b >> 3 == 0b11110 else 0
            try:
                if not n: raise ValueError
                out.append(bs[i:i + n].decode('utf-8')); i += n
            except Exception:
                out.append(toks[i]); i += 1
        return ''.join(out)
    return _PCT.sub(rep, v)


def humanize_urls(wb, skip=('_snapshot',)):
    """Во всех листах: кириллица в адресах — буквами, а не %D0%BA…; по правилу human_url."""
    for ws in wb.worksheets:
        if ws.title in skip: continue
        for row in ws.iter_rows():
            for c in row:
                v = c.value
                if isinstance(v, str) and '%' in v:
                    h = human_url(v)
                    if h != v: c.value = h


def redden_codes(wb, skip=('_snapshot',), only=None, rx=r'код|ответ'):
    """Во всех листах: в колонках с кодами ответа ошибки (4xx/5xx, кроме 499) — красным #C00000, остальное как было."""
    import re
    from openpyxl.cell.rich_text import CellRichText, TextBlock
    from openpyxl.cell.text import InlineFont
    tok = re.compile(r'(?<!\d)([1-5]\d\d)(\s*(?::\s*[\d\s\u00a0]+|\([\d\s\u00a0]+\)))')
    for ws in wb.worksheets:
        if ws.title in skip or ws.max_row < 2 or (only is not None and ws.title not in only): continue
        hdr_rows = [r for r in range(1, min(ws.max_row, 6) + 1)]
        cols = {}
        for r in hdr_rows:
            for c in range(1, ws.max_column + 1):
                v = ws.cell(r, c).value
                if isinstance(v, str) and re.search(rx, v, re.I) and v.strip() not in ('Ответы',):
                    cols[c] = r
        for c, hr in cols.items():
            for r in range(hr + 1, ws.max_row + 1):
                cell = ws.cell(r, c); v = cell.value
                if not isinstance(v, str) or not tok.search(v): continue
                parts, pos, any_bad = [], 0, False
                f0 = cell.font
                base = InlineFont(rFont=f0.name or 'Arial', sz=f0.sz or 9, b=f0.b, color=(f0.color.rgb if f0.color is not None and isinstance(f0.color.rgb, str) else None))
                redf = InlineFont(rFont=f0.name or 'Arial', sz=f0.sz or 9, b=f0.b, color=RED)
                for m in tok.finditer(v):
                    k = int(m.group(1)); bad = k >= 400 and k != 499
                    if not bad: continue
                    any_bad = True
                    if m.start() > pos: parts.append(TextBlock(base, v[pos:m.start()]))
                    parts.append(TextBlock(redf, m.group(0))); pos = m.end()
                if any_bad:
                    if pos < len(v): parts.append(TextBlock(base, v[pos:]))
                    cell.value = CellRichText(parts)


def heat_sheet(wb, name, title, subtitle, blocks, intro=(), links=(), unit='Запросов за час', foot=None):
    """Тепловые карты «день × час» друг под другом на одном листе: blocks — [(заголовок, подпись, DataFrame день × 0..23)].
    Перед картами — заметка, куда смотреть (intro). Общий для «Нагрузки по часам» (03) и «Признаков торможения» (02)."""
    from openpyxl.formatting.rule import ColorScaleRule
    from openpyxl.utils import get_column_letter as L_
    idx = wb.sheetnames.index(name) if name in wb.sheetnames else len(wb.sheetnames)
    if name in wb.sheetnames: del wb[name]
    ws = wb.create_sheet(name, idx)
    ws.column_dimensions['A'].width = 2.5
    ws['B1'] = title.upper(); ws['B1'].font = Font(name='Montserrat', size=16, bold=True, color=ORANGE); ws.row_dimensions[1].height = 34
    ws['B2'] = subtitle; ws['B2'].font = Font(name='Comfortaa', size=11, bold=True, color=GREY); ws.row_dimensions[2].height = 24
    r = 4
    for t_ in intro:   # заметка перед картами — персиковая плашка на всю ширину
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=28)
        c_ = ws.cell(r, 2, t_); c_.font = Font(name='Arial', size=10, italic=True, color=INK); c_.fill = PatternFill('solid', fgColor=F_NOTE)
        c_.alignment = Alignment(wrap_text=True, vertical='center', indent=1)
        ws.row_dimensions[r].height = 15 * (len(t_) // 170 + 1) + 10
        r += 1
    r += 1
    for blk in blocks:
        bt, bn, P = blk[:3]
        fmt_ = blk[3] if len(blk) > 3 else None   # формат чисел карты: None — целые с разрядами, иначе строка формата Excel
        if P is None or not len(P): continue
        ws.cell(r, 2, bt.upper()).font = Font(name='Montserrat', size=12, bold=True, color=ORANGE); ws.row_dimensions[r].height = 22; r += 1
        if bn:
            ws.cell(r, 2, bn).font = Font(name='Arial', size=9, italic=True, color=GREY); r += 1
        hdr = ['День', '' if len(P) and isinstance(P.index[0], (int, np.integer)) else 'Дата'] + [f'{h:02d}' for h in range(24)] + ([] if fmt_ else ['Всего'])
        for j, v in enumerate(hdr):
            c_ = ws.cell(r, 2 + j, v); c_.font = Font(name='Arial', size=9, bold=True, color='FFFFFF'); c_.fill = PatternFill('solid', fgColor=ORANGE)
            c_.alignment = Alignment(horizontal='center', vertical='center'); c_.border = Border(left=WHITE, right=WHITE)
        r += 1; r0 = r
        for day, row in P.iterrows():
            wk = isinstance(day, (int, np.integer))   # карта «день недели × час» (05): строка — день недели 0..6, без даты
            wd = int(day) if wk else pd.Timestamp(day).weekday()
            ws.cell(r, 2, WEEKDAY[wd]).alignment = Alignment(horizontal='center')
            ws.cell(r, 3, '' if wk else pd.Timestamp(day).strftime('%d.%m')).alignment = Alignment(horizontal='center')
            for h in range(24):
                v_ = row.get(h)
                v_ = None if v_ is None or pd.isna(v_) else (float(v_) if fmt_ else int(v_))
                c_ = ws.cell(r, 4 + h, v_); c_.number_format = fmt_ or NUM_FMT; c_.font = Font(name='Arial', size=8)
            if not fmt_:
                c_ = ws.cell(r, 28, int(row.fillna(0).sum())); c_.number_format = NUM_FMT; c_.font = Font(name='Arial', size=9, bold=True)
            for q in (2, 3): ws.cell(r, q).font = Font(name='Arial', size=9, color='000000' if wd < 5 else GREY)
            r += 1
        ws.conditional_formatting.add(f'D{r0}:AA{r - 1}', ColorScaleRule(start_type='min', start_color='FFFFFF', mid_type='percentile', mid_value=50,
                                                                        mid_color='FCD9C4', end_type='max', end_color='E8541C'))
        r += 1
    ws.column_dimensions['B'].width = 6; ws.column_dimensions['C'].width = 7
    for j in range(24): ws.column_dimensions[L_(4 + j)].width = 6.3
    ws.column_dimensions['AB'].width = 10
    for text, target in links:
        c = ws.cell(r, 2, f'{text}: лист «{target}» →'); c.hyperlink = f"#'{target}'!A1"; c.font = Font(name='Arial', size=10, color=ORANGE2, underline='single'); r += 1
    c_ = ws.cell(r + 1, 2, foot or f'{unit}. Цвет — от белого (меньше всего) до тёмно-оранжевого (больше всего) в каждой карте отдельно. Выходные — серой датой.')
    c_.font = Font(name='Arial', size=9, italic=True, color=GREY)
    ws.page_setup.orientation = 'landscape'; ws.sheet_properties.pageSetUpPr.fitToPage = True; ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
    return ws


def extra_table(ws, df, title, note='', widths=None, wrap=(), row_rule=None, size=9, at=None, red=('Ошибки',), font_rule=None, groups=None):
    """Вторая таблица на листе — под первой (после ссылок и заметок): заголовок, подпись, оранжевая шапка, строки.
    at — буквы колонок листа для каждой колонки таблицы (широкие колонки — на широкие места первой таблицы)."""
    from openpyxl.utils import column_index_from_string as ci_
    r = ws.max_row + 3
    ws.cell(r, 2, title.upper()).font = Font(name='Montserrat', size=12, bold=True, color=ORANGE); ws.row_dimensions[r].height = 22; r += 1
    if note:
        ws.cell(r, 2, note).font = Font(name='Arial', size=9, italic=True, color=GREY); r += 1
    cols = list(df.columns)
    pos = [ci_(x) for x in at] if at else [2 + j for j in range(len(cols))]
    span = [1] * len(cols)
    if not at and not groups:   # длинный текст — на несколько колонок листа (объединённые ячейки), остальные сдвигаются вправо
        from openpyxl.utils import get_column_letter as L_
        cur = 2
        for j, c in enumerate(cols):
            need = 0
            if c in wrap and len(df):
                need = min(60, df[c].astype(str).str.split('\n').map(lambda xs: max(len(x) for x in xs)).quantile(1.0 if len(df) <= 30 else 0.9) * 0.95 + 2)   # короткая таблица — по самой длинной строке
            n_, w_ = 1, (ws.column_dimensions[L_(cur)].width or 10)
            while need and w_ < need and n_ < 3:
                w_ += ws.column_dimensions[L_(cur + n_)].width or 10; n_ += 1
            pos[j], span[j] = cur, n_
            cur += n_
    if groups:   # шапка в два уровня: верх — над своими колонками, остальные колонки — одной ячейкой на два уровня
        from openpyxl.utils import get_column_letter as L_
        for j, c in enumerate(cols):   # слово шапки не рвётся посередине
            lw = max((len(w_) for w_ in str(c).split()), default=0) * 1.1 + 1.5
            if (ws.column_dimensions[L_(pos[j])].width or 10) < lw: ws.column_dimensions[L_(pos[j])].width = lw
        inner = {c: top for top, cs in groups.items() for c in cs}
        merges = []
        for j, c in enumerate(cols):   # сначала значения и оформление, объединение — после: в объединённую ячейку писать нельзя
            top = inner.get(c)
            cell = ws.cell(r, pos[j], top if top else c)
            for rr in (r, r + 1):
                ws.cell(rr, pos[j]).fill = PatternFill('solid', fgColor=ORANGE); ws.cell(rr, pos[j]).border = Border(left=WHITE, right=WHITE, bottom=WHITE)
            cell.font = Font(name='Arial', size=size, bold=True, color='FFFFFF'); cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            if not top: merges.append((r, pos[j], r + 1, pos[j]))
        for top in groups:
            js = [pos[k] for k, c2 in enumerate(cols) if inner.get(c2) == top]
            if len(js) > 1:
                for jj in js[1:]: ws.cell(r, jj).value = None
                merges.append((r, min(js), r, max(js)))
        r += 1
        for j, c in enumerate(cols):
            if c in inner:
                cell = ws.cell(r, pos[j], c); cell.font = Font(name='Arial', size=size, bold=True, color='FFFFFF')
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        for a, b_, c_, d_ in merges: ws.merge_cells(start_row=a, start_column=b_, end_row=c_, end_column=d_)
    for j, c in enumerate(cols):
        if groups: break   # шапка в два уровня уже записана
        cell = ws.cell(r, pos[j], c); cell.font = Font(name='Arial', size=size, bold=True, color='FFFFFF'); cell.fill = PatternFill('solid', fgColor=ORANGE)
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True); cell.border = Border(left=WHITE, right=WHITE)
        for k_ in range(1, span[j]): ws.cell(r, pos[j] + k_).fill = PatternFill('solid', fgColor=ORANGE)
    if not groups:
        for j in range(len(cols)):
            if span[j] > 1: ws.merge_cells(start_row=r, start_column=pos[j], end_row=r, end_column=pos[j] + span[j] - 1)
    if not groups:   # высота шапки — по самому длинному названию при ширине его колонок (с учётом объединения)
        import math
        from openpyxl.utils import get_column_letter as L_
        lines = 1
        for j, c in enumerate(cols):
            w_ = sum((ws.column_dimensions[L_(pos[j] + k_)].width or 10) for k_ in range(span[j]))
            words = str(c).split()
            if words and max(len(x) for x in words) * 1.1 > w_ - 1:   # слово не помещается — колонка шире
                ws.column_dimensions[L_(pos[j] + span[j] - 1)].width = (ws.column_dimensions[L_(pos[j] + span[j] - 1)].width or 10) + max(len(x) for x in words) * 1.1 - w_ + 2
                w_ = max(len(x) for x in words) * 1.1 + 1
            lines = max(lines, math.ceil(len(str(c)) * 1.15 / max(4, w_ - 1)))
        ws.row_dimensions[r].height = max(20, 13 * lines + 8)
    for row in df.itertuples(index=False):
        r += 1
        rf = row_rule(dict(zip(cols, row))) if row_rule else None
        for j, v in enumerate(row):
            if isinstance(v, float) and pd.isna(v): v = None
            if hasattr(v, 'item'): v = v.item()
            if isinstance(v, str): v = ILLEGAL.sub('�', v)
            cell = ws.cell(r, pos[j], v)
            isnum = isinstance(v, numbers.Number) and not isinstance(v, bool)
            ff = font_rule(dict(zip(cols, row))) if font_rule else None
            cell.font = Font(name='Arial', size=size, color=ff or (RED if cols[j] in red else '000000'))
            cell.alignment = Alignment(horizontal='right' if isnum else 'left', vertical='top', wrap_text=cols[j] in wrap, indent=1)
            if isnum and isinstance(v, int) and abs(v) >= 1000: cell.number_format = NUM_FMT
            cell.border = Border(bottom=SEP)
            if rf: cell.fill = PatternFill('solid', fgColor=rf)
            for k_ in range(1, span[j]):
                cc = ws.cell(r, pos[j] + k_); cc.border = Border(bottom=SEP)
                if rf: cc.fill = PatternFill('solid', fgColor=rf)
        for j in range(len(cols)):
            if span[j] > 1: ws.merge_cells(start_row=r, start_column=pos[j], end_row=r, end_column=pos[j] + span[j] - 1)
        if max(span) > 1:   # высота строки — по самому длинному тексту в объединённых ячейках
            from openpyxl.utils import get_column_letter as L_
            lines = 1
            for j, v in enumerate(row):
                if cols[j] in wrap and v is not None:
                    w_ = sum((ws.column_dimensions[L_(pos[j] + k_)].width or 10) for k_ in range(span[j]))
                    lines = max(lines, sum(max(1, -(-len(x) // max(5, int(w_ * 1.05)))) for x in str(v).split('\n')))
            ws.row_dimensions[r].height = max(15, 12.5 * lines + 3)
    return ws



def mask_pd_cells(wb, skip=('_snapshot',)):
    """Во всех листах: персональные данные (телефоны, почты, ФИО) в адресах и параметрах — маскированно, по общему правилу recon.has_pd / mask_pd;
    секреты (sessid, token, USER_CHECKWORD…) — первые 4 символа и «…» (recon.has_secret / mask_secrets).
    Смотрятся только ячейки, похожие на адрес с параметрами (есть «=»), — числа с разрядами и даты не трогаются."""
    from .recon import has_pd, mask_pd, has_secret, mask_secrets
    import re
    for ws in wb.worksheets:
        if ws.title in skip: continue
        for row in ws.iter_rows():
            for c in row:
                v = c.value
                if not isinstance(v, str) or '=' not in v: continue
                parts = re.split(r'(\s+)', v)
                out, hit = [], False
                for p_ in parts:
                    q = p_.split('?', 1)[1] if '?' in p_ else p_
                    if '=' in q and has_pd(q):
                        out.append(p_[:len(p_) - len(q)] + mask_pd(q)); hit = True
                    elif '=' in q and has_secret(q):
                        out.append(p_[:len(p_) - len(q)] + mask_secrets(q)); hit = True
                    else: out.append(p_)
                if hit: c.value = ''.join(out)
