"""NXLD: файл 06 «SEO» — как поисковики видят сайт, по тем же правилам, что 01–05.

Обзор → Проблемы → Статистика → Обход поисковиками → Файлы для роботов → Паразитные адреса → Поисковые ошибки →
Страницы без обхода → Переадресации у роботов → Органика → ИИ-видимость → Подлинность поисковиков.
Данные — seo.build; паразитные адреса — срез 03 (security), поисковые ошибки — блок 02, органика — блок 05,
ИИ-роботы — блок 04: в своих файлах эти листы при 06 не повторяются, там — ссылка «Связанное в других отчётах»."""
from . import sheets
from .catalog import order as catalog_order
import pandas as pd
from .report_index import Wide, brand_header, F_NOTE, GREY
from .seo import OPTIONAL_MISSING
from .report_tables import data_sheet, journal_sheet, extra_table, split_codes, notes, notes_of, legend_of
from .report_bots import notes, ai_sheet
from .report_load import parasites_sheet
from .report_errors import search_errors_sheet
from .report_marketing import organic_sheet

LINK = sheets.LINK_06
p_ = lambda v: str(v).replace('.', ',')


def relink(findings):
    for x in findings:
        if x.get('блок') == 'SEO' and x.get('лист') in LINK: x['лист'] = LINK[x['лист']]


def _sheet(wb, nm, d, sub, widths, wrap, kpi, kpi_col, row_rule=None, links=(), font_rule=None, auto=None):
    if d is None or not len(d): return None
    if nm not in wb.sheetnames: wb.create_sheet(nm)
    data_sheet(wb, nm, d, widths, note=sub, wrap=wrap, kpi=kpi, kpi_col=kpi_col, row_rule=row_rule, links=links, red=('Ошибки',), font_rule=font_rule, auto=auto)   # ошибки — красным
    return wb[nm]


def build_sheets(wb, res):
    D = res.get('seo') or {}
    S = res.get('sheets') or {}
    E = res.get('errors') or {}
    J = D.get('журнал')
    if J is not None and len(J):
        if 'Статистика' not in wb.sheetnames: wb.create_sheet('Статистика')
        def kpi(body):
            full = body[body['_полный'].astype(bool)] if body['_полный'].astype(bool).any() else body
            return [('Запросов Яндекса в день', int(round(full['Запросы поисковиков|Яндекс'].mean()))), ('Запросов Google в день', int(round(full['Запросы поисковиков|Google'].mean()))),
                    ('Людей из поиска', int(body['Люди из поиска|Визитов'].sum()))]
        journal_sheet(wb, 'Статистика', J, kpi, kpi_col='Ответы роботам|Ошибок 5xx', outages=E.get('сбои'))
    C = D.get('обход')
    if C is not None and len(C):
        d = pd.DataFrame({'Робот': C['робот'], 'Поисковик': C['поисковик'], 'Запросов': C['запросов'], 'Страниц': C['страниц'], 'Разных страниц': C['адресов_страниц'],
                          'С параметрами, %': C['с_параметрами_%'], 'Ответ 2xx, %': C['ответ_2xx_%'], 'Переадресаций, %': C['переадресаций_%'], 'Ошибок 4xx, %': C['ошибок_4xx_%'],
                          'Ошибок 5xx, %': C['ошибок_5xx_%'], 'Трафик, МБ': C['МБ'], 'Последний день': pd.to_datetime(C['последний']).dt.strftime('%d.%m.%Y')})
        ws = _sheet(wb, 'Обход поисковиками', d, None, {'Робот': 26, 'Поисковик': 14}, ('Робот',),
                    [('Роботов', len(d)), ('Запросов', int(d['Запросов'].sum()))], 'Ошибок 4xx, %',
                    row_rule=lambda r: F_NOTE if (r.get('Переадресаций, %') or 0) + (r.get('Ошибок 4xx, %') or 0) + (r.get('Ошибок 5xx, %') or 0) >= 20 else None)
        Sc = D.get('разделы')
        if ws is not None and Sc is not None and len(Sc):
            t = pd.DataFrame({'Раздел': Sc['раздел'], 'Запросов': Sc['запросов'], 'Яндекс': Sc['Яндекс'], 'Google': Sc['Google'], 'Bing': Sc['Bing'], 'Прочие': Sc['прочие'],
                              'Ошибок, %': Sc['ошибок_%'], 'Переадресаций, %': Sc['переадресаций_%']})
            extra_table(ws, t.head(60), 'crawl_sections',
                        row_rule=lambda r: F_NOTE if (r.get('Ошибок, %') or 0) >= 10 else None, red=())
        notes_of(ws, 'crawl_sections')
    Fl = D.get('файлы')
    if Fl is not None and len(Fl):
        sp_ = Fl['коды'].map(split_codes)   # ответы и ошибки — отдельно, ошибки красным
        d = pd.DataFrame({'Файл': Fl['файл'], 'Вывод': Fl['вывод'], 'Запросов': Fl['запросов'], 'От поисковиков': Fl['от_поисковиков'], 'Ответы': sp_.str[0], 'Ошибки': sp_.str[1],
                          'Последний ответ': Fl['последний_код'], 'Через переадресацию': Fl['через_переадресацию'], 'Ошибок': Fl['ошибок'],
                          'Проверка из сети': Fl['проверка'] if 'проверка' in Fl else ''})
        ws = _sheet(wb, 'Файлы для роботов', d, None, {'Файл': 36, 'Вывод': 26, 'Ответы': 30, 'Ошибки': 30, 'Проверка из сети': 34},
                    ('Файл', 'Ответы', 'Ошибки', 'Проверка из сети'), [('Файлов', len(d)), ('Не отвечают', int((d['Вывод'] == 'не отвечает').sum()))], 'Последний ответ',
                    row_rule=lambda r: F_NOTE if r.get('Вывод') not in ('отвечает', OPTIONAL_MISSING) else None,
                    font_rule=lambda r: GREY if r.get('Вывод') == OPTIONAL_MISSING else None)   # необязательный файл без ответа — норма, серым
        notes_of(ws)
    X = res.get('security') or {}
    parasites_sheet(wb, X.get('паразиты'))
    search_errors_sheet(wb, (S.get('Ошибки') or {}).get('Ошибки у поисковиков'))
    A, B = D.get('без_обхода'), D.get('без_людей')
    if (A is not None and len(A)) or (B is not None and len(B)):
        a = pd.DataFrame({'Страница': A['страница'], 'Визитов людей': A['визитов_людей']}) if A is not None and len(A) else pd.DataFrame({'Страница': ['—'], 'Визитов людей': [0]})
        ws = _sheet(wb, 'Страницы без обхода', a, None, {'Страница': 70}, ('Страница',),
                    [('Без обхода', len(A) if A is not None else 0), ('Страниц людей', int(D.get('страниц_людей') or 0))], 'Визитов людей')
        if ws is not None and B is not None and len(B):
            sp_ = B['коды'].map(split_codes)
            extra_table(ws, pd.DataFrame({'Страница': B['страница'], 'Запросов роботов': B['запросов_роботов'], 'Ответы': sp_.str[0], 'Ошибки': sp_.str[1], 'Последний обход': B['последний_обход']}),
                        'crawled_unvisited', wrap=('Страница', 'Ответы', 'Ошибки'), red=('Ошибки',))
        notes_of(ws, 'crawled_unvisited')
    R_ = D.get('переадресации')
    if R_ is not None and len(R_):
        d = pd.DataFrame({'Адрес': R_['адрес'], 'Переадресаций': R_['переадресаций'], 'Коды': R_['коды'], 'Роботы': R_['роботы']})
        kpi = [('Адресов', len(d)), ('Переадресаций', int(d['Переадресаций'].sum()))]   # по всем адресам; на лист — 1000 крупнейших
        cut = '· на листе — 1000 крупнейших' if len(d) > 1000 else ''   # динамическая часть подзаголовка (каталог: auto «cut»)
        _sheet(wb, 'Переадресации роботов', d.head(1000), None,
               {'Адрес': 60, 'Роботы': 44, 'Коды': 18}, ('Адрес', 'Роботы'), kpi, 'Коды', auto={'cut': cut})
    organic_sheet(wb, (S.get('Маркетинг') or {}).get('Органика'))
    SB = S.get('Боты') or {}
    ai_sheet(wb, SB.get('ИИ-роботы'), SB.get('ИИ: страницы по запросам людей'), nm='ИИ-видимость')
    Au = D.get('подлинность')
    if Au is not None and len(Au):
        ch_ = Au['проверяется'] if 'проверяется' in Au else pd.Series(True, index=Au.index)
        dash = lambda col: [v if c_ else '—' for v, c_ in zip(Au[col], ch_)]   # у робота нет опубликованных сетей — проверить нельзя
        d = pd.DataFrame({'Робот': Au['робот'], 'Уникальных IP': Au['IP'], 'Подлинных IP': dash('подлинных_IP'), 'Поддельных IP': dash('поддельных_IP'), 'Запросов': Au['запросов'],
                          'Запросов подделок': dash('запросов_подделок'), 'Подделок, %': dash('подделок_%')})
        ws = _sheet(wb, 'Подлинность поисковиков', d, None, {'Робот': 28}, ('Робот',),
                    [('Поддельных IP', int(Au['поддельных_IP'].sum())), ('Их запросов', int(Au['запросов_подделок'].sum()))], 'Подделок, %',
                    row_rule=lambda r: F_NOTE if isinstance(r.get('Подделок, %'), (int, float)) and r.get('Подделок, %') >= 10 else None)
        notes_of(ws)


def overview(wb, res, site):
    D = res.get('seo') or {}
    S = res.get('sheets') or {}
    if 'Обзор' in wb.sheetnames: del wb['Обзор']
    ws = wb.create_sheet('Обзор', 0)
    W = Wide(ws)
    brand_header(ws, W, res, last='I', site=site.upper())
    names = set(wb.sheetnames)
    W.r += 1
    C = D.get('обход'); Fl = D.get('файлы'); Au = D.get('подлинность')
    eng = C.groupby('поисковик')['запросов'].sum() if C is not None and len(C) else pd.Series(dtype=int)
    org = (S.get('Маркетинг') or {}).get('Органика')
    W.kpis([('Запросов Яндекса', int(eng.get('Яндекс', 0))), ('Запросов Google', int(eng.get('Google', 0))), ('Запросов Bing', int(eng.get('Bing', 0))),
            ('Людей из поиска', int(org.drop(columns='day').values.sum()) if org is not None and len(org) else 0),
            ('Страниц без обхода', len(D.get('без_обхода')) if D.get('без_обхода') is not None else 0),
            ('Поддельных IP', int(Au['поддельных_IP'].sum()) if Au is not None and len(Au) else 0)])
    if C is not None and len(C):
        W.block('crawl')
        W.table(['Робот', 'Запросов', 'С параметрами, %', 'Переадресаций, %', 'Ошибок 4xx, %', 'Ошибок 5xx, %'],
                [[r['робот'], int(r['запросов']), r['с_параметрами_%'], r['переадресаций_%'], r['ошибок_4xx_%'], r['ошибок_5xx_%']] for _, r in C.head(6).iterrows()],
                ['BC', 'D', 'E', 'F', 'G', 'H'], num=(1,))
        W.links_of('crawl', names)
    if Fl is not None and len(Fl):
        W.block('robot_files')
        r0 = W.r + 1
        W.table(['Файл', 'Вывод', 'Запросов', 'Ответы', 'Ошибки'], [[r['файл'], r['вывод'], int(r['запросов'])] + list(split_codes(r['коды'])) for _, r in Fl.head(6).iterrows()],
                ['BC', 'D', 'E', 'FG', 'HI'], num=(2,), wrap=0.95)
        W.red(r0, 'H')
        W.links_of('robot_files', names)
    P = (res.get('security') or {}).get('паразиты')
    if P is not None and len(P):
        W.block('parasites')
        W.tsize = 9   # длинные списки роботов и параметров — шрифтом большой таблицы
        W.table(['Базовый адрес', 'Вариантов', 'Фигуранты', 'Виновники'], [[r['адрес'], int(r['вариантов']), r['фигуранты'], r['виновники']] for _, r in P.head(5).iterrows()], ['BC', 'D', 'EF', 'GHI'], num=(1,), wrap=0.95)
        W.tsize = 11
        W.links_of('parasites', names)
    SE = (S.get('Ошибки') or {}).get('Ошибки у поисковиков')
    g = (res.get('сводки') or {}).get('поиск_по_роботам')
    if SE is not None and len(SE) and g is not None:
        W.block('search_errors')
        W.table(['Робот', 'Типов страниц', 'Запросов', 'Ошибок'], [[r['робот'], int(r['типов']), int(r['запросов']), int(r['ошибок'])] for _, r in g.iterrows()], ['B', 'C', 'D', 'E'], num=(1, 2, 3))
        W.links_of('search_errors', names)
    if Au is not None and len(Au):
        F_ = Au[Au['поддельных_IP'] > 0]
        if len(F_):
            W.block('authenticity')
            W.table(['Робот', 'Подлинных IP', 'Поддельных IP', 'Подделок, %'], [[r['робот'], int(r['подлинных_IP']), int(r['поддельных_IP']), r['подделок_%']] for _, r in F_.head(6).iterrows()],
                    ['BC', 'D', 'E', 'F'], num=(1, 2))
            W.links_of('authenticity', names)
    W.related(res, 'SEO')
    W.finish()   # блоки — в порядке каталога (#11)
    ws.page_setup.orientation = 'portrait'; ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    return ws


def build(wb, res, site):
    for k_ in list(wb.sheetnames):
        if k_ not in ('Проблемы',): del wb[k_]
    build_sheets(wb, res)
    from .catalog import prune
    prune(wb, 'SEO')   # до Обзора: строки на невыведенные листы не появляются (#8)
    overview(wb, res, site)
    byname = {w.title: w for w in wb._sheets}
    head_ = [byname[n_] for n_ in catalog_order('SEO') if n_ in byname]   # порядок — из каталога (#8)
    wb._sheets = head_ + [w for w in wb._sheets if w not in head_]
